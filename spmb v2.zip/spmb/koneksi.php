<?php
$conn = mysqli_connect('localhost','root','','db_jadwal');
if(!$conn){
	echo 'gagal terhubung ke database';
}
?>