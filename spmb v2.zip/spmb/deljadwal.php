<?php
if(isset($_POST['delete'])){
	include "koneksi.php";
	$hapus = $_POST['idjadwal'];
	$del = "delete from jadwal where idjadwal = '$hapus'";
	if (mysqli_query($conn, $del)) {
		header ('location:jadwals.php');
	} else {
		echo 'Error deleting record: ' . mysqli_error($conn);
	}
}
?>