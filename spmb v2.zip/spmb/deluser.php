<?php
if(isset($_POST['delete'])){
	include "koneksi.php";
	$hapususer = $_POST['id_user'];
	$del = "delete from user where id_user = '$hapususer'";
	if (mysqli_query($conn, $del)) {
		header ('location:dtuser.php');
	} else {
		echo 'Error deleting record: ' . mysqli_error($conn);
	}
}
?>