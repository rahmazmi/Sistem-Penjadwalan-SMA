<?php 
if(isset($_POST['add'])){
	include "koneksi.php";
	$guru = "SELECT guru.*, mapel.idmapel, mapel.nama_mapel, jurusan.idjur, jurusan.nama_jurusan, kelas.idkelas, kelas.nama_kelas FROM guru INNER JOIN mapel ON guru.mapel_ajar = mapel.nama_mapel INNER JOIN jurusan ON guru.jurusannya = jurusan.nama_jurusan INNER JOIN kelas ON guru.kelas_ajar = kelas.nama_kelas";
	$jam = "select idjam from jampel" ;
	$hari1 = "select idhari from hari";
	$periode1 = "select idperiode from periode";
	$xjadwal = ceil("'idjam'/2 ADD CONSTRAINT 
	$cek1 = '1=1';
	$cek2 = '1=1';
	$cek3 = '1=1';
	
}
?>