<?php 
if(isset($_POST['add'])){
	include "koneksi.php";
	$idjur = $_POST['idjur'];
	$nama_jurusan = $_POST['nama_jurusan'];
	$sql = "insert into jurusan (idjur, nama_jurusan) 
	VALUES('$idjur', '$nama_jurusan')";
	if (mysqli_query($conn, $sql)) {
		header ('location:dtjurusan.php');
	} else {
		echo 'Error: ' . $sql. " . " .mysqli_error($conn);
	}
}
?>