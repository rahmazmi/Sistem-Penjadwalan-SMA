<!--
Author: W3layouts
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE HTML>
<html>
<head>
<title>Sistem Penjadwalan MAN Surabaya</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Modern Responsive web template, Bootstrap Web Templates, Flat Web Templates, Andriod Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyErricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
 <!-- Bootstrap Core CSS -->
<link href="css/bootstrap.min.css" rel='stylesheet' type='text/css' />
<!-- Custom CSS -->
<link href="css/style.css" rel='stylesheet' type='text/css' />
<link href="css/font-awesome.css" rel="stylesheet"> 
<!-- jQuery -->
<script src="js/jquery.min.js"></script>
<script type="text/javascript" src="js/jquery.js"></script>
	<script type="text/javascript" src="jquery.dataTables.js"></script>
	<link rel="stylesheet" type="text/css" href="bootstrap2.css">
	<link rel="stylesheet" type="text/css" href="jquery.dataTables.css">
	<link rel="stylesheet" type="text/css" href="dataTables.bootstrap.css">
<!-- Bootstrap Core JavaScript -->
<script src="js/bootstrap.min.js"></script>
</head>
<body>
<div id="wrapper">
     <!-- Navigation -->
        <nav class="top1 navbar navbar-default navbar-static-top" role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="home.php">SPMP</a>
            </div>
            <!-- /.navbar-header -->
            <ul class="nav navbar-nav navbar-right">
			    <li class="dropdown">
	        		<a href="#" class="dropdown-toggle avatar" data-toggle="dropdown">Haiii, Anda sedang Login Sebagai Admin</a>
	        		<ul class="dropdown-menu">
						<li class="dropdown-menu-header text-center">
							<strong>Settings</strong>
						</li>
						<li class="m_2"><a href="profile.php"><i class="fa fa-user"></i> Profile</a></li>
						<li class="divider"></li>
						<li class="m_2"><a href="logout.php"><i class="fa fa-lock"></i> Logout</a></li>	
	        		</ul>
	      		</li>
			</ul>
			
			
			
			
			
            <div class="navbar-default sidebar" role="navigation">
                <div class="sidebar-nav navbar-collapse">
                    <ul class="nav" id="side-menu">
                        <li>
                            <a href="home.php"><i class="fa fa-dashboard fa-fw nav_icon"></i>Beranda</a>
                        </li>
                        <li>
                            <a href="#"><i class="fa fa-laptop nav_icon"></i>Master<span class="fa arrow"></span></a>
                            <ul class="nav nav-second-level">
                                <li>
                                    <a href="dtuser.php">User</a>
                                </li>
								<li>
                                    <a href="dtuser.php">Guru</a>
                                </li>
								<li>
                                    <a href="dtmapel.php">Mata Pelajaran</a>
                                </li>
								<li>
                                    <a href="dtkelas.php">Kelas</a>
                                </li>
								<li>
                                    <a href="dtjurusan.php">Jurusan</a>
                                </li>
								<li>
                                    <a href="dtjam.php">Jam Pelajaran</a>
                                </li>
                            </ul>
							<!-- /.nav-second-level -->
                        </li>
                        <li>
                            <a href="periode.php"><i class="fa fa-indent nav_icon"></i>Periode</a>
                        </li>
                         <li>
						 <!-- /.nav-second-level -->
                        </li>
                        <li>
                            <a href="jadwal.php"><i class="fa fa-table nav_icon"></i>Jadwal</a>
                        </li>
                         <li>
                        </li>
                    </ul>
                </div>
                <!-- /.sidebar-collapse -->
            </div>
            <!-- /.navbar-static-side -->
        </nav>
        <div id="page-wrapper">
        <div class="col-md-12 graphs">
	   <div class="xs">
  	 
  	<div class="bs-example4" data-example-id="contextual-table">
   
  
 
  
  </div>
  
    <div class="grid_3 grid_5">
     <h3>Data Kelas</h3>
      <div class="bs-example2">
		<div class="modal-dialog">
			<div class="modal-content">
				
			</div><!-- /.modal-content -->
		</div><!-- /.modal-dialog -->
	   </div>
	 <div class="bs-example2 bs-example-padded-bottom">
     <button type="button" class="btn btn-primary btn-lg" data-toggle="modal" data-target="#myModal">
      Input Data Kelas
     </button>
	 <button type="button" class="btn btn-primary btn-lg" data-toggle="modal" data-target="#delModal">
      Hapus Data Kelas
     </button>
	 <a href="cetakkelas.php"><button type="button" class="btn btn-primary btn-lg">
	 Cetak Data Kelas
	 </button></a>
	 
	 <div class="bs-example4" data-example-id="contextual-table">
    <table class="table">
      <thead>
        <tr>
          <th>#</th>
          <th>Kelas</th>
		 <th>Jurusan</th>
		  <th>Aksi</th>
        </tr>
      </thead>
	  <tbody>
	  <?php
  include "koneksi.php";
  $sql = "select * FROM kelas inner join jurusan on kelas.idjur = jurusan.idjur
";
  $query  = mysqli_query($conn,$sql);
  while($row = mysqli_fetch_assoc($query)){
    ?>
        <tr>
          <td><?=$row['idkelas']?></td>
          <td><?=$row['nama_kelas']?></td>
		   <td><?=$row['nama_jurusan']?></td>
		  <td>
		  <a href="editkelas.php?id=<?php echo $row['idkelas'] ?>">Edit</a>
		  </td>
        </tr>
    <?php
  }
 ?>
				
			</tbody>
		</table>
   </div>
   <form action="delkelas.php" method="post" enctype="multipart/form-data">
	<div class="modal fade" id="delModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="display: none;">
					<div class="modal-dialog">
						<div class="modal-content">
							<div class="modal-header">
								<button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
								<h2 class="modal-title">Form Hapus Data</h2>
							</div>
							<div class="modal-body">
								<div class="form-group">
									<label class="control-label" for="testimoni_add_name">Masukkan ID yang ingin di hapus</label>
										<input name="idkelas" class="form-control input_text" id="testimoni_add_name" type="text" maxlength="40" required>
								</div>
							</div>
						
							<div class="modal-footer">
								<button type="button" class="btn btn-default" data-dismiss="modal">Batal</button>
								<button type="submit" name="delete" class="btn btn-primary">Tambah Data</button>
							</div>
						</div><!-- /.modal-content -->
					</div><!-- /.modal-dialog -->
				</div>
				</form>
				<form action="addkelas.php" method="post" enctype="multipart/form-data">
     <div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="display: none;">
					<div class="modal-dialog">
						<div class="modal-content">
							<div class="modal-header">
								<button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
								<h2 class="modal-title">Form Input Data</h2>
							</div>
							<div class="modal-body">
								<div class="form-group">
            <label class="control-label" for="testimoni_add_name">ID Kelas</label>
            <input name="idkelas" class="form-control input_text" id="testimoni_add_name" type="number" maxlength="40" required>
          </div>
          <div class="form-group">
            <label class="control-label" for="testimoni_add_name">Nama Kelas</label>
            <input name="nama_kelas" class="form-control input_text" id="testimoni_add_name" type="text" maxlength="40" required>
          </div>
		  <div class="form-group">
            <label class="control-label" for="testimoni_add_name">Jurusan</label>
            <!--<input name="jurusan" class="form-control input_text" id="testimoni_add_name" type="radio" maxlength="40" required="">-->
            <input type="radio" name="idjur" value="1" id="1"> IPA
            <input type="radio" name="idjur" value="2" id="2"> IPS
			<input type="radio" name="idjur" value="3" id="3"> AGAMA
          </div>
      </div>
	  
	  
	  
							<div class="modal-footer">
								<button type="button" class="btn btn-default" data-dismiss="modal">Batal</button>
								<button type="submit" name="add" class="btn btn-primary">Tambah Data</button>
							</div>
							</div><!-- /.modal-content -->
					</div><!-- /.modal-dialog -->
				</div>
           
							</form>
				
				
				
         </div>
		 
  <div class="copy_layout">
      <p>Copyright © 2015 Modern. All Rights Reserved | Design by <a href="http://w3layouts.com/" target="_blank">W3layouts</a> </p>
  </div>
   </div>
      </div>
      <!-- /#page-wrapper -->
   </div>
    <!-- /#wrapper -->
<!-- Nav CSS -->
<link href="css/custom.css" rel="stylesheet">
<!-- Metis Menu Plugin JavaScript -->
<script src="js/metisMenu.min.js"></script>
<script src="js/custom.js"></script>
</body>
</html>