<?php 
if(isset($_POST['add'])){
	include "koneksi.php";
	$iduser = $_POST['id_user'];
	$email = $_POST['email'];
	$password = md5($_POST['password']);
	$nipuser = $_POST['nipuser'];
	$nama = $_POST['nama_lengkap'];
	$pangkat = $_POST['pangkat'];
	$sql = "insert into user (id_user, email, password, nipuser, nama_lengkap, level) 
	VALUES('$iduser', '$email', '$password', '$nipuser', '$nama', '$pangkat')";
	if (mysqli_query($conn, $sql)) {
		header ('location:dtuser.php');
	} else {
		echo 'Error: ' . $sql. " . " .mysqli_error($conn);
	}
}
?>