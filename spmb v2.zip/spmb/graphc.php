<?php
error_reporting (E_ALL^(E_NOTICE | E_WARNING));
require_once "graph.php";

//When source is file
$col = new GraphColoring();

//When source is DB
$newCol = new GraphColoring();
//Data from DB
$newCol->initSource("graph","DB");
$newCol->initGraph();
$newCol->initColoring();
$newCol->displayColorResult();

?>