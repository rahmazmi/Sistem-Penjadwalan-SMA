-- phpMyAdmin SQL Dump
-- version 4.6.5.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 09, 2018 at 05:35 PM
-- Server version: 10.1.21-MariaDB
-- PHP Version: 5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_jadwal`
--

-- --------------------------------------------------------

--
-- Table structure for table `dt_ngajar`
--

CREATE TABLE `dt_ngajar` (
  `iddata` int(11) NOT NULL,
  `gurunya` varchar(200) NOT NULL,
  `mapelnya` varchar(200) NOT NULL,
  `jurnya` varchar(200) NOT NULL,
  `kelasnya` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `generate_jadwal`
--

CREATE TABLE `generate_jadwal` (
  `id_jadwal` int(11) NOT NULL,
  `idperiode` int(11) NOT NULL,
  `nama_jurusan` varchar(255) NOT NULL,
  `nama_kelas` varchar(255) NOT NULL,
  `hari` varchar(255) NOT NULL,
  `jamke` int(11) NOT NULL,
  `nama_guru` varchar(255) NOT NULL,
  `mapel_ajar` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `generate_jadwal`
--

INSERT INTO `generate_jadwal` (`id_jadwal`, `idperiode`, `nama_jurusan`, `nama_kelas`, `hari`, `jamke`, `nama_guru`, `mapel_ajar`) VALUES
(1, 3, 'IPA', 'X-MIPA1', 'Senin', 1, 'NENI SUHARTINI, S.Pd, M.Psi', 'BK'),
(2, 3, 'IPA', 'X-MIPA2', 'Senin', 1, 'HADIAH, S.Pd.', 'Ekonomi'),
(3, 3, 'IPA', 'X-MIPA3', 'Senin', 1, 'TEGUH KOESTANTININGSIH, S.Pd', 'Keterampilan'),
(4, 3, 'IPS', 'X-IPS1', 'Senin', 1, 'Dra. ULUMIYAH', 'BKTI'),
(5, 3, 'IPS', 'X-IPS2', 'Senin', 1, 'MOHAMAD AFIF FARICHIN, M.Pd.I.', 'Muhadatsah'),
(6, 3, 'AGAMA', 'X-IAG', 'Senin', 1, 'ALIFIYAH RUSDIYANA, S.Pd.', 'Bahasa Inggris'),
(7, 3, 'IPA', 'XI-IPA 1', 'Senin', 1, 'WIJI LAELATUL JUMAH, S.Pd.', 'Bahasa Indonesia'),
(8, 3, 'IPA', 'XI-IPA 2', 'Senin', 1, 'Drs. ABAS SIMAN', 'Pendidikan Kewarganegaraan'),
(9, 3, 'IPS', 'XI-IPS 1', 'Senin', 1, 'NUR RAHMAWATI, S.Pd', 'Bhs & Sastra Ind'),
(10, 3, 'IPS', 'XI-IPS 2', 'Senin', 1, 'INSA ASYAROH, S.Ag', 'Al Quran Hadis'),
(11, 3, 'AGAMA', 'XI-AGAMA', 'Senin', 1, 'Drs. AKHMAD EFENDI', 'Teknologi Informasi Komunikasi'),
(12, 3, 'IPA', 'XII-IPA 1', 'Senin', 1, 'Drs. ABD. SALAM HS.', 'Fiqih'),
(13, 3, 'IPA', 'XII-IPA 2', 'Senin', 1, 'ALY FUADI, S.Pd.', 'Fisika'),
(14, 3, 'IPS', 'XII-IPS 1', 'Senin', 1, 'NASHRUL ULUM, S.Pd.', 'Sosiologi'),
(15, 3, 'IPS', 'XII-IPS 2', 'Senin', 1, 'EDDI HARIYADI, S,Pd.', 'Seni Budaya'),
(16, 3, 'AGAMA', 'XII-AGAMA', 'Senin', 1, 'SITI MARIA ULFAH, S.Pd.I', 'Ilmu Hadits'),
(17, 3, 'IPA', 'X-MIPA1', 'Senin', 2, 'Drs. YUDI SYAIFULLOH', 'Pendidikan Jasmani, ORKES'),
(18, 3, 'IPA', 'X-MIPA2', 'Senin', 2, 'Drs. MOKH. HASAN B., M.Pd.', 'Fisika'),
(19, 3, 'IPA', 'X-MIPA3', 'Senin', 2, 'NURUL AINI, S.Pd', 'Matematika'),
(20, 3, 'IPS', 'X-IPS1', 'Senin', 2, 'ARIF MUSTOFA, S.Ag., M.Pd.', 'Fiqih'),
(21, 3, 'IPS', 'X-IPS2', 'Senin', 2, 'MARDWI ASDIYANTO, M.Pd.I.', 'S K I'),
(22, 3, 'AGAMA', 'X-IAG', 'Senin', 2, 'TEGUH KOESTANTININGSIH, S.Pd', 'Keterampilan'),
(23, 3, 'IPA', 'XI-IPA 1', 'Senin', 2, 'Drs. ABAS SIMAN', 'Pendidikan Kewarganegaraan'),
(24, 3, 'IPA', 'XI-IPA 2', 'Senin', 2, 'TRI SUDIK WIYONO, S.Pd', 'Ekonomi'),
(25, 3, 'IPS', 'XI-IPS 1', 'Senin', 2, 'MOHAMAD AFIF FARICHIN, M.Pd.I.', 'Muhadatsah'),
(26, 3, 'IPS', 'XI-IPS 2', 'Senin', 2, 'EDDI HARIYADI, S,Pd.', 'Seni Budaya'),
(27, 3, 'AGAMA', 'XI-AGAMA', 'Senin', 2, 'ISMI MARIYAM, S.Pd.', 'Bhs & Sastra Ind'),
(28, 3, 'IPA', 'XII-IPA 1', 'Senin', 2, 'ISMI MARIYAM, S.Pd.', 'Bahasa Indonesia'),
(29, 3, 'IPA', 'XII-IPA 2', 'Senin', 2, 'INGRID ARIANY SAVITRI, S.Pd.', 'Biologi'),
(30, 3, 'IPS', 'XII-IPS 1', 'Senin', 2, 'Dra. SUWINARTI', 'Geografi'),
(31, 3, 'IPS', 'XII-IPS 2', 'Senin', 2, 'Drs. AKHMAD EFENDI', 'Teknologi Informasi Komunikasi'),
(32, 3, 'AGAMA', 'XII-AGAMA', 'Senin', 2, 'AHERI SUGIHARTONO, S.Th.I', 'Aqidah Akhlak'),
(33, 3, 'IPA', 'X-MIPA1', 'Senin', 3, 'Drs. AKHMAD EFENDI', 'Teknologi Informasi Komunikasi'),
(34, 3, 'IPA', 'X-MIPA2', 'Senin', 3, 'NUR RAHMAWATI, S.Pd', 'Bahasa Indonesia'),
(35, 3, 'IPA', 'X-MIPA3', 'Senin', 3, 'WIWIN SISWINARNI, S.Pd.', 'Pendidikan Kewarganegaraan'),
(36, 3, 'IPS', 'X-IPS1', 'Senin', 3, 'INSA ASYAROH, S.Ag', 'Al Quran Hadis'),
(37, 3, 'IPS', 'X-IPS2', 'Senin', 3, 'TRI SUDIK WIYONO, S.Pd', 'Ekonomi'),
(38, 3, 'AGAMA', 'X-IAG', 'Senin', 3, 'Drs. YUDI SYAIFULLOH', 'Pendidikan Jasmani, ORKES'),
(39, 3, 'IPA', 'XI-IPA 1', 'Senin', 3, 'YAYUK ISWATIN, S.Pd', 'Seni Budaya'),
(40, 3, 'IPA', 'XI-IPA 2', 'Senin', 3, 'MARIFA RIAMA, S.Pd.', 'Sejarah'),
(41, 3, 'IPS', 'XI-IPS 1', 'Senin', 3, 'AHERI SUGIHARTONO, S.Th.I', 'Aqidah Akhlak'),
(42, 3, 'IPS', 'XI-IPS 2', 'Senin', 3, 'NASHRUL ULUM, S.Pd.', 'S K I'),
(43, 3, 'AGAMA', 'XI-AGAMA', 'Senin', 3, 'NURUL AINI, S.Pd', 'Matematika'),
(44, 3, 'IPA', 'XII-IPA 1', 'Senin', 3, 'ARYS SUSANTO, M.Pd', 'Fisika'),
(45, 3, 'IPA', 'XII-IPA 2', 'Senin', 3, 'ENNI SUBCHANDINI, S.Pd', 'Kimia'),
(46, 3, 'IPS', 'XII-IPS 1', 'Senin', 3, 'Drs. ABD. SALAM HS.', 'Fiqih'),
(47, 3, 'IPS', 'XII-IPS 2', 'Senin', 3, 'AGUS SALIM, S.Pd.', 'Bahasa Inggris'),
(48, 3, 'AGAMA', 'XII-AGAMA', 'Senin', 3, 'UMAR FARUQ, S.Ag.', 'Ilmu Kalam'),
(49, 3, 'IPA', 'X-MIPA1', 'Senin', 4, 'HADIAH, S.Pd.', 'Ekonomi'),
(50, 3, 'IPA', 'X-MIPA2', 'Senin', 4, 'NENI SUHARTINI, S.Pd, M.Psi', 'BK'),
(51, 3, 'IPA', 'X-MIPA3', 'Senin', 4, 'ALIFIYAH RUSDIYANA, S.Pd.', 'Bahasa Inggris'),
(52, 3, 'IPS', 'X-IPS1', 'Senin', 4, 'MUHAMMAD SUWAR, S.Pd.I.', 'Bahasa Arab'),
(53, 3, 'IPS', 'X-IPS2', 'Senin', 4, 'USMAN, S.Pd.', 'Bahasa Indonesia'),
(54, 3, 'AGAMA', 'X-IAG', 'Senin', 4, 'EDDI HARIYADI, S,Pd.', 'Seni Budaya'),
(55, 3, 'IPA', 'XI-IPA 1', 'Senin', 4, 'Dra. MAZIDAH INAYATI', 'Matematika'),
(56, 3, 'IPA', 'XI-IPA 2', 'Senin', 4, 'INSA ASYAROH, S.Ag', 'Al Quran Hadis'),
(57, 3, 'IPS', 'XI-IPS 1', 'Senin', 4, 'MARDWI ASDIYANTO, M.Pd.I.', 'S K I'),
(58, 3, 'IPS', 'XI-IPS 2', 'Senin', 4, 'MOHAMAD AFIF FARICHIN, M.Pd.I.', 'Muhadatsah'),
(59, 3, 'AGAMA', 'XI-AGAMA', 'Senin', 4, 'ARIF MUSTOFA, S.Ag., M.Pd.', 'Ushul Fiqih'),
(60, 3, 'IPA', 'XII-IPA 1', 'Senin', 4, 'Drs. AKHMAD EFENDI', 'Teknologi Informasi Komunikasi'),
(61, 3, 'IPA', 'XII-IPA 2', 'Senin', 4, 'NUR JANAH, S.Pd', 'Keterampilan'),
(62, 3, 'IPS', 'XII-IPS 1', 'Senin', 4, 'Dra. ULUMIYAH', 'BKTI'),
(63, 3, 'IPS', 'XII-IPS 2', 'Senin', 4, 'Dra. SUWINARTI', 'Geografi'),
(64, 3, 'AGAMA', 'XII-AGAMA', 'Senin', 4, 'ISMI MARIYAM, S.Pd.', 'Bhs & Sastra Ind'),
(65, 3, 'IPA', 'X-MIPA1', 'Senin', 5, 'MURSALIN, ST, S.Pd', 'Matematika'),
(66, 3, 'IPA', 'X-MIPA2', 'Senin', 5, 'TEGUH KOESTANTININGSIH, S.Pd', 'Keterampilan'),
(67, 3, 'IPA', 'X-MIPA3', 'Senin', 5, 'MOCH. FARID WADJIDI Lc, S.Pd.', 'Biologi'),
(68, 3, 'IPS', 'X-IPS1', 'Senin', 5, 'MARDWI ASDIYANTO, M.Pd.I.', 'S K I'),
(69, 3, 'IPS', 'X-IPS2', 'Senin', 5, 'Drs. AKHMAD EFENDI', 'Teknologi Informasi Komunikasi'),
(70, 3, 'AGAMA', 'X-IAG', 'Senin', 5, 'Drs. ABD. SALAM HS.', 'Fiqih'),
(71, 3, 'IPA', 'XI-IPA 1', 'Senin', 5, 'ARYS SUSANTO, M.Pd', 'Fisika'),
(72, 3, 'IPA', 'XI-IPA 2', 'Senin', 5, 'Drs. ALI MUSTOFA, M.Pd', 'Geografi'),
(73, 3, 'IPS', 'XI-IPS 1', 'Senin', 5, 'Dra. ULUMIYAH', 'BKTI'),
(74, 3, 'IPS', 'XI-IPS 2', 'Senin', 5, 'AHERI SUGIHARTONO, S.Th.I', 'Aqidah Akhlak'),
(75, 3, 'AGAMA', 'XI-AGAMA', 'Senin', 5, 'ALIFIYAH RUSDIYANA, S.Pd.', 'Bahasa Inggris'),
(76, 3, 'IPA', 'XII-IPA 1', 'Senin', 5, 'Drs. ABAS SIMAN', 'Pendidikan Kewarganegaraan'),
(77, 3, 'IPA', 'XII-IPA 2', 'Senin', 5, 'NENI SUHARTINI, S.Pd, M.Psi', 'BK'),
(78, 3, 'IPS', 'XII-IPS 1', 'Senin', 5, 'EDDI HARIYADI, S,Pd.', 'Seni Budaya'),
(79, 3, 'IPS', 'XII-IPS 2', 'Senin', 5, 'NASHRUL ULUM, S.Pd.', 'Sosiologi'),
(80, 3, 'AGAMA', 'XII-AGAMA', 'Senin', 5, 'MOHAMAD AFIF FARICHIN, M.Pd.I.', 'Muhadatsah'),
(81, 3, 'IPA', 'X-MIPA1', 'Senin', 6, 'Drs. ALI MUSTOFA, M.Pd', 'Geografi'),
(82, 3, 'IPA', 'X-MIPA2', 'Senin', 6, 'MOCH. FARID WADJIDI Lc, S.Pd.', 'Biologi'),
(83, 3, 'IPA', 'X-MIPA3', 'Senin', 6, 'HANIM NURUL AINI, S.Pd.', 'Bahasa Indonesia'),
(84, 3, 'IPS', 'X-IPS1', 'Senin', 6, 'Drs. AKHMAD EFENDI', 'Teknologi Informasi Komunikasi'),
(85, 3, 'IPS', 'X-IPS2', 'Senin', 6, 'MUHAMMAD SUWAR, S.Pd.I.', 'Bahasa Arab'),
(86, 3, 'AGAMA', 'X-IAG', 'Senin', 6, 'WIWIN SISWINARNI, S.Pd.', 'Pendidikan Kewarganegaraan'),
(87, 3, 'IPA', 'XI-IPA 1', 'Senin', 6, 'ALIEF PURNOMO AJU, S.Pd.', 'Kimia'),
(88, 3, 'IPA', 'XI-IPA 2', 'Senin', 6, 'Drs. DENNY MF., S.Pd.', 'Fisika'),
(89, 3, 'IPS', 'XI-IPS 1', 'Senin', 6, 'ARIF MUSTOFA, S.Ag., M.Pd.', 'Fiqih'),
(90, 3, 'IPS', 'XI-IPS 2', 'Senin', 6, 'Drs. YUDI SYAIFULLOH', 'Pendidikan Jasmani, ORKES'),
(91, 3, 'AGAMA', 'XI-AGAMA', 'Senin', 6, 'NUR JANAH, S.Pd', 'Keterampilan'),
(92, 3, 'IPA', 'XII-IPA 1', 'Senin', 6, 'NURUL AINI, S.Pd', 'Matematika'),
(93, 3, 'IPA', 'XII-IPA 2', 'Senin', 6, 'MARIFA RIAMA, S.Pd.', 'Sejarah'),
(94, 3, 'IPS', 'XII-IPS 1', 'Senin', 6, 'NASHRUL ULUM, S.Pd.', 'S K I'),
(95, 3, 'IPS', 'XII-IPS 2', 'Senin', 6, 'Dra. ULUMIYAH', 'BKTI'),
(96, 3, 'AGAMA', 'XII-AGAMA', 'Senin', 6, 'AGUS SALIM, S.Pd.', 'Bahasa Inggris'),
(97, 3, 'IPA', 'X-MIPA1', 'Senin', 7, 'INGRID ARIANY SAVITRI, S.Pd.', 'Biologi'),
(98, 3, 'IPA', 'X-MIPA2', 'Senin', 7, 'ARI KUSUMAWATI, M.Pd', 'Matematika'),
(99, 3, 'IPA', 'X-MIPA3', 'Senin', 7, 'YUDHA KURNIAWAN, S.Pd.', 'Pendidikan Jasmani, ORKES'),
(100, 3, 'IPS', 'X-IPS1', 'Senin', 7, 'TRI SUDIK WIYONO, S.Pd', 'Ekonomi'),
(101, 3, 'IPS', 'X-IPS2', 'Senin', 7, 'SURAWAN, S.Pd.', 'Bahasa Inggris'),
(102, 3, 'AGAMA', 'X-IAG', 'Senin', 7, 'MARDWI ASDIYANTO, M.Pd.I.', 'Ilmu Tafsir'),
(103, 3, 'IPA', 'XI-IPA 1', 'Senin', 7, 'NUR JANAH, S.Pd', 'Keterampilan'),
(104, 3, 'IPA', 'XI-IPA 2', 'Senin', 7, 'ENNI SUBCHANDINI, S.Pd', 'Kimia'),
(105, 3, 'IPS', 'XI-IPS 1', 'Senin', 7, 'NASHRUL ULUM, S.Pd.', 'Sosiologi'),
(106, 3, 'IPS', 'XI-IPS 2', 'Senin', 7, 'WIJI LAELATUL JUMAH, S.Pd.', 'Bahasa Indonesia'),
(107, 3, 'AGAMA', 'XI-AGAMA', 'Senin', 7, 'NENI SUHARTINI, S.Pd, M.Psi', 'BK'),
(108, 3, 'IPA', 'XII-IPA 1', 'Senin', 7, 'Dra. SUWINARTI', 'Geografi'),
(109, 3, 'IPA', 'XII-IPA 2', 'Senin', 7, 'MOHAMAD AFIF FARICHIN, M.Pd.I.', 'Muhadatsah'),
(110, 3, 'IPS', 'XII-IPS 1', 'Senin', 7, 'MUHAMMAD SUWAR, S.Pd.I.', 'Bahasa Arab'),
(111, 3, 'IPS', 'XII-IPS 2', 'Senin', 7, 'MARDWI ASDIYANTO, M.Pd.I.', 'S K I'),
(112, 3, 'AGAMA', 'XII-AGAMA', 'Senin', 7, 'ARIF MUSTOFA, S.Ag., M.Pd.', 'Fiqih'),
(113, 3, 'IPA', 'X-MIPA1', 'Senin', 8, 'INSA ASYAROH, S.Ag', 'Al Quran Hadis'),
(114, 3, 'IPA', 'X-MIPA2', 'Senin', 8, 'MARIFA RIAMA, S.Pd.', 'Sejarah'),
(115, 3, 'IPA', 'X-MIPA3', 'Senin', 8, 'ALIEF PURNOMO AJU, S.Pd.', 'Kimia'),
(116, 3, 'IPS', 'X-IPS1', 'Senin', 8, 'Drs. ABAS SIMAN', 'Pendidikan Kewarganegaraan'),
(117, 3, 'IPS', 'X-IPS2', 'Senin', 8, 'EDDI HARIYADI, S,Pd.', 'Seni Budaya'),
(118, 3, 'AGAMA', 'X-IAG', 'Senin', 8, 'Drs. AKHMAD EFENDI', 'Teknologi Informasi Komunikasi'),
(119, 3, 'IPA', 'XI-IPA 1', 'Senin', 8, 'HADIAH, S.Pd.', 'Ekonomi'),
(120, 3, 'IPA', 'XI-IPA 2', 'Senin', 8, 'INGRID ARIANY SAVITRI, S.Pd.', 'Biologi'),
(121, 3, 'IPS', 'XI-IPS 1', 'Senin', 8, 'WIJI LAELATUL JUMAH, S.Pd.', 'Bahasa Indonesia'),
(122, 3, 'IPS', 'XI-IPS 2', 'Senin', 8, 'SURAWAN, S.Pd.', 'Bahasa Inggris'),
(123, 3, 'AGAMA', 'XI-AGAMA', 'Senin', 8, 'UMAR FARUQ, S.Ag.', 'Ilmu Kalam'),
(124, 3, 'IPA', 'XII-IPA 1', 'Senin', 8, 'YUDHA KURNIAWAN, S.Pd.', 'Pendidikan Jasmani, ORKES'),
(125, 3, 'IPA', 'XII-IPA 2', 'Senin', 8, 'ARIF MUSTOFA, S.Ag., M.Pd.', 'Fiqih'),
(126, 3, 'IPS', 'XII-IPS 1', 'Senin', 8, 'NUR RAHMAWATI, S.Pd', 'Bhs & Sastra Ind'),
(127, 3, 'IPS', 'XII-IPS 2', 'Senin', 8, 'MOHAMAD AFIF FARICHIN, M.Pd.I.', 'Muhadatsah'),
(128, 3, 'AGAMA', 'XII-AGAMA', 'Senin', 8, 'MARDWI ASDIYANTO, M.Pd.I.', 'Ilmu Tafsir'),
(129, 3, 'IPA', 'X-MIPA1', 'Senin', 9, 'HANIM NURUL AINI, S.Pd.', 'Bahasa Indonesia'),
(130, 3, 'IPA', 'X-MIPA2', 'Senin', 9, 'INSA ASYAROH, S.Ag', 'Al Quran Hadis'),
(131, 3, 'IPA', 'X-MIPA3', 'Senin', 9, 'YAYUK ISWATIN, S.Pd', 'Seni Budaya'),
(132, 3, 'IPS', 'X-IPS1', 'Senin', 9, 'AGUS SALIM, S.Pd.', 'Bahasa Inggris'),
(133, 3, 'IPS', 'X-IPS2', 'Senin', 9, 'Drs. ABAS SIMAN', 'Pendidikan Kewarganegaraan'),
(134, 3, 'AGAMA', 'X-IAG', 'Senin', 9, 'ISMI MARIYAM, S.Pd.', 'Bhs & Sastra Ind'),
(135, 3, 'IPA', 'XI-IPA 1', 'Senin', 9, 'Drs. ALI MUSTOFA, M.Pd', 'Geografi'),
(136, 3, 'IPA', 'XI-IPA 2', 'Senin', 9, 'MUHAMMAD SUWAR, S.Pd.I.', 'Bahasa Arab'),
(137, 3, 'IPS', 'XI-IPS 1', 'Senin', 9, 'FATUKHA, S.Pd.', 'Matematika'),
(138, 3, 'IPS', 'XI-IPS 2', 'Senin', 9, 'TEGUH KOESTANTININGSIH, S.Pd', 'Keterampilan'),
(139, 3, 'AGAMA', 'XI-AGAMA', 'Senin', 9, 'MARDWI ASDIYANTO, M.Pd.I.', 'Ilmu Tafsir'),
(140, 3, 'IPA', 'XII-IPA 1', 'Senin', 9, 'ALIEF PURNOMO AJU, S.Pd.', 'Kimia'),
(141, 3, 'IPA', 'XII-IPA 2', 'Senin', 9, 'HADIAH, S.Pd.', 'Ekonomi'),
(142, 3, 'IPS', 'XII-IPS 1', 'Senin', 9, 'MARIFA RIAMA, S.Pd.', 'Sejarah'),
(143, 3, 'IPS', 'XII-IPS 2', 'Senin', 9, 'Drs. YUDI SYAIFULLOH', 'Pendidikan Jasmani, ORKES'),
(144, 3, 'AGAMA', 'XII-AGAMA', 'Senin', 9, 'Dra. ULUMIYAH', 'BKTI'),
(145, 3, 'IPA', 'X-MIPA1', 'Senin', 10, 'ALIFIYAH RUSDIYANA, S.Pd.', 'Bahasa Inggris'),
(146, 3, 'IPA', 'X-MIPA2', 'Senin', 10, 'ARIF MUSTOFA, S.Ag., M.Pd.', 'Fiqih'),
(147, 3, 'IPA', 'X-MIPA3', 'Senin', 10, 'HADIAH, S.Pd.', 'Ekonomi'),
(148, 3, 'IPS', 'X-IPS1', 'Senin', 10, 'USMAN, S.Pd.', 'Bahasa Indonesia'),
(149, 3, 'IPS', 'X-IPS2', 'Senin', 10, 'Drs. YUDI SYAIFULLOH', 'Pendidikan Jasmani, ORKES'),
(150, 3, 'AGAMA', 'X-IAG', 'Senin', 10, 'MURSALIN, ST, S.Pd', 'Matematika'),
(151, 3, 'IPA', 'XI-IPA 1', 'Senin', 10, 'INGRID ARIANY SAVITRI, S.Pd.', 'Biologi'),
(152, 3, 'IPA', 'XI-IPA 2', 'Senin', 10, 'NENI SUHARTINI, S.Pd, M.Psi', 'BK'),
(153, 3, 'IPS', 'XI-IPS 1', 'Senin', 10, 'MUHAMMAD SUWAR, S.Pd.I.', 'Bahasa Arab'),
(154, 3, 'IPS', 'XI-IPS 2', 'Senin', 10, 'Dra. ULUMIYAH', 'BKTI'),
(155, 3, 'AGAMA', 'XI-AGAMA', 'Senin', 10, 'Drs. ABAS SIMAN', 'Pendidikan Kewarganegaraan'),
(156, 3, 'IPA', 'XII-IPA 1', 'Senin', 10, 'TEGUH KOESTANTININGSIH, S.Pd', 'Keterampilan'),
(157, 3, 'IPA', 'XII-IPA 2', 'Senin', 10, 'Drs. AKHMAD EFENDI', 'Teknologi Informasi Komunikasi'),
(158, 3, 'IPS', 'XII-IPS 1', 'Senin', 10, 'MOHAMAD AFIF FARICHIN, M.Pd.I.', 'Muhadatsah'),
(159, 3, 'IPS', 'XII-IPS 2', 'Senin', 10, 'INSA ASYAROH, S.Ag', 'Al Quran Hadis'),
(160, 3, 'AGAMA', 'XII-AGAMA', 'Senin', 10, 'MARIFA RIAMA, S.Pd.', 'Sejarah'),
(161, 3, 'IPA', 'X-MIPA1', 'Selasa', 1, 'Drs. DENNY MF., S.Pd.', 'Fisika'),
(162, 3, 'IPA', 'X-MIPA2', 'Selasa', 1, 'MOHAMAD AFIF FARICHIN, M.Pd.I.', 'Muhadatsah'),
(163, 3, 'IPA', 'X-MIPA3', 'Selasa', 1, 'WIJI LAELATUL JUMAH, S.Pd.', 'Bahasa Indonesia'),
(164, 3, 'IPS', 'X-IPS1', 'Selasa', 1, 'HADIAH, S.Pd.', 'Ekonomi'),
(165, 3, 'IPS', 'X-IPS2', 'Selasa', 1, 'WIWIN SISWINARNI, S.Pd.', 'Pendidikan Kewarganegaraan'),
(166, 3, 'AGAMA', 'X-IAG', 'Selasa', 1, 'Dra. AGUS SETYANINGSIH, M.Si', 'Matematika'),
(167, 3, 'IPA', 'XI-IPA 1', 'Selasa', 1, 'Dra. ULUMIYAH', 'BKTI'),
(168, 3, 'IPA', 'XI-IPA 2', 'Selasa', 1, 'Dra. SUWINARTI', 'Geografi'),
(169, 3, 'IPS', 'XI-IPS 1', 'Selasa', 1, 'YAYUK ISWATIN, S.Pd', 'Seni Budaya'),
(170, 3, 'IPS', 'XI-IPS 2', 'Selasa', 1, 'INSA ASYAROH, S.Ag', 'Al Quran Hadis'),
(171, 3, 'AGAMA', 'XI-AGAMA', 'Selasa', 1, 'NUR RAHMAWATI, S.Pd', 'Bhs & Sastra Ind'),
(172, 3, 'IPA', 'XII-IPA 1', 'Selasa', 1, 'MUHAMMAD SUWAR, S.Pd.I.', 'Bahasa Arab'),
(173, 3, 'IPA', 'XII-IPA 2', 'Selasa', 1, 'Drs. AKHMAD EFENDI', 'Teknologi Informasi Komunikasi'),
(174, 3, 'IPS', 'XII-IPS 1', 'Selasa', 1, 'NASHRUL ULUM, S.Pd.', 'S K I'),
(175, 3, 'IPS', 'XII-IPS 2', 'Selasa', 1, 'NASHRUL ULUM, S.Pd.', 'Sosiologi'),
(176, 3, 'AGAMA', 'XII-AGAMA', 'Selasa', 1, 'ARIF MUSTOFA, S.Ag., M.Pd.', 'Fiqih'),
(177, 3, 'IPA', 'X-MIPA1', 'Selasa', 2, 'YUDHA KURNIAWAN, S.Pd.', 'Pendidikan Jasmani, ORKES'),
(178, 3, 'IPA', 'X-MIPA2', 'Selasa', 2, 'EDDI HARIYADI, S,Pd.', 'Seni Budaya'),
(179, 3, 'IPA', 'X-MIPA3', 'Selasa', 2, 'TRI SUDIK WIYONO, S.Pd', 'Ekonomi'),
(180, 3, 'IPS', 'X-IPS1', 'Selasa', 2, 'Dra. AGUS SETYANINGSIH, M.Si', 'Matematika'),
(181, 3, 'IPS', 'X-IPS2', 'Selasa', 2, 'Drs. AKHMAD EFENDI', 'Teknologi Informasi Komunikasi'),
(182, 3, 'AGAMA', 'X-IAG', 'Selasa', 2, 'TEGUH KOESTANTININGSIH, S.Pd', 'Keterampilan'),
(183, 3, 'IPA', 'XI-IPA 1', 'Selasa', 2, 'MOHAMAD AFIF FARICHIN, M.Pd.I.', 'Muhadatsah'),
(184, 3, 'IPA', 'XI-IPA 2', 'Selasa', 2, 'Drs. DENNY MF., S.Pd.', 'Fisika'),
(185, 3, 'IPS', 'XI-IPS 1', 'Selasa', 2, 'Drs. ABD. SALAM HS.', 'Fiqih'),
(186, 3, 'IPS', 'XI-IPS 2', 'Selasa', 2, 'NASHRUL ULUM, S.Pd.', 'S K I'),
(187, 3, 'AGAMA', 'XI-AGAMA', 'Selasa', 2, 'SITI MARIA ULFAH, S.Pd.I', 'Ilmu Hadits'),
(188, 3, 'IPA', 'XII-IPA 1', 'Selasa', 2, 'ENNI SUBCHANDINI, S.Pd', 'Kimia'),
(189, 3, 'IPA', 'XII-IPA 2', 'Selasa', 2, 'INGRID ARIANY SAVITRI, S.Pd.', 'Biologi'),
(190, 3, 'IPS', 'XII-IPS 1', 'Selasa', 2, 'Dra. SUWINARTI', 'Geografi'),
(191, 3, 'IPS', 'XII-IPS 2', 'Selasa', 2, 'INSA ASYAROH, S.Ag', 'Al Quran Hadis'),
(192, 3, 'AGAMA', 'XII-AGAMA', 'Selasa', 2, 'MARDWI ASDIYANTO, M.Pd.I.', 'Ilmu Tafsir'),
(193, 3, 'IPA', 'X-MIPA1', 'Selasa', 3, 'Dra. AGUS SETYANINGSIH, M.Si', 'Matematika'),
(194, 3, 'IPA', 'X-MIPA2', 'Selasa', 3, 'INGRID ARIANY SAVITRI, S.Pd.', 'Biologi'),
(195, 3, 'IPA', 'X-MIPA3', 'Selasa', 3, 'Drs. ABAS SIMAN', 'Pendidikan Kewarganegaraan'),
(196, 3, 'IPS', 'X-IPS1', 'Selasa', 3, 'TEGUH KOESTANTININGSIH, S.Pd', 'Keterampilan'),
(197, 3, 'IPS', 'X-IPS2', 'Selasa', 3, 'MUHAMMAD SUWAR, S.Pd.I.', 'Bahasa Arab'),
(198, 3, 'AGAMA', 'X-IAG', 'Selasa', 3, 'MARIFA RIAMA, S.Pd.', 'Sejarah'),
(199, 3, 'IPA', 'XI-IPA 1', 'Selasa', 3, 'Drs. MOKH. HASAN B., M.Pd.', 'Fisika'),
(200, 3, 'IPA', 'XI-IPA 2', 'Selasa', 3, 'MOHAMAD AFIF FARICHIN, M.Pd.I.', 'Muhadatsah'),
(201, 3, 'IPS', 'XI-IPS 1', 'Selasa', 3, 'Dra. ULUMIYAH', 'BKTI'),
(202, 3, 'IPS', 'XI-IPS 2', 'Selasa', 3, 'ISMI MARIYAM, S.Pd.', 'Bhs & Sastra Ind'),
(203, 3, 'AGAMA', 'XI-AGAMA', 'Selasa', 3, 'Drs. AKHMAD EFENDI', 'Teknologi Informasi Komunikasi'),
(204, 3, 'IPA', 'XII-IPA 1', 'Selasa', 3, 'HANIM NURUL AINI, S.Pd.', 'Bahasa Indonesia'),
(205, 3, 'IPA', 'XII-IPA 2', 'Selasa', 3, 'ALIFIYAH RUSDIYANA, S.Pd.', 'Bahasa Inggris'),
(206, 3, 'IPS', 'XII-IPS 1', 'Selasa', 3, 'ARIF MUSTOFA, S.Ag., M.Pd.', 'Fiqih'),
(207, 3, 'IPS', 'XII-IPS 2', 'Selasa', 3, 'EDDI HARIYADI, S,Pd.', 'Seni Budaya'),
(208, 3, 'AGAMA', 'XII-AGAMA', 'Selasa', 3, 'YUDHA KURNIAWAN, S.Pd.', 'Pendidikan Jasmani, ORKES'),
(209, 3, 'IPA', 'X-MIPA1', 'Selasa', 4, 'ARIF MUSTOFA, S.Ag., M.Pd.', 'Fiqih'),
(210, 3, 'IPA', 'X-MIPA2', 'Selasa', 4, 'SURAWAN, S.Pd.', 'Kimia'),
(211, 3, 'IPA', 'X-MIPA3', 'Selasa', 4, 'YAYUK ISWATIN, S.Pd', 'Seni Budaya'),
(212, 3, 'IPS', 'X-IPS1', 'Selasa', 4, 'NASHRUL ULUM, S.Pd.', 'Sosiologi'),
(213, 3, 'IPS', 'X-IPS2', 'Selasa', 4, 'INSA ASYAROH, S.Ag', 'Al Quran Hadis'),
(214, 3, 'AGAMA', 'X-IAG', 'Selasa', 4, 'MUHAMMAD SUWAR, S.Pd.I.', 'Bahasa Arab'),
(215, 3, 'IPA', 'XI-IPA 1', 'Selasa', 4, 'WIJI LAELATUL JUMAH, S.Pd.', 'Bahasa Indonesia'),
(216, 3, 'IPA', 'XI-IPA 2', 'Selasa', 4, 'Dra. ULUMIYAH', 'BKTI'),
(217, 3, 'IPS', 'XI-IPS 1', 'Selasa', 4, 'AGUS SALIM, S.Pd.', 'Bahasa Inggris'),
(218, 3, 'IPS', 'XI-IPS 2', 'Selasa', 4, 'FATUKHA, S.Pd.', 'Matematika'),
(219, 3, 'AGAMA', 'XI-AGAMA', 'Selasa', 4, 'YUDHA KURNIAWAN, S.Pd.', 'Pendidikan Jasmani, ORKES'),
(220, 3, 'IPA', 'XII-IPA 1', 'Selasa', 4, 'WIWIN SISWINARNI, S.Pd.', 'Pendidikan Kewarganegaraan'),
(221, 3, 'IPA', 'XII-IPA 2', 'Selasa', 4, 'AHERI SUGIHARTONO, S.Th.I', 'Aqidah Akhlak'),
(222, 3, 'IPS', 'XII-IPS 1', 'Selasa', 4, 'ISMI MARIYAM, S.Pd.', 'Bhs & Sastra Ind'),
(223, 3, 'IPS', 'XII-IPS 2', 'Selasa', 4, 'Dra. SUWINARTI', 'Geografi'),
(224, 3, 'AGAMA', 'XII-AGAMA', 'Selasa', 4, 'MOHAMAD AFIF FARICHIN, M.Pd.I.', 'Muhadatsah'),
(225, 3, 'IPA', 'X-MIPA1', 'Selasa', 5, 'ISMI MARIYAM, S.Pd.', 'Bahasa Indonesia'),
(226, 3, 'IPA', 'X-MIPA2', 'Selasa', 5, 'Drs. AKHMAD EFENDI', 'Teknologi Informasi Komunikasi'),
(227, 3, 'IPA', 'X-MIPA3', 'Selasa', 5, 'Dra. SUWINARTI', 'Geografi'),
(228, 3, 'IPS', 'X-IPS1', 'Selasa', 5, 'MARDWI ASDIYANTO, M.Pd.I.', 'S K I'),
(229, 3, 'IPS', 'X-IPS2', 'Selasa', 5, 'MARIFA RIAMA, S.Pd.', 'Sejarah'),
(230, 3, 'AGAMA', 'X-IAG', 'Selasa', 5, 'YUDHA KURNIAWAN, S.Pd.', 'Pendidikan Jasmani, ORKES'),
(231, 3, 'IPA', 'XI-IPA 1', 'Selasa', 5, 'SURAWAN, S.Pd.', 'Kimia'),
(232, 3, 'IPA', 'XI-IPA 2', 'Selasa', 5, 'INGRID ARIANY SAVITRI, S.Pd.', 'Biologi'),
(233, 3, 'IPS', 'XI-IPS 1', 'Selasa', 5, 'AHERI SUGIHARTONO, S.Th.I', 'Aqidah Akhlak'),
(234, 3, 'IPS', 'XI-IPS 2', 'Selasa', 5, 'YAYUK ISWATIN, S.Pd', 'Seni Budaya'),
(235, 3, 'AGAMA', 'XI-AGAMA', 'Selasa', 5, 'Drs. ABD. SALAM HS.', 'Fiqih'),
(236, 3, 'IPA', 'XII-IPA 1', 'Selasa', 5, 'ARI KUSUMAWATI, M.Pd', 'Matematika'),
(237, 3, 'IPA', 'XII-IPA 2', 'Selasa', 5, 'MOHAMAD AFIF FARICHIN, M.Pd.I.', 'Muhadatsah'),
(238, 3, 'IPS', 'XII-IPS 1', 'Selasa', 5, 'TEGUH KOESTANTININGSIH, S.Pd', 'Keterampilan'),
(239, 3, 'IPS', 'XII-IPS 2', 'Selasa', 5, 'AGUS SALIM, S.Pd.', 'Bahasa Inggris'),
(240, 3, 'AGAMA', 'XII-AGAMA', 'Selasa', 5, 'Drs. ABAS SIMAN', 'Pendidikan Kewarganegaraan'),
(241, 3, 'IPA', 'X-MIPA1', 'Selasa', 6, 'MARDWI ASDIYANTO, M.Pd.I.', 'S K I'),
(242, 3, 'IPA', 'X-MIPA2', 'Selasa', 6, 'ISMI MARIYAM, S.Pd.', 'Bahasa Indonesia'),
(243, 3, 'IPA', 'X-MIPA3', 'Selasa', 6, 'YUDHA KURNIAWAN, S.Pd.', 'Pendidikan Jasmani, ORKES'),
(244, 3, 'IPS', 'X-IPS1', 'Selasa', 6, 'YAYUK ISWATIN, S.Pd', 'Seni Budaya'),
(245, 3, 'IPS', 'X-IPS2', 'Selasa', 6, 'Drs. ALI MUSTOFA, M.Pd', 'Geografi'),
(246, 3, 'AGAMA', 'X-IAG', 'Selasa', 6, 'AGUS SALIM, S.Pd.', 'Bahasa Inggris'),
(247, 3, 'IPA', 'XI-IPA 1', 'Selasa', 6, 'ARIF MUSTOFA, S.Ag., M.Pd.', 'Fiqih'),
(248, 3, 'IPA', 'XI-IPA 2', 'Selasa', 6, 'Dra. MAZIDAH INAYATI', 'Matematika'),
(249, 3, 'IPS', 'XI-IPS 1', 'Selasa', 6, 'MOHAMAD AFIF FARICHIN, M.Pd.I.', 'Muhadatsah'),
(250, 3, 'IPS', 'XI-IPS 2', 'Selasa', 6, 'Drs. AKHMAD EFENDI', 'Teknologi Informasi Komunikasi'),
(251, 3, 'AGAMA', 'XI-AGAMA', 'Selasa', 6, 'TEGUH KOESTANTININGSIH, S.Pd', 'Keterampilan'),
(252, 3, 'IPA', 'XII-IPA 1', 'Selasa', 6, 'Drs. DENNY MF., S.Pd.', 'Fisika'),
(253, 3, 'IPA', 'XII-IPA 2', 'Selasa', 6, 'SURAWAN, S.Pd.', 'Kimia'),
(254, 3, 'IPS', 'XII-IPS 1', 'Selasa', 6, 'Dra. ULUMIYAH', 'BKTI'),
(255, 3, 'IPS', 'XII-IPS 2', 'Selasa', 6, 'ISMI MARIYAM, S.Pd.', 'Bhs & Sastra Ind'),
(256, 3, 'AGAMA', 'XII-AGAMA', 'Selasa', 6, 'ARIF MUSTOFA, S.Ag., M.Pd.', 'Ushul Fiqih'),
(257, 3, 'IPA', 'X-MIPA1', 'Selasa', 7, 'MOCH. FARID WADJIDI Lc, S.Pd.', 'Biologi'),
(258, 3, 'IPA', 'X-MIPA2', 'Selasa', 7, 'ARYS SUSANTO, M.Pd', 'Fisika'),
(259, 3, 'IPA', 'X-MIPA3', 'Selasa', 7, 'INSA ASYAROH, S.Ag', 'Al Quran Hadis'),
(260, 3, 'IPS', 'X-IPS1', 'Selasa', 7, 'WIJI LAELATUL JUMAH, S.Pd.', 'Bahasa Indonesia'),
(261, 3, 'IPS', 'X-IPS2', 'Selasa', 7, 'EDDI HARIYADI, S,Pd.', 'Seni Budaya'),
(262, 3, 'AGAMA', 'X-IAG', 'Selasa', 7, 'ISMI MARIYAM, S.Pd.', 'Bhs & Sastra Ind'),
(263, 3, 'IPA', 'XI-IPA 1', 'Selasa', 7, 'MUHAMMAD SUWAR, S.Pd.I.', 'Bahasa Arab'),
(264, 3, 'IPA', 'XI-IPA 2', 'Selasa', 7, 'YUDHA KURNIAWAN, S.Pd.', 'Pendidikan Jasmani, ORKES'),
(265, 3, 'IPS', 'XI-IPS 1', 'Selasa', 7, 'MARDWI ASDIYANTO, M.Pd.I.', 'S K I'),
(266, 3, 'IPS', 'XI-IPS 2', 'Selasa', 7, 'ARIF MUSTOFA, S.Ag., M.Pd.', 'Fiqih'),
(267, 3, 'AGAMA', 'XI-AGAMA', 'Selasa', 7, 'MOHAMAD AFIF FARICHIN, M.Pd.I.', 'Muhadatsah'),
(268, 3, 'IPA', 'XII-IPA 1', 'Selasa', 7, 'SURAWAN, S.Pd.', 'Bahasa Inggris'),
(269, 3, 'IPA', 'XII-IPA 2', 'Selasa', 7, 'WIWIN SISWINARNI, S.Pd.', 'Pendidikan Kewarganegaraan'),
(270, 3, 'IPS', 'XII-IPS 1', 'Selasa', 7, 'FATUKHA, S.Pd.', 'Matematika'),
(271, 3, 'IPS', 'XII-IPS 2', 'Selasa', 7, 'TRI SUDIK WIYONO, S.Pd', 'Ekonomi'),
(272, 3, 'AGAMA', 'XII-AGAMA', 'Selasa', 7, 'MARIFA RIAMA, S.Pd.', 'Sejarah'),
(273, 3, 'IPA', 'X-MIPA1', 'Selasa', 8, 'AHERI SUGIHARTONO, S.Th.I', 'Aqidah Akhlak'),
(274, 3, 'IPA', 'X-MIPA2', 'Selasa', 8, 'HADIAH, S.Pd.', 'Ekonomi'),
(275, 3, 'IPA', 'X-MIPA3', 'Selasa', 8, 'MURSALIN, ST, S.Pd', 'Matematika'),
(276, 3, 'IPS', 'X-IPS1', 'Selasa', 8, 'WIWIN SISWINARNI, S.Pd.', 'Pendidikan Kewarganegaraan'),
(277, 3, 'IPS', 'X-IPS2', 'Selasa', 8, 'SURAWAN, S.Pd.', 'Bahasa Inggris'),
(278, 3, 'AGAMA', 'X-IAG', 'Selasa', 8, 'MOHAMAD AFIF FARICHIN, M.Pd.I.', 'Muhadatsah'),
(279, 3, 'IPA', 'XI-IPA 1', 'Selasa', 8, 'ANITA KURNIA RAHAYU, S.P.', 'Biologi'),
(280, 3, 'IPA', 'XI-IPA 2', 'Selasa', 8, 'EDDI HARIYADI, S,Pd.', 'Seni Budaya'),
(281, 3, 'IPS', 'XI-IPS 1', 'Selasa', 8, 'TEGUH KOESTANTININGSIH, S.Pd', 'Keterampilan'),
(282, 3, 'IPS', 'XI-IPS 2', 'Selasa', 8, 'Dra. ULUMIYAH', 'BKTI'),
(283, 3, 'AGAMA', 'XI-AGAMA', 'Selasa', 8, 'Drs. ABD. SALAM HS.', 'Ushul Fiqih'),
(284, 3, 'IPA', 'XII-IPA 1', 'Selasa', 8, 'NENI SUHARTINI, S.Pd, M.Psi', 'BK'),
(285, 3, 'IPA', 'XII-IPA 2', 'Selasa', 8, 'MARDWI ASDIYANTO, M.Pd.I.', 'S K I'),
(286, 3, 'IPS', 'XII-IPS 1', 'Selasa', 8, 'MARIFA RIAMA, S.Pd.', 'Sejarah'),
(287, 3, 'IPS', 'XII-IPS 2', 'Selasa', 8, 'MUHAMMAD SUWAR, S.Pd.I.', 'Bahasa Arab'),
(288, 3, 'AGAMA', 'XII-AGAMA', 'Selasa', 8, 'Drs. AKHMAD EFENDI', 'Teknologi Informasi Komunikasi'),
(289, 3, 'IPA', 'X-MIPA1', 'Selasa', 9, 'Drs. ABAS SIMAN', 'Pendidikan Kewarganegaraan'),
(290, 3, 'IPA', 'X-MIPA2', 'Selasa', 9, 'Dra. MAZIDAH INAYATI', 'Matematika'),
(291, 3, 'IPA', 'X-MIPA3', 'Selasa', 9, 'MARIFA RIAMA, S.Pd.', 'Sejarah'),
(292, 3, 'IPS', 'X-IPS1', 'Selasa', 9, 'ISMI MARIYAM, S.Pd.', 'Bhs & Sastra Ind'),
(293, 3, 'IPS', 'X-IPS2', 'Selasa', 9, 'Dra. ULUMIYAH', 'BKTI'),
(294, 3, 'AGAMA', 'X-IAG', 'Selasa', 9, 'MARDWI ASDIYANTO, M.Pd.I.', 'Ilmu Tafsir'),
(295, 3, 'IPA', 'XI-IPA 1', 'Selasa', 9, 'Drs. YUDI SYAIFULLOH', 'Pendidikan Jasmani, ORKES'),
(296, 3, 'IPA', 'XI-IPA 2', 'Selasa', 9, 'ISMI MARIYAM, S.Pd.', 'Bahasa Indonesia'),
(297, 3, 'IPS', 'XI-IPS 1', 'Selasa', 9, 'TRI SUDIK WIYONO, S.Pd', 'Ekonomi'),
(298, 3, 'IPS', 'XI-IPS 2', 'Selasa', 9, 'Dra. SUWINARTI', 'Geografi'),
(299, 3, 'AGAMA', 'XI-AGAMA', 'Selasa', 9, 'SURAWAN, S.Pd.', 'Bahasa Inggris'),
(300, 3, 'IPA', 'XII-IPA 1', 'Selasa', 9, 'NUR JANAH, S.Pd', 'Keterampilan'),
(301, 3, 'IPA', 'XII-IPA 2', 'Selasa', 9, 'EDDI HARIYADI, S,Pd.', 'Seni Budaya'),
(302, 3, 'IPS', 'XII-IPS 1', 'Selasa', 9, 'AHERI SUGIHARTONO, S.Th.I', 'Aqidah Akhlak'),
(303, 3, 'IPS', 'XII-IPS 2', 'Selasa', 9, 'Drs. ABD. SALAM HS.', 'Fiqih'),
(304, 3, 'AGAMA', 'XII-AGAMA', 'Selasa', 9, 'UMAR FARUQ, S.Ag.', 'Ilmu Kalam'),
(305, 3, 'IPA', 'X-MIPA1', 'Selasa', 10, 'ALIFIYAH RUSDIYANA, S.Pd.', 'Bahasa Inggris'),
(306, 3, 'IPA', 'X-MIPA2', 'Selasa', 10, 'Dra. SUWINARTI', 'Geografi'),
(307, 3, 'IPA', 'X-MIPA3', 'Selasa', 10, 'Drs. DENNY MF., S.Pd.', 'Fisika'),
(308, 3, 'IPS', 'X-IPS1', 'Selasa', 10, 'Drs. YUDI SYAIFULLOH', 'Pendidikan Jasmani, ORKES'),
(309, 3, 'IPS', 'X-IPS2', 'Selasa', 10, 'NASHRUL ULUM, S.Pd.', 'S K I'),
(310, 3, 'AGAMA', 'X-IAG', 'Selasa', 10, 'Dra. ULUMIYAH', 'BKTI'),
(311, 3, 'IPA', 'XI-IPA 1', 'Selasa', 10, 'NURUL AINI, S.Pd', 'Matematika'),
(312, 3, 'IPA', 'XI-IPA 2', 'Selasa', 10, 'WIWIN SISWINARNI, S.Pd.', 'Pendidikan Kewarganegaraan'),
(313, 3, 'IPS', 'XI-IPS 1', 'Selasa', 10, 'WIJI LAELATUL JUMAH, S.Pd.', 'Bahasa Indonesia'),
(314, 3, 'IPS', 'XI-IPS 2', 'Selasa', 10, 'AHERI SUGIHARTONO, S.Th.I', 'Aqidah Akhlak'),
(315, 3, 'AGAMA', 'XI-AGAMA', 'Selasa', 10, 'EDDI HARIYADI, S,Pd.', 'Seni Budaya'),
(316, 3, 'IPA', 'XII-IPA 1', 'Selasa', 10, 'MOHAMAD AFIF FARICHIN, M.Pd.I.', 'Muhadatsah'),
(317, 3, 'IPA', 'XII-IPA 2', 'Selasa', 10, 'ARIF MUSTOFA, S.Ag., M.Pd.', 'Fiqih'),
(318, 3, 'IPS', 'XII-IPS 1', 'Selasa', 10, 'NASHRUL ULUM, S.Pd.', 'Sosiologi'),
(319, 3, 'IPS', 'XII-IPS 2', 'Selasa', 10, 'TEGUH KOESTANTININGSIH, S.Pd', 'Keterampilan'),
(320, 3, 'AGAMA', 'XII-AGAMA', 'Selasa', 10, 'MOHAMAD AFIF FARICHIN, M.Pd.I.', 'Bahasa Arab'),
(321, 3, 'IPA', 'X-MIPA1', 'Rabu', 1, 'WIJI LAELATUL JUMAH, S.Pd.', 'Bahasa Indonesia'),
(322, 3, 'IPA', 'X-MIPA2', 'Rabu', 1, 'YAYUK ISWATIN, S.Pd', 'Seni Budaya'),
(323, 3, 'IPA', 'X-MIPA3', 'Rabu', 1, 'Drs. ABD. SALAM HS.', 'Fiqih'),
(324, 3, 'IPS', 'X-IPS1', 'Rabu', 1, 'INSA ASYAROH, S.Ag', 'Al Quran Hadis'),
(325, 3, 'IPS', 'X-IPS2', 'Rabu', 1, 'Dra. ULUMIYAH', 'BKTI'),
(326, 3, 'AGAMA', 'X-IAG', 'Rabu', 1, 'NUR JANAH, S.Pd', 'Keterampilan'),
(327, 3, 'IPA', 'XI-IPA 1', 'Rabu', 1, 'Dra. AGUS SETYANINGSIH, M.Si', 'Matematika'),
(328, 3, 'IPA', 'XI-IPA 2', 'Rabu', 1, 'AHERI SUGIHARTONO, S.Th.I', 'Aqidah Akhlak'),
(329, 3, 'IPS', 'XI-IPS 1', 'Rabu', 1, 'Drs. ABAS SIMAN', 'Pendidikan Kewarganegaraan'),
(330, 3, 'IPS', 'XI-IPS 2', 'Rabu', 1, 'Drs. ALI MUSTOFA, M.Pd', 'Geografi'),
(331, 3, 'AGAMA', 'XI-AGAMA', 'Rabu', 1, 'MARDWI ASDIYANTO, M.Pd.I.', 'Ilmu Tafsir'),
(332, 3, 'IPA', 'XII-IPA 1', 'Rabu', 1, 'ARYS SUSANTO, M.Pd', 'Fisika'),
(333, 3, 'IPA', 'XII-IPA 2', 'Rabu', 1, 'SURAWAN, S.Pd.', 'Bahasa Inggris'),
(334, 3, 'IPS', 'XII-IPS 1', 'Rabu', 1, 'NUR RAHMAWATI, S.Pd', 'Bhs & Sastra Ind'),
(335, 3, 'IPS', 'XII-IPS 2', 'Rabu', 1, 'MARIFA RIAMA, S.Pd.', 'Sejarah'),
(336, 3, 'AGAMA', 'XII-AGAMA', 'Rabu', 1, 'Drs. AKHMAD EFENDI', 'Teknologi Informasi Komunikasi'),
(337, 3, 'IPA', 'X-MIPA1', 'Rabu', 2, 'Dra. SUWINARTI', 'Geografi'),
(338, 3, 'IPA', 'X-MIPA2', 'Rabu', 2, 'AHERI SUGIHARTONO, S.Th.I', 'Aqidah Akhlak'),
(339, 3, 'IPA', 'X-MIPA3', 'Rabu', 2, 'ISMI MARIYAM, S.Pd.', 'Bahasa Indonesia'),
(340, 3, 'IPS', 'X-IPS1', 'Rabu', 2, 'MOHAMAD AFIF FARICHIN, M.Pd.I.', 'Muhadatsah'),
(341, 3, 'IPS', 'X-IPS2', 'Rabu', 2, 'NASHRUL ULUM, S.Pd.', 'S K I'),
(342, 3, 'AGAMA', 'X-IAG', 'Rabu', 2, 'Drs. ABD. SALAM HS.', 'Fiqih'),
(343, 3, 'IPA', 'XI-IPA 1', 'Rabu', 2, 'MOCH. FARID WADJIDI Lc, S.Pd.', 'Biologi'),
(344, 3, 'IPA', 'XI-IPA 2', 'Rabu', 2, 'SITI MARIA ULFAH, S.Pd.I', 'Al Quran Hadis'),
(345, 3, 'IPS', 'XI-IPS 1', 'Rabu', 2, 'Dra. ULUMIYAH', 'BKTI'),
(346, 3, 'IPS', 'XI-IPS 2', 'Rabu', 2, 'AGUS SALIM, S.Pd.', 'Bahasa Inggris'),
(347, 3, 'AGAMA', 'XI-AGAMA', 'Rabu', 2, 'Drs. ABD. SALAM HS.', 'Ushul Fiqih'),
(348, 3, 'IPA', 'XII-IPA 1', 'Rabu', 2, 'NENI SUHARTINI, S.Pd, M.Psi', 'BK'),
(349, 3, 'IPA', 'XII-IPA 2', 'Rabu', 2, 'ALY FUADI, S.Pd.', 'Fisika'),
(350, 3, 'IPS', 'XII-IPS 1', 'Rabu', 2, 'Dra. AGUS SETYANINGSIH, M.Si', 'Matematika'),
(351, 3, 'IPS', 'XII-IPS 2', 'Rabu', 2, 'TEGUH KOESTANTININGSIH, S.Pd', 'Keterampilan'),
(352, 3, 'AGAMA', 'XII-AGAMA', 'Rabu', 2, 'Drs. YUDI SYAIFULLOH', 'Pendidikan Jasmani, ORKES'),
(353, 3, 'IPA', 'X-MIPA1', 'Rabu', 3, 'ARI KUSUMAWATI, M.Pd', 'Matematika'),
(354, 3, 'IPA', 'X-MIPA2', 'Rabu', 3, 'YUDHA KURNIAWAN, S.Pd.', 'Pendidikan Jasmani, ORKES'),
(355, 3, 'IPA', 'X-MIPA3', 'Rabu', 3, 'ENNI SUBCHANDINI, S.Pd', 'Kimia'),
(356, 3, 'IPS', 'X-IPS1', 'Rabu', 3, 'TEGUH KOESTANTININGSIH, S.Pd', 'Keterampilan'),
(357, 3, 'IPS', 'X-IPS2', 'Rabu', 3, 'MOHAMAD AFIF FARICHIN, M.Pd.I.', 'Muhadatsah'),
(358, 3, 'AGAMA', 'X-IAG', 'Rabu', 3, 'USMAN, S.Pd.', 'Bahasa Indonesia'),
(359, 3, 'IPA', 'XI-IPA 1', 'Rabu', 3, 'Drs. AKHMAD EFENDI', 'Teknologi Informasi Komunikasi'),
(360, 3, 'IPA', 'XI-IPA 2', 'Rabu', 3, 'Drs. MOKH. HASAN B., M.Pd.', 'Fisika'),
(361, 3, 'IPS', 'XI-IPS 1', 'Rabu', 3, 'NASHRUL ULUM, S.Pd.', 'Sosiologi'),
(362, 3, 'IPS', 'XI-IPS 2', 'Rabu', 3, 'EDDI HARIYADI, S,Pd.', 'Seni Budaya'),
(363, 3, 'AGAMA', 'XI-AGAMA', 'Rabu', 3, 'Drs. ABD. SALAM HS.', 'Fiqih'),
(364, 3, 'IPA', 'XII-IPA 1', 'Rabu', 3, 'Dra. ULUMIYAH', 'BKTI'),
(365, 3, 'IPA', 'XII-IPA 2', 'Rabu', 3, 'INSA ASYAROH, S.Ag', 'Al Quran Hadis'),
(366, 3, 'IPS', 'XII-IPS 1', 'Rabu', 3, 'Dra. SUWINARTI', 'Geografi'),
(367, 3, 'IPS', 'XII-IPS 2', 'Rabu', 3, 'AGUS SALIM, S.Pd.', 'Bahasa Inggris'),
(368, 3, 'AGAMA', 'XII-AGAMA', 'Rabu', 3, 'Drs. ABAS SIMAN', 'Pendidikan Kewarganegaraan'),
(369, 3, 'IPA', 'X-MIPA1', 'Rabu', 4, 'MARDWI ASDIYANTO, M.Pd.I.', 'S K I'),
(370, 3, 'IPA', 'X-MIPA2', 'Rabu', 4, 'ALY FUADI, S.Pd.', 'Fisika'),
(371, 3, 'IPA', 'X-MIPA3', 'Rabu', 4, 'NURUL AINI, S.Pd', 'Matematika'),
(372, 3, 'IPS', 'X-IPS1', 'Rabu', 4, 'ISMI MARIYAM, S.Pd.', 'Bhs & Sastra Ind'),
(373, 3, 'IPS', 'X-IPS2', 'Rabu', 4, 'TEGUH KOESTANTININGSIH, S.Pd', 'Keterampilan'),
(374, 3, 'AGAMA', 'X-IAG', 'Rabu', 4, 'MOHAMAD AFIF FARICHIN, M.Pd.I.', 'Bahasa Arab'),
(375, 3, 'IPA', 'XI-IPA 1', 'Rabu', 4, 'Drs. ALI MUSTOFA, M.Pd', 'Geografi'),
(376, 3, 'IPA', 'XI-IPA 2', 'Rabu', 4, 'HADIAH, S.Pd.', 'Ekonomi'),
(377, 3, 'IPS', 'XI-IPS 1', 'Rabu', 4, 'AHERI SUGIHARTONO, S.Th.I', 'Aqidah Akhlak'),
(378, 3, 'IPS', 'XI-IPS 2', 'Rabu', 4, 'ARIF MUSTOFA, S.Ag., M.Pd.', 'Fiqih'),
(379, 3, 'AGAMA', 'XI-AGAMA', 'Rabu', 4, 'EDDI HARIYADI, S,Pd.', 'Seni Budaya'),
(380, 3, 'IPA', 'XII-IPA 1', 'Rabu', 4, 'Drs. AKHMAD EFENDI', 'Teknologi Informasi Komunikasi'),
(381, 3, 'IPA', 'XII-IPA 2', 'Rabu', 4, 'Drs. ABAS SIMAN', 'Pendidikan Kewarganegaraan'),
(382, 3, 'IPS', 'XII-IPS 1', 'Rabu', 4, 'USMAN, S.Pd.', 'Bahasa Indonesia'),
(383, 3, 'IPS', 'XII-IPS 2', 'Rabu', 4, 'Drs. YUDI SYAIFULLOH', 'Pendidikan Jasmani, ORKES'),
(384, 3, 'AGAMA', 'XII-AGAMA', 'Rabu', 4, 'UMAR FARUQ, S.Ag.', 'Ilmu Kalam'),
(385, 3, 'IPA', 'X-MIPA1', 'Rabu', 5, 'MOHAMAD AFIF FARICHIN, M.Pd.I.', 'Muhadatsah'),
(386, 3, 'IPA', 'X-MIPA2', 'Rabu', 5, 'TRI SUDIK WIYONO, S.Pd', 'Ekonomi'),
(387, 3, 'IPA', 'X-MIPA3', 'Rabu', 5, 'MUHAMMAD SUWAR, S.Pd.I.', 'Bahasa Arab'),
(388, 3, 'IPS', 'X-IPS1', 'Rabu', 5, 'AHERI SUGIHARTONO, S.Th.I', 'Aqidah Akhlak'),
(389, 3, 'IPS', 'X-IPS2', 'Rabu', 5, 'USMAN, S.Pd.', 'Bahasa Indonesia'),
(390, 3, 'AGAMA', 'X-IAG', 'Rabu', 5, 'WIWIN SISWINARNI, S.Pd.', 'Pendidikan Kewarganegaraan'),
(391, 3, 'IPA', 'XI-IPA 1', 'Rabu', 5, 'ARIF MUSTOFA, S.Ag., M.Pd.', 'Fiqih'),
(392, 3, 'IPA', 'XI-IPA 2', 'Rabu', 5, 'Drs. YUDI SYAIFULLOH', 'Pendidikan Jasmani, ORKES'),
(393, 3, 'IPS', 'XI-IPS 1', 'Rabu', 5, 'INSA ASYAROH, S.Ag', 'Al Quran Hadis'),
(394, 3, 'IPS', 'XI-IPS 2', 'Rabu', 5, 'Dra. AGUS SETYANINGSIH, M.Si', 'Matematika'),
(395, 3, 'AGAMA', 'XI-AGAMA', 'Rabu', 5, 'Dra. ULUMIYAH', 'BKTI'),
(396, 3, 'IPA', 'XII-IPA 1', 'Rabu', 5, 'MARDWI ASDIYANTO, M.Pd.I.', 'S K I'),
(397, 3, 'IPA', 'XII-IPA 2', 'Rabu', 5, 'MARIFA RIAMA, S.Pd.', 'Sejarah'),
(398, 3, 'IPS', 'XII-IPS 1', 'Rabu', 5, 'EDDI HARIYADI, S,Pd.', 'Seni Budaya'),
(399, 3, 'IPS', 'XII-IPS 2', 'Rabu', 5, 'Drs. AKHMAD EFENDI', 'Teknologi Informasi Komunikasi'),
(400, 3, 'AGAMA', 'XII-AGAMA', 'Rabu', 5, 'Drs. ABD. SALAM HS.', 'Ushul Fiqih'),
(401, 3, 'IPA', 'X-MIPA1', 'Rabu', 6, 'Drs. DENNY MF., S.Pd.', 'Fisika'),
(402, 3, 'IPA', 'X-MIPA2', 'Rabu', 6, 'NUR RAHMAWATI, S.Pd', 'Bahasa Indonesia'),
(403, 3, 'IPA', 'X-MIPA3', 'Rabu', 6, 'Drs. AKHMAD EFENDI', 'Teknologi Informasi Komunikasi'),
(404, 3, 'IPS', 'X-IPS1', 'Rabu', 6, 'Drs. YUDI SYAIFULLOH', 'Pendidikan Jasmani, ORKES'),
(405, 3, 'IPS', 'X-IPS2', 'Rabu', 6, 'NURUL AINI, S.Pd', 'Matematika'),
(406, 3, 'AGAMA', 'X-IAG', 'Rabu', 6, 'ARIF MUSTOFA, S.Ag., M.Pd.', 'Ushul Fiqih'),
(407, 3, 'IPA', 'XI-IPA 1', 'Rabu', 6, 'NUR JANAH, S.Pd', 'Keterampilan'),
(408, 3, 'IPA', 'XI-IPA 2', 'Rabu', 6, 'ARIF MUSTOFA, S.Ag., M.Pd.', 'Fiqih'),
(409, 3, 'IPS', 'XI-IPS 1', 'Rabu', 6, 'TRI SUDIK WIYONO, S.Pd', 'Ekonomi'),
(410, 3, 'IPS', 'XI-IPS 2', 'Rabu', 6, 'INSA ASYAROH, S.Ag', 'Al Quran Hadis'),
(411, 3, 'AGAMA', 'XI-AGAMA', 'Rabu', 6, 'ALIFIYAH RUSDIYANA, S.Pd.', 'Bahasa Inggris'),
(412, 3, 'IPA', 'XII-IPA 1', 'Rabu', 6, 'ENNI SUBCHANDINI, S.Pd', 'Kimia'),
(413, 3, 'IPA', 'XII-IPA 2', 'Rabu', 6, 'NENI SUHARTINI, S.Pd, M.Psi', 'BK'),
(414, 3, 'IPS', 'XII-IPS 1', 'Rabu', 6, 'MUHAMMAD SUWAR, S.Pd.I.', 'Bahasa Arab'),
(415, 3, 'IPS', 'XII-IPS 2', 'Rabu', 6, 'NUR RAHMAWATI, S.Pd', 'Bhs & Sastra Ind'),
(416, 3, 'AGAMA', 'XII-AGAMA', 'Rabu', 6, 'MARDWI ASDIYANTO, M.Pd.I.', 'Ilmu Tafsir'),
(417, 3, 'IPA', 'X-MIPA1', 'Rabu', 7, 'Drs. ABD. SALAM HS.', 'Fiqih'),
(418, 3, 'IPA', 'X-MIPA2', 'Rabu', 7, 'MARIFA RIAMA, S.Pd.', 'Sejarah'),
(419, 3, 'IPA', 'X-MIPA3', 'Rabu', 7, 'ALY FUADI, S.Pd.', 'Fisika'),
(420, 3, 'IPS', 'X-IPS1', 'Rabu', 7, 'MARDWI ASDIYANTO, M.Pd.I.', 'S K I'),
(421, 3, 'IPS', 'X-IPS2', 'Rabu', 7, 'YAYUK ISWATIN, S.Pd', 'Seni Budaya'),
(422, 3, 'AGAMA', 'X-IAG', 'Rabu', 7, 'ALIFIYAH RUSDIYANA, S.Pd.', 'Bahasa Inggris'),
(423, 3, 'IPA', 'XI-IPA 1', 'Rabu', 7, 'WIWIN SISWINARNI, S.Pd.', 'Pendidikan Kewarganegaraan'),
(424, 3, 'IPA', 'XI-IPA 2', 'Rabu', 7, 'HANIM NURUL AINI, S.Pd.', 'Bahasa Indonesia'),
(425, 3, 'IPS', 'XI-IPS 1', 'Rabu', 7, 'MOHAMAD AFIF FARICHIN, M.Pd.I.', 'Muhadatsah'),
(426, 3, 'IPS', 'XI-IPS 2', 'Rabu', 7, 'NUR RAHMAWATI, S.Pd', 'Bhs & Sastra Ind'),
(427, 3, 'AGAMA', 'XI-AGAMA', 'Rabu', 7, 'Drs. YUDI SYAIFULLOH', 'Pendidikan Jasmani, ORKES'),
(428, 3, 'IPA', 'XII-IPA 1', 'Rabu', 7, 'MOCH. FARID WADJIDI Lc, S.Pd.', 'Biologi'),
(429, 3, 'IPA', 'XII-IPA 2', 'Rabu', 7, 'TRI SUDIK WIYONO, S.Pd', 'Ekonomi'),
(430, 3, 'IPS', 'XII-IPS 1', 'Rabu', 7, 'AHERI SUGIHARTONO, S.Th.I', 'Aqidah Akhlak'),
(431, 3, 'IPS', 'XII-IPS 2', 'Rabu', 7, 'Drs. ALI MUSTOFA, M.Pd', 'Geografi'),
(432, 3, 'AGAMA', 'XII-AGAMA', 'Rabu', 7, 'MUHAMMAD SUWAR, S.Pd.I.', 'Bahasa Arab'),
(433, 3, 'IPA', 'X-MIPA1', 'Rabu', 8, 'Dra. ULUMIYAH', 'BKTI'),
(434, 3, 'IPA', 'X-MIPA2', 'Rabu', 8, 'NUR JANAH, S.Pd', 'Keterampilan'),
(435, 3, 'IPA', 'X-MIPA3', 'Rabu', 8, 'HADIAH, S.Pd.', 'Ekonomi'),
(436, 3, 'IPS', 'X-IPS1', 'Rabu', 8, 'WIWIN SISWINARNI, S.Pd.', 'Pendidikan Kewarganegaraan'),
(437, 3, 'IPS', 'X-IPS2', 'Rabu', 8, 'AGUS SALIM, S.Pd.', 'Bahasa Inggris'),
(438, 3, 'AGAMA', 'X-IAG', 'Rabu', 8, 'ISMI MARIYAM, S.Pd.', 'Bhs & Sastra Ind'),
(439, 3, 'IPA', 'XI-IPA 1', 'Rabu', 8, 'Drs. YUDI SYAIFULLOH', 'Pendidikan Jasmani, ORKES'),
(440, 3, 'IPA', 'XI-IPA 2', 'Rabu', 8, 'SURAWAN, S.Pd.', 'Kimia'),
(441, 3, 'IPS', 'XI-IPS 1', 'Rabu', 8, 'MARIFA RIAMA, S.Pd.', 'Sejarah'),
(442, 3, 'IPS', 'XI-IPS 2', 'Rabu', 8, 'Drs. AKHMAD EFENDI', 'Teknologi Informasi Komunikasi'),
(443, 3, 'AGAMA', 'XI-AGAMA', 'Rabu', 8, 'MOHAMAD AFIF FARICHIN, M.Pd.I.', 'Bahasa Arab'),
(444, 3, 'IPA', 'XII-IPA 1', 'Rabu', 8, 'SAYUDI, S. Pd.', 'Bahasa Indonesia'),
(445, 3, 'IPA', 'XII-IPA 2', 'Rabu', 8, 'MOCH. FARID WADJIDI Lc, S.Pd.', 'Biologi'),
(446, 3, 'IPS', 'XII-IPS 1', 'Rabu', 8, 'MARDWI ASDIYANTO, M.Pd.I.', 'S K I'),
(447, 3, 'IPS', 'XII-IPS 2', 'Rabu', 8, 'FATUKHA, S.Pd.', 'Matematika'),
(448, 3, 'AGAMA', 'XII-AGAMA', 'Rabu', 8, 'Drs. ABD. SALAM HS.', 'Fiqih'),
(449, 3, 'IPA', 'X-MIPA1', 'Rabu', 9, 'HADIAH, S.Pd.', 'Ekonomi'),
(450, 3, 'IPA', 'X-MIPA2', 'Rabu', 9, 'ARIF MUSTOFA, S.Ag., M.Pd.', 'Fiqih'),
(451, 3, 'IPA', 'X-MIPA3', 'Rabu', 9, 'ANITA KURNIA RAHAYU, S.P.', 'Biologi'),
(452, 3, 'IPS', 'X-IPS1', 'Rabu', 9, 'NASHRUL ULUM, S.Pd.', 'Sosiologi'),
(453, 3, 'IPS', 'X-IPS2', 'Rabu', 9, 'Drs. ABAS SIMAN', 'Pendidikan Kewarganegaraan'),
(454, 3, 'AGAMA', 'X-IAG', 'Rabu', 9, 'INSA ASYAROH, S.Ag', 'Ilmu Hadits'),
(455, 3, 'IPA', 'XI-IPA 1', 'Rabu', 9, 'NENI SUHARTINI, S.Pd, M.Psi', 'BK'),
(456, 3, 'IPA', 'XI-IPA 2', 'Rabu', 9, 'Dra. SUWINARTI', 'Geografi'),
(457, 3, 'IPS', 'XI-IPS 1', 'Rabu', 9, 'MARDWI ASDIYANTO, M.Pd.I.', 'S K I'),
(458, 3, 'IPS', 'XI-IPS 2', 'Rabu', 9, 'MARIFA RIAMA, S.Pd.', 'Sejarah'),
(459, 3, 'AGAMA', 'XI-AGAMA', 'Rabu', 9, 'UMAR FARUQ, S.Ag.', 'Ilmu Kalam'),
(460, 3, 'IPA', 'XII-IPA 1', 'Rabu', 9, 'INSA ASYAROH, S.Ag', 'Al Quran Hadis'),
(461, 3, 'IPA', 'XII-IPA 2', 'Rabu', 9, 'ARI KUSUMAWATI, M.Pd', 'Matematika'),
(462, 3, 'IPS', 'XII-IPS 1', 'Rabu', 9, 'SURAWAN, S.Pd.', 'Bahasa Inggris'),
(463, 3, 'IPS', 'XII-IPS 2', 'Rabu', 9, 'Dra. ULUMIYAH', 'BKTI'),
(464, 3, 'AGAMA', 'XII-AGAMA', 'Rabu', 9, 'NUR JANAH, S.Pd', 'Keterampilan'),
(465, 3, 'IPA', 'X-MIPA1', 'Rabu', 10, 'INSA ASYAROH, S.Ag', 'Al Quran Hadis'),
(466, 3, 'IPA', 'X-MIPA2', 'Rabu', 10, 'ARI KUSUMAWATI, M.Pd', 'Matematika'),
(467, 3, 'IPA', 'X-MIPA3', 'Rabu', 10, 'SURAWAN, S.Pd.', 'Bahasa Inggris'),
(468, 3, 'IPS', 'X-IPS1', 'Rabu', 10, 'Drs. ABD. SALAM HS.', 'Fiqih'),
(469, 3, 'IPS', 'X-IPS2', 'Rabu', 10, 'NASHRUL ULUM, S.Pd.', 'Sosiologi'),
(470, 3, 'AGAMA', 'X-IAG', 'Rabu', 10, 'MOHAMAD AFIF FARICHIN, M.Pd.I.', 'Muhadatsah'),
(471, 3, 'IPA', 'XI-IPA 1', 'Rabu', 10, 'YAYUK ISWATIN, S.Pd', 'Seni Budaya'),
(472, 3, 'IPA', 'XI-IPA 2', 'Rabu', 10, 'MARDWI ASDIYANTO, M.Pd.I.', 'S K I'),
(473, 3, 'IPS', 'XI-IPS 1', 'Rabu', 10, 'Drs. ALI MUSTOFA, M.Pd', 'Geografi'),
(474, 3, 'IPS', 'XI-IPS 2', 'Rabu', 10, 'Drs. YUDI SYAIFULLOH', 'Pendidikan Jasmani, ORKES'),
(475, 3, 'AGAMA', 'XI-AGAMA', 'Rabu', 10, 'NENI SUHARTINI, S.Pd, M.Psi', 'BK'),
(476, 3, 'IPA', 'XII-IPA 1', 'Rabu', 10, 'Drs. ABAS SIMAN', 'Pendidikan Kewarganegaraan'),
(477, 3, 'IPA', 'XII-IPA 2', 'Rabu', 10, 'TEGUH KOESTANTININGSIH, S.Pd', 'Keterampilan'),
(478, 3, 'IPS', 'XII-IPS 1', 'Rabu', 10, 'TRI SUDIK WIYONO, S.Pd', 'Ekonomi'),
(479, 3, 'IPS', 'XII-IPS 2', 'Rabu', 10, 'AHERI SUGIHARTONO, S.Th.I', 'Aqidah Akhlak'),
(480, 3, 'AGAMA', 'XII-AGAMA', 'Rabu', 10, 'SAYUDI, S. Pd.', 'Bahasa Indonesia'),
(481, 3, 'IPA', 'X-MIPA1', 'Kamis', 1, 'ISMI MARIYAM, S.Pd.', 'Bahasa Indonesia'),
(482, 3, 'IPA', 'X-MIPA2', 'Kamis', 1, 'SURAWAN, S.Pd.', 'Kimia'),
(483, 3, 'IPA', 'X-MIPA3', 'Kamis', 1, 'NENI SUHARTINI, S.Pd, M.Psi', 'BK'),
(484, 3, 'IPS', 'X-IPS1', 'Kamis', 1, 'TEGUH KOESTANTININGSIH, S.Pd', 'Keterampilan'),
(485, 3, 'IPS', 'X-IPS2', 'Kamis', 1, 'EDDI HARIYADI, S,Pd.', 'Seni Budaya'),
(486, 3, 'AGAMA', 'X-IAG', 'Kamis', 1, 'ARIF MUSTOFA, S.Ag., M.Pd.', 'Fiqih'),
(487, 3, 'IPA', 'XI-IPA 1', 'Kamis', 1, 'Drs. YUDI SYAIFULLOH', 'Pendidikan Jasmani, ORKES'),
(488, 3, 'IPA', 'XI-IPA 2', 'Kamis', 1, 'NURUL AINI, S.Pd', 'Matematika'),
(489, 3, 'IPS', 'XI-IPS 1', 'Kamis', 1, 'MARIFA RIAMA, S.Pd.', 'Sejarah'),
(490, 3, 'IPS', 'XI-IPS 2', 'Kamis', 1, 'TRI SUDIK WIYONO, S.Pd', 'Ekonomi'),
(491, 3, 'AGAMA', 'XI-AGAMA', 'Kamis', 1, 'UMAR FARUQ, S.Ag.', 'Ilmu Kalam'),
(492, 3, 'IPA', 'XII-IPA 1', 'Kamis', 1, 'Drs. ABAS SIMAN', 'Pendidikan Kewarganegaraan'),
(493, 3, 'IPA', 'XII-IPA 2', 'Kamis', 1, 'INSA ASYAROH, S.Ag', 'Al Quran Hadis'),
(494, 3, 'IPS', 'XII-IPS 1', 'Kamis', 1, 'ISMI MARIYAM, S.Pd.', 'Bhs & Sastra Ind'),
(495, 3, 'IPS', 'XII-IPS 2', 'Kamis', 1, 'MARDWI ASDIYANTO, M.Pd.I.', 'S K I'),
(496, 3, 'AGAMA', 'XII-AGAMA', 'Kamis', 1, 'AGUS SALIM, S.Pd.', 'Bahasa Inggris'),
(497, 3, 'IPA', 'X-MIPA1', 'Kamis', 2, 'MARDWI ASDIYANTO, M.Pd.I.', 'S K I'),
(498, 3, 'IPA', 'X-MIPA2', 'Kamis', 2, 'HANIM NURUL AINI, S.Pd.', 'Bahasa Indonesia'),
(499, 3, 'IPA', 'X-MIPA3', 'Kamis', 2, 'ARI KUSUMAWATI, M.Pd', 'Matematika'),
(500, 3, 'IPS', 'X-IPS1', 'Kamis', 2, 'MARIFA RIAMA, S.Pd.', 'Sejarah'),
(501, 3, 'IPS', 'X-IPS2', 'Kamis', 2, 'Dra. ULUMIYAH', 'BKTI'),
(502, 3, 'AGAMA', 'X-IAG', 'Kamis', 2, 'ARIF MUSTOFA, S.Ag., M.Pd.', 'Ushul Fiqih'),
(503, 3, 'IPA', 'XI-IPA 1', 'Kamis', 2, 'ARIF MUSTOFA, S.Ag., M.Pd.', 'Fiqih'),
(504, 3, 'IPA', 'XI-IPA 2', 'Kamis', 2, 'Drs. ALI MUSTOFA, M.Pd', 'Geografi'),
(505, 3, 'IPS', 'XI-IPS 1', 'Kamis', 2, 'WIWIN SISWINARNI, S.Pd.', 'Pendidikan Kewarganegaraan'),
(506, 3, 'IPS', 'XI-IPS 2', 'Kamis', 2, 'NASHRUL ULUM, S.Pd.', 'Sosiologi'),
(507, 3, 'AGAMA', 'XI-AGAMA', 'Kamis', 2, 'MUHAMMAD SUWAR, S.Pd.I.', 'Bahasa Arab'),
(508, 3, 'IPA', 'XII-IPA 1', 'Kamis', 2, 'EDDI HARIYADI, S,Pd.', 'Seni Budaya'),
(509, 3, 'IPA', 'XII-IPA 2', 'Kamis', 2, 'Drs. DENNY MF., S.Pd.', 'Fisika'),
(510, 3, 'IPS', 'XII-IPS 1', 'Kamis', 2, 'TRI SUDIK WIYONO, S.Pd', 'Ekonomi'),
(511, 3, 'IPS', 'XII-IPS 2', 'Kamis', 2, 'TEGUH KOESTANTININGSIH, S.Pd', 'Keterampilan'),
(512, 3, 'AGAMA', 'XII-AGAMA', 'Kamis', 2, 'ISMI MARIYAM, S.Pd.', 'Bhs & Sastra Ind'),
(513, 3, 'IPA', 'X-MIPA1', 'Kamis', 3, 'YUDHA KURNIAWAN, S.Pd.', 'Pendidikan Jasmani, ORKES'),
(514, 3, 'IPA', 'X-MIPA2', 'Kamis', 3, 'YAYUK ISWATIN, S.Pd', 'Seni Budaya'),
(515, 3, 'IPA', 'X-MIPA3', 'Kamis', 3, 'WIJI LAELATUL JUMAH, S.Pd.', 'Bahasa Indonesia'),
(516, 3, 'IPS', 'X-IPS1', 'Kamis', 3, 'NURUL AINI, S.Pd', 'Matematika'),
(517, 3, 'IPS', 'X-IPS2', 'Kamis', 3, 'AGUS SALIM, S.Pd.', 'Bahasa Inggris'),
(518, 3, 'AGAMA', 'X-IAG', 'Kamis', 3, 'AHERI SUGIHARTONO, S.Th.I', 'Aqidah Akhlak'),
(519, 3, 'IPA', 'XI-IPA 1', 'Kamis', 3, 'NENI SUHARTINI, S.Pd, M.Psi', 'BK'),
(520, 3, 'IPA', 'XI-IPA 2', 'Kamis', 3, 'SITI MARIA ULFAH, S.Pd.I', 'Al Quran Hadis'),
(521, 3, 'IPS', 'XI-IPS 1', 'Kamis', 3, 'MOHAMAD AFIF FARICHIN, M.Pd.I.', 'Muhadatsah'),
(522, 3, 'IPS', 'XI-IPS 2', 'Kamis', 3, 'MARDWI ASDIYANTO, M.Pd.I.', 'S K I'),
(523, 3, 'AGAMA', 'XI-AGAMA', 'Kamis', 3, 'Drs. ABAS SIMAN', 'Pendidikan Kewarganegaraan'),
(524, 3, 'IPA', 'XII-IPA 1', 'Kamis', 3, 'ARYS SUSANTO, M.Pd', 'Fisika'),
(525, 3, 'IPA', 'XII-IPA 2', 'Kamis', 3, 'MOCH. FARID WADJIDI Lc, S.Pd.', 'Biologi'),
(526, 3, 'IPS', 'XII-IPS 1', 'Kamis', 3, 'NASHRUL ULUM, S.Pd.', 'Sosiologi'),
(527, 3, 'IPS', 'XII-IPS 2', 'Kamis', 3, 'TRI SUDIK WIYONO, S.Pd', 'Ekonomi'),
(528, 3, 'AGAMA', 'XII-AGAMA', 'Kamis', 3, 'SITI MARIA ULFAH, S.Pd.I', 'Ilmu Hadits'),
(529, 3, 'IPA', 'X-MIPA1', 'Kamis', 4, 'WIWIN SISWINARNI, S.Pd.', 'Pendidikan Kewarganegaraan'),
(530, 3, 'IPA', 'X-MIPA2', 'Kamis', 4, 'Drs. ALI MUSTOFA, M.Pd', 'Geografi'),
(531, 3, 'IPA', 'X-MIPA3', 'Kamis', 4, 'YUDHA KURNIAWAN, S.Pd.', 'Pendidikan Jasmani, ORKES'),
(532, 3, 'IPS', 'X-IPS1', 'Kamis', 4, 'MUHAMMAD SUWAR, S.Pd.I.', 'Bahasa Arab'),
(533, 3, 'IPS', 'X-IPS2', 'Kamis', 4, 'TEGUH KOESTANTININGSIH, S.Pd', 'Keterampilan'),
(534, 3, 'AGAMA', 'X-IAG', 'Kamis', 4, 'SURAWAN, S.Pd.', 'Bahasa Inggris'),
(535, 3, 'IPA', 'XI-IPA 1', 'Kamis', 4, 'EDDI HARIYADI, S,Pd.', 'Seni Budaya'),
(536, 3, 'IPA', 'XI-IPA 2', 'Kamis', 4, 'Drs. MOKH. HASAN B., M.Pd.', 'Fisika'),
(537, 3, 'IPS', 'XI-IPS 1', 'Kamis', 4, 'NASHRUL ULUM, S.Pd.', 'Sosiologi'),
(538, 3, 'IPS', 'XI-IPS 2', 'Kamis', 4, 'USMAN, S.Pd.', 'Bahasa Indonesia'),
(539, 3, 'AGAMA', 'XI-AGAMA', 'Kamis', 4, 'Drs. AKHMAD EFENDI', 'Teknologi Informasi Komunikasi'),
(540, 3, 'IPA', 'XII-IPA 1', 'Kamis', 4, 'Dra. ULUMIYAH', 'BKTI'),
(541, 3, 'IPA', 'XII-IPA 2', 'Kamis', 4, 'ALIEF PURNOMO AJU, S.Pd.', 'Kimia'),
(542, 3, 'IPS', 'XII-IPS 1', 'Kamis', 4, 'FATUKHA, S.Pd.', 'Matematika'),
(543, 3, 'IPS', 'XII-IPS 2', 'Kamis', 4, 'NUR RAHMAWATI, S.Pd', 'Bhs & Sastra Ind'),
(544, 3, 'AGAMA', 'XII-AGAMA', 'Kamis', 4, 'Drs. ABD. SALAM HS.', 'Fiqih'),
(545, 3, 'IPA', 'X-MIPA1', 'Kamis', 5, 'NENI SUHARTINI, S.Pd, M.Psi', 'BK'),
(546, 3, 'IPA', 'X-MIPA2', 'Kamis', 5, 'ALY FUADI, S.Pd.', 'Fisika'),
(547, 3, 'IPA', 'X-MIPA3', 'Kamis', 5, 'TEGUH KOESTANTININGSIH, S.Pd', 'Keterampilan'),
(548, 3, 'IPS', 'X-IPS1', 'Kamis', 5, 'NASHRUL ULUM, S.Pd.', 'S K I'),
(549, 3, 'IPS', 'X-IPS2', 'Kamis', 5, 'Drs. ABD. SALAM HS.', 'Fiqih'),
(550, 3, 'AGAMA', 'X-IAG', 'Kamis', 5, 'Dra. AGUS SETYANINGSIH, M.Si', 'Matematika'),
(551, 3, 'IPA', 'XI-IPA 1', 'Kamis', 5, 'TRI SUDIK WIYONO, S.Pd', 'Ekonomi'),
(552, 3, 'IPA', 'XI-IPA 2', 'Kamis', 5, 'EDDI HARIYADI, S,Pd.', 'Seni Budaya'),
(553, 3, 'IPS', 'XI-IPS 1', 'Kamis', 5, 'NUR RAHMAWATI, S.Pd', 'Bhs & Sastra Ind'),
(554, 3, 'IPS', 'XI-IPS 2', 'Kamis', 5, 'AHERI SUGIHARTONO, S.Th.I', 'Aqidah Akhlak'),
(555, 3, 'AGAMA', 'XI-AGAMA', 'Kamis', 5, 'ARIF MUSTOFA, S.Ag., M.Pd.', 'Ushul Fiqih'),
(556, 3, 'IPA', 'XII-IPA 1', 'Kamis', 5, 'YUDHA KURNIAWAN, S.Pd.', 'Pendidikan Jasmani, ORKES'),
(557, 3, 'IPA', 'XII-IPA 2', 'Kamis', 5, 'SAYUDI, S. Pd.', 'Bahasa Indonesia'),
(558, 3, 'IPS', 'XII-IPS 1', 'Kamis', 5, 'AGUS SALIM, S.Pd.', 'Bahasa Inggris'),
(559, 3, 'IPS', 'XII-IPS 2', 'Kamis', 5, 'MARIFA RIAMA, S.Pd.', 'Sejarah'),
(560, 3, 'AGAMA', 'XII-AGAMA', 'Kamis', 5, 'MUHAMMAD SUWAR, S.Pd.I.', 'Bahasa Arab'),
(561, 3, 'IPA', 'X-MIPA1', 'Kamis', 6, 'Drs. DENNY MF., S.Pd.', 'Fisika'),
(562, 3, 'IPA', 'X-MIPA2', 'Kamis', 6, 'MUHAMMAD SUWAR, S.Pd.I.', 'Bahasa Arab'),
(563, 3, 'IPA', 'X-MIPA3', 'Kamis', 6, 'ENNI SUBCHANDINI, S.Pd', 'Kimia'),
(564, 3, 'IPS', 'X-IPS1', 'Kamis', 6, 'HADIAH, S.Pd.', 'Ekonomi'),
(565, 3, 'IPS', 'X-IPS2', 'Kamis', 6, 'INSA ASYAROH, S.Ag', 'Al Quran Hadis'),
(566, 3, 'AGAMA', 'X-IAG', 'Kamis', 6, 'USMAN, S.Pd.', 'Bahasa Indonesia'),
(567, 3, 'IPA', 'XI-IPA 1', 'Kamis', 6, 'Dra. MAZIDAH INAYATI', 'Matematika'),
(568, 3, 'IPA', 'XI-IPA 2', 'Kamis', 6, 'Dra. ULUMIYAH', 'BKTI'),
(569, 3, 'IPS', 'XI-IPS 1', 'Kamis', 6, 'ARIF MUSTOFA, S.Ag., M.Pd.', 'Fiqih'),
(570, 3, 'IPS', 'XI-IPS 2', 'Kamis', 6, 'WIWIN SISWINARNI, S.Pd.', 'Pendidikan Kewarganegaraan'),
(571, 3, 'AGAMA', 'XI-AGAMA', 'Kamis', 6, 'AGUS SALIM, S.Pd.', 'Bahasa Inggris'),
(572, 3, 'IPA', 'XII-IPA 1', 'Kamis', 6, 'MARIFA RIAMA, S.Pd.', 'Sejarah'),
(573, 3, 'IPA', 'XII-IPA 2', 'Kamis', 6, 'NENI SUHARTINI, S.Pd, M.Psi', 'BK'),
(574, 3, 'IPS', 'XII-IPS 1', 'Kamis', 6, 'MARDWI ASDIYANTO, M.Pd.I.', 'S K I'),
(575, 3, 'IPS', 'XII-IPS 2', 'Kamis', 6, 'Drs. YUDI SYAIFULLOH', 'Pendidikan Jasmani, ORKES'),
(576, 3, 'AGAMA', 'XII-AGAMA', 'Kamis', 6, 'NUR JANAH, S.Pd', 'Keterampilan'),
(577, 3, 'IPA', 'X-MIPA1', 'Kamis', 7, 'Dra. ULUMIYAH', 'BKTI'),
(578, 3, 'IPA', 'X-MIPA2', 'Kamis', 7, 'MURSALIN, ST, S.Pd', 'Matematika'),
(579, 3, 'IPA', 'X-MIPA3', 'Kamis', 7, 'SURAWAN, S.Pd.', 'Bahasa Inggris'),
(580, 3, 'IPS', 'X-IPS1', 'Kamis', 7, 'Drs. ALI MUSTOFA, M.Pd', 'Geografi'),
(581, 3, 'IPS', 'X-IPS2', 'Kamis', 7, 'Drs. YUDI SYAIFULLOH', 'Pendidikan Jasmani, ORKES'),
(582, 3, 'AGAMA', 'X-IAG', 'Kamis', 7, 'ISMI MARIYAM, S.Pd.', 'Bhs & Sastra Ind'),
(583, 3, 'IPA', 'XI-IPA 1', 'Kamis', 7, 'HANIM NURUL AINI, S.Pd.', 'Bahasa Indonesia'),
(584, 3, 'IPA', 'XI-IPA 2', 'Kamis', 7, 'TRI SUDIK WIYONO, S.Pd', 'Ekonomi'),
(585, 3, 'IPS', 'XI-IPS 1', 'Kamis', 7, 'TEGUH KOESTANTININGSIH, S.Pd', 'Keterampilan'),
(586, 3, 'IPS', 'XI-IPS 2', 'Kamis', 7, 'MUHAMMAD SUWAR, S.Pd.I.', 'Bahasa Arab'),
(587, 3, 'AGAMA', 'XI-AGAMA', 'Kamis', 7, 'YAYUK ISWATIN, S.Pd', 'Seni Budaya'),
(588, 3, 'IPA', 'XII-IPA 1', 'Kamis', 7, 'ENNI SUBCHANDINI, S.Pd', 'Kimia'),
(589, 3, 'IPA', 'XII-IPA 2', 'Kamis', 7, 'MARIFA RIAMA, S.Pd.', 'Sejarah'),
(590, 3, 'IPS', 'XII-IPS 1', 'Kamis', 7, 'Drs. ABD. SALAM HS.', 'Fiqih'),
(591, 3, 'IPS', 'XII-IPS 2', 'Kamis', 7, 'Drs. AKHMAD EFENDI', 'Teknologi Informasi Komunikasi'),
(592, 3, 'AGAMA', 'XII-AGAMA', 'Kamis', 7, 'AHERI SUGIHARTONO, S.Th.I', 'Aqidah Akhlak'),
(593, 3, 'IPA', 'X-MIPA1', 'Kamis', 8, 'SITI MARIA ULFAH, S.Pd.I', 'Al Quran Hadis'),
(594, 3, 'IPA', 'X-MIPA2', 'Kamis', 8, 'MARDWI ASDIYANTO, M.Pd.I.', 'S K I'),
(595, 3, 'IPA', 'X-MIPA3', 'Kamis', 8, 'ARYS SUSANTO, M.Pd', 'Fisika'),
(596, 3, 'IPS', 'X-IPS1', 'Kamis', 8, 'AGUS SALIM, S.Pd.', 'Bahasa Inggris'),
(597, 3, 'IPS', 'X-IPS2', 'Kamis', 8, 'NUR RAHMAWATI, S.Pd', 'Bhs & Sastra Ind'),
(598, 3, 'AGAMA', 'X-IAG', 'Kamis', 8, 'UMAR FARUQ, S.Ag.', 'Ilmu Kalam'),
(599, 3, 'IPA', 'XI-IPA 1', 'Kamis', 8, 'INGRID ARIANY SAVITRI, S.Pd.', 'Biologi'),
(600, 3, 'IPA', 'XI-IPA 2', 'Kamis', 8, 'NUR JANAH, S.Pd', 'Keterampilan'),
(601, 3, 'IPS', 'XI-IPS 1', 'Kamis', 8, 'Dra. ULUMIYAH', 'BKTI'),
(602, 3, 'IPS', 'XI-IPS 2', 'Kamis', 8, 'Drs. ABD. SALAM HS.', 'Fiqih'),
(603, 3, 'AGAMA', 'XI-AGAMA', 'Kamis', 8, 'SAYUDI, S. Pd.', 'Bahasa Indonesia'),
(604, 3, 'IPA', 'XII-IPA 1', 'Kamis', 8, 'Dra. MAZIDAH INAYATI', 'Matematika'),
(605, 3, 'IPA', 'XII-IPA 2', 'Kamis', 8, 'Drs. AKHMAD EFENDI', 'Teknologi Informasi Komunikasi'),
(606, 3, 'IPS', 'XII-IPS 1', 'Kamis', 8, 'AHERI SUGIHARTONO, S.Th.I', 'Aqidah Akhlak'),
(607, 3, 'IPS', 'XII-IPS 2', 'Kamis', 8, 'NASHRUL ULUM, S.Pd.', 'Sosiologi'),
(608, 3, 'AGAMA', 'XII-AGAMA', 'Kamis', 8, 'WIWIN SISWINARNI, S.Pd.', 'Pendidikan Kewarganegaraan'),
(609, 3, 'IPA', 'X-MIPA1', 'Kamis', 9, 'ALIEF PURNOMO AJU, S.Pd.', 'Kimia'),
(610, 3, 'IPA', 'X-MIPA2', 'Kamis', 9, 'SURAWAN, S.Pd.', 'Bahasa Inggris'),
(611, 3, 'IPA', 'X-MIPA3', 'Kamis', 9, 'WIWIN SISWINARNI, S.Pd.', 'Pendidikan Kewarganegaraan'),
(612, 3, 'IPS', 'X-IPS1', 'Kamis', 9, 'NASHRUL ULUM, S.Pd.', 'Sosiologi'),
(613, 3, 'IPS', 'X-IPS2', 'Kamis', 9, 'AHERI SUGIHARTONO, S.Th.I', 'Aqidah Akhlak'),
(614, 3, 'AGAMA', 'X-IAG', 'Kamis', 9, 'MOHAMAD AFIF FARICHIN, M.Pd.I.', 'Bahasa Arab'),
(615, 3, 'IPA', 'XI-IPA 1', 'Kamis', 9, 'MOHAMAD AFIF FARICHIN, M.Pd.I.', 'Muhadatsah'),
(616, 3, 'IPA', 'XI-IPA 2', 'Kamis', 9, 'ARIF MUSTOFA, S.Ag., M.Pd.', 'Fiqih'),
(617, 3, 'IPS', 'XI-IPS 1', 'Kamis', 9, 'INSA ASYAROH, S.Ag', 'Al Quran Hadis'),
(618, 3, 'IPS', 'XI-IPS 2', 'Kamis', 9, 'NUR RAHMAWATI, S.Pd', 'Bhs & Sastra Ind'),
(619, 3, 'AGAMA', 'XI-AGAMA', 'Kamis', 9, 'Dra. AGUS SETYANINGSIH, M.Si', 'Matematika'),
(620, 3, 'IPA', 'XII-IPA 1', 'Kamis', 9, 'TRI SUDIK WIYONO, S.Pd', 'Ekonomi'),
(621, 3, 'IPA', 'XII-IPA 2', 'Kamis', 9, 'TEGUH KOESTANTININGSIH, S.Pd', 'Keterampilan'),
(622, 3, 'IPS', 'XII-IPS 1', 'Kamis', 9, 'Drs. YUDI SYAIFULLOH', 'Pendidikan Jasmani, ORKES'),
(623, 3, 'IPS', 'XII-IPS 2', 'Kamis', 9, 'Dra. SUWINARTI', 'Geografi'),
(624, 3, 'AGAMA', 'XII-AGAMA', 'Kamis', 9, 'UMAR FARUQ, S.Ag.', 'Ilmu Kalam'),
(625, 3, 'IPA', 'X-MIPA1', 'Kamis', 10, 'MURSALIN, ST, S.Pd', 'Matematika'),
(626, 3, 'IPA', 'X-MIPA2', 'Kamis', 10, 'INSA ASYAROH, S.Ag', 'Al Quran Hadis');
INSERT INTO `generate_jadwal` (`id_jadwal`, `idperiode`, `nama_jurusan`, `nama_kelas`, `hari`, `jamke`, `nama_guru`, `mapel_ajar`) VALUES
(627, 3, 'IPA', 'X-MIPA3', 'Kamis', 10, 'MOCH. FARID WADJIDI Lc, S.Pd.', 'Biologi'),
(628, 3, 'IPS', 'X-IPS1', 'Kamis', 10, 'MOHAMAD AFIF FARICHIN, M.Pd.I.', 'Muhadatsah'),
(629, 3, 'IPS', 'X-IPS2', 'Kamis', 10, 'USMAN, S.Pd.', 'Bahasa Indonesia'),
(630, 3, 'AGAMA', 'X-IAG', 'Kamis', 10, 'INSA ASYAROH, S.Ag', 'Ilmu Hadits'),
(631, 3, 'IPA', 'XI-IPA 1', 'Kamis', 10, 'ARYS SUSANTO, M.Pd', 'Fisika'),
(632, 3, 'IPA', 'XI-IPA 2', 'Kamis', 10, 'WIWIN SISWINARNI, S.Pd.', 'Pendidikan Kewarganegaraan'),
(633, 3, 'IPS', 'XI-IPS 1', 'Kamis', 10, 'Dra. SUWINARTI', 'Geografi'),
(634, 3, 'IPS', 'XI-IPS 2', 'Kamis', 10, 'AGUS SALIM, S.Pd.', 'Bahasa Inggris'),
(635, 3, 'AGAMA', 'XI-AGAMA', 'Kamis', 10, 'NUR RAHMAWATI, S.Pd', 'Bhs & Sastra Ind'),
(636, 3, 'IPA', 'XII-IPA 1', 'Kamis', 10, 'AHERI SUGIHARTONO, S.Th.I', 'Aqidah Akhlak'),
(637, 3, 'IPA', 'XII-IPA 2', 'Kamis', 10, 'Drs. ABD. SALAM HS.', 'Fiqih'),
(638, 3, 'IPS', 'XII-IPS 1', 'Kamis', 10, 'EDDI HARIYADI, S,Pd.', 'Seni Budaya'),
(639, 3, 'IPS', 'XII-IPS 2', 'Kamis', 10, 'MUHAMMAD SUWAR, S.Pd.I.', 'Bahasa Arab'),
(640, 3, 'AGAMA', 'XII-AGAMA', 'Kamis', 10, 'Drs. YUDI SYAIFULLOH', 'Pendidikan Jasmani, ORKES'),
(641, 3, 'IPA', 'X-MIPA1', 'Jumat', 1, 'YUDHA KURNIAWAN, S.Pd.', 'Pendidikan Jasmani, ORKES'),
(642, 3, 'IPA', 'X-MIPA2', 'Jumat', 1, 'ANITA KURNIA RAHAYU, S.P.', 'Biologi'),
(643, 3, 'IPA', 'X-MIPA3', 'Jumat', 1, 'Dra. ULUMIYAH', 'BKTI'),
(644, 3, 'IPS', 'X-IPS1', 'Jumat', 1, 'Drs. AKHMAD EFENDI', 'Teknologi Informasi Komunikasi'),
(645, 3, 'IPS', 'X-IPS2', 'Jumat', 1, 'INSA ASYAROH, S.Ag', 'Al Quran Hadis'),
(646, 3, 'AGAMA', 'X-IAG', 'Jumat', 1, 'NURUL AINI, S.Pd', 'Matematika'),
(647, 3, 'IPA', 'XI-IPA 1', 'Jumat', 1, 'YAYUK ISWATIN, S.Pd', 'Seni Budaya'),
(648, 3, 'IPA', 'XI-IPA 2', 'Jumat', 1, 'ALY FUADI, S.Pd.', 'Fisika'),
(649, 3, 'IPS', 'XI-IPS 1', 'Jumat', 1, 'AGUS SALIM, S.Pd.', 'Bahasa Inggris'),
(650, 3, 'IPS', 'XI-IPS 2', 'Jumat', 1, 'Drs. ABD. SALAM HS.', 'Fiqih'),
(651, 3, 'AGAMA', 'XI-AGAMA', 'Jumat', 1, 'ARIF MUSTOFA, S.Ag., M.Pd.', 'Ushul Fiqih'),
(652, 3, 'IPA', 'XII-IPA 1', 'Jumat', 1, 'NUR JANAH, S.Pd', 'Keterampilan'),
(653, 3, 'IPA', 'XII-IPA 2', 'Jumat', 1, 'SAYUDI, S. Pd.', 'Bahasa Indonesia'),
(654, 3, 'IPS', 'XII-IPS 1', 'Jumat', 1, 'Dra. SUWINARTI', 'Geografi'),
(655, 3, 'IPS', 'XII-IPS 2', 'Jumat', 1, 'MOHAMAD AFIF FARICHIN, M.Pd.I.', 'Muhadatsah'),
(656, 3, 'AGAMA', 'XII-AGAMA', 'Jumat', 1, 'Drs. ABAS SIMAN', 'Pendidikan Kewarganegaraan'),
(657, 3, 'IPA', 'X-MIPA1', 'Jumat', 2, 'SURAWAN, S.Pd.', 'Kimia'),
(658, 3, 'IPA', 'X-MIPA2', 'Jumat', 2, 'NUR JANAH, S.Pd', 'Keterampilan'),
(659, 3, 'IPA', 'X-MIPA3', 'Jumat', 2, 'MARDWI ASDIYANTO, M.Pd.I.', 'S K I'),
(660, 3, 'IPS', 'X-IPS1', 'Jumat', 2, 'ARIF MUSTOFA, S.Ag., M.Pd.', 'Fiqih'),
(661, 3, 'IPS', 'X-IPS2', 'Jumat', 2, 'HADIAH, S.Pd.', 'Ekonomi'),
(662, 3, 'AGAMA', 'X-IAG', 'Jumat', 2, 'SAYUDI, S. Pd.', 'Bahasa Indonesia'),
(663, 3, 'IPA', 'XI-IPA 1', 'Jumat', 2, 'ANITA KURNIA RAHAYU, S.P.', 'Biologi'),
(664, 3, 'IPA', 'XI-IPA 2', 'Jumat', 2, 'YUDHA KURNIAWAN, S.Pd.', 'Pendidikan Jasmani, ORKES'),
(665, 3, 'IPS', 'XI-IPS 1', 'Jumat', 2, 'Dra. ULUMIYAH', 'BKTI'),
(666, 3, 'IPS', 'XI-IPS 2', 'Jumat', 2, 'Dra. AGUS SETYANINGSIH, M.Si', 'Matematika'),
(667, 3, 'AGAMA', 'XI-AGAMA', 'Jumat', 2, 'MARIFA RIAMA, S.Pd.', 'Sejarah'),
(668, 3, 'IPA', 'XII-IPA 1', 'Jumat', 2, 'AHERI SUGIHARTONO, S.Th.I', 'Aqidah Akhlak'),
(669, 3, 'IPA', 'XII-IPA 2', 'Jumat', 2, 'WIWIN SISWINARNI, S.Pd.', 'Pendidikan Kewarganegaraan'),
(670, 3, 'IPS', 'XII-IPS 1', 'Jumat', 2, 'MOHAMAD AFIF FARICHIN, M.Pd.I.', 'Muhadatsah'),
(671, 3, 'IPS', 'XII-IPS 2', 'Jumat', 2, 'ISMI MARIYAM, S.Pd.', 'Bhs & Sastra Ind'),
(672, 3, 'AGAMA', 'XII-AGAMA', 'Jumat', 2, 'AGUS SALIM, S.Pd.', 'Bahasa Inggris'),
(673, 3, 'IPA', 'X-MIPA1', 'Jumat', 3, 'TEGUH KOESTANTININGSIH, S.Pd', 'Keterampilan'),
(674, 3, 'IPA', 'X-MIPA2', 'Jumat', 3, 'MOHAMAD AFIF FARICHIN, M.Pd.I.', 'Muhadatsah'),
(675, 3, 'IPA', 'X-MIPA3', 'Jumat', 3, 'ENNI SUBCHANDINI, S.Pd', 'Kimia'),
(676, 3, 'IPS', 'X-IPS1', 'Jumat', 3, 'NURUL AINI, S.Pd', 'Matematika'),
(677, 3, 'IPS', 'X-IPS2', 'Jumat', 3, 'NASHRUL ULUM, S.Pd.', 'S K I'),
(678, 3, 'AGAMA', 'X-IAG', 'Jumat', 3, 'Dra. ULUMIYAH', 'BKTI'),
(679, 3, 'IPA', 'XI-IPA 1', 'Jumat', 3, 'ARYS SUSANTO, M.Pd', 'Fisika'),
(680, 3, 'IPA', 'XI-IPA 2', 'Jumat', 3, 'MARIFA RIAMA, S.Pd.', 'Sejarah'),
(681, 3, 'IPS', 'XI-IPS 1', 'Jumat', 3, 'Drs. ABD. SALAM HS.', 'Fiqih'),
(682, 3, 'IPS', 'XI-IPS 2', 'Jumat', 3, 'Drs. ABAS SIMAN', 'Pendidikan Kewarganegaraan'),
(683, 3, 'AGAMA', 'XI-AGAMA', 'Jumat', 3, 'Drs. YUDI SYAIFULLOH', 'Pendidikan Jasmani, ORKES'),
(684, 3, 'IPA', 'XII-IPA 1', 'Jumat', 3, 'EDDI HARIYADI, S,Pd.', 'Seni Budaya'),
(685, 3, 'IPA', 'XII-IPA 2', 'Jumat', 3, 'MUHAMMAD SUWAR, S.Pd.I.', 'Bahasa Arab'),
(686, 3, 'IPS', 'XII-IPS 1', 'Jumat', 3, 'AHERI SUGIHARTONO, S.Th.I', 'Aqidah Akhlak'),
(687, 3, 'IPS', 'XII-IPS 2', 'Jumat', 3, 'WIJI LAELATUL JUMAH, S.Pd.', 'Bahasa Indonesia'),
(688, 3, 'AGAMA', 'XII-AGAMA', 'Jumat', 3, 'NUR RAHMAWATI, S.Pd', 'Bhs & Sastra Ind'),
(689, 3, 'IPA', 'X-MIPA1', 'Jumat', 4, 'Drs. DENNY MF., S.Pd.', 'Fisika'),
(690, 3, 'IPA', 'X-MIPA2', 'Jumat', 4, 'YUDHA KURNIAWAN, S.Pd.', 'Pendidikan Jasmani, ORKES'),
(691, 3, 'IPA', 'X-MIPA3', 'Jumat', 4, 'Drs. ALI MUSTOFA, M.Pd', 'Geografi'),
(692, 3, 'IPS', 'X-IPS1', 'Jumat', 4, 'MOHAMAD AFIF FARICHIN, M.Pd.I.', 'Muhadatsah'),
(693, 3, 'IPS', 'X-IPS2', 'Jumat', 4, 'AHERI SUGIHARTONO, S.Th.I', 'Aqidah Akhlak'),
(694, 3, 'AGAMA', 'X-IAG', 'Jumat', 4, 'ARIF MUSTOFA, S.Ag., M.Pd.', 'Ushul Fiqih'),
(695, 3, 'IPA', 'XI-IPA 1', 'Jumat', 4, 'Dra. AGUS SETYANINGSIH, M.Si', 'Matematika'),
(696, 3, 'IPA', 'XI-IPA 2', 'Jumat', 4, 'SITI MARIA ULFAH, S.Pd.I', 'Al Quran Hadis'),
(697, 3, 'IPS', 'XI-IPS 1', 'Jumat', 4, 'TEGUH KOESTANTININGSIH, S.Pd', 'Keterampilan'),
(698, 3, 'IPS', 'XI-IPS 2', 'Jumat', 4, 'USMAN, S.Pd.', 'Bahasa Indonesia'),
(699, 3, 'AGAMA', 'XI-AGAMA', 'Jumat', 4, 'ISMI MARIYAM, S.Pd.', 'Bhs & Sastra Ind'),
(700, 3, 'IPA', 'XII-IPA 1', 'Jumat', 4, 'ANITA KURNIA RAHAYU, S.P.', 'Biologi'),
(701, 3, 'IPA', 'XII-IPA 2', 'Jumat', 4, 'MARIFA RIAMA, S.Pd.', 'Sejarah'),
(702, 3, 'IPS', 'XII-IPS 1', 'Jumat', 4, 'EDDI HARIYADI, S,Pd.', 'Seni Budaya'),
(703, 3, 'IPS', 'XII-IPS 2', 'Jumat', 4, 'Drs. ABAS SIMAN', 'Pendidikan Kewarganegaraan'),
(704, 3, 'AGAMA', 'XII-AGAMA', 'Jumat', 4, 'MOHAMAD AFIF FARICHIN, M.Pd.I.', 'Bahasa Arab'),
(705, 3, 'IPA', 'X-MIPA1', 'Jumat', 5, 'Drs. ABD. SALAM HS.', 'Fiqih'),
(706, 3, 'IPA', 'X-MIPA2', 'Jumat', 5, 'HANIM NURUL AINI, S.Pd.', 'Bahasa Indonesia'),
(707, 3, 'IPA', 'X-MIPA3', 'Jumat', 5, 'INSA ASYAROH, S.Ag', 'Al Quran Hadis'),
(708, 3, 'IPS', 'X-IPS1', 'Jumat', 5, 'YAYUK ISWATIN, S.Pd', 'Seni Budaya'),
(709, 3, 'IPS', 'X-IPS2', 'Jumat', 5, 'Dra. SUWINARTI', 'Geografi'),
(710, 3, 'AGAMA', 'X-IAG', 'Jumat', 5, 'MOHAMAD AFIF FARICHIN, M.Pd.I.', 'Muhadatsah'),
(711, 3, 'IPA', 'XI-IPA 1', 'Jumat', 5, 'Drs. YUDI SYAIFULLOH', 'Pendidikan Jasmani, ORKES'),
(712, 3, 'IPA', 'XI-IPA 2', 'Jumat', 5, 'ARI KUSUMAWATI, M.Pd', 'Matematika'),
(713, 3, 'IPS', 'XI-IPS 1', 'Jumat', 5, 'MUHAMMAD SUWAR, S.Pd.I.', 'Bahasa Arab'),
(714, 3, 'IPS', 'XI-IPS 2', 'Jumat', 5, 'ISMI MARIYAM, S.Pd.', 'Bhs & Sastra Ind'),
(715, 3, 'AGAMA', 'XI-AGAMA', 'Jumat', 5, 'Dra. ULUMIYAH', 'BKTI'),
(716, 3, 'IPA', 'XII-IPA 1', 'Jumat', 5, 'TRI SUDIK WIYONO, S.Pd', 'Ekonomi'),
(717, 3, 'IPA', 'XII-IPA 2', 'Jumat', 5, 'Drs. MOKH. HASAN B., M.Pd.', 'Fisika'),
(718, 3, 'IPS', 'XII-IPS 1', 'Jumat', 5, 'NASHRUL ULUM, S.Pd.', 'S K I'),
(719, 3, 'IPS', 'XII-IPS 2', 'Jumat', 5, 'AGUS SALIM, S.Pd.', 'Bahasa Inggris'),
(720, 3, 'AGAMA', 'XII-AGAMA', 'Jumat', 5, 'NUR JANAH, S.Pd', 'Keterampilan'),
(721, 3, 'IPA', 'X-MIPA1', 'Jumat', 6, 'WIJI LAELATUL JUMAH, S.Pd.', 'Bahasa Indonesia'),
(722, 3, 'IPA', 'X-MIPA2', 'Jumat', 6, 'ALIFIYAH RUSDIYANA, S.Pd.', 'Bahasa Inggris'),
(723, 3, 'IPA', 'X-MIPA3', 'Jumat', 6, 'ARYS SUSANTO, M.Pd', 'Fisika'),
(724, 3, 'IPS', 'X-IPS1', 'Jumat', 6, 'TEGUH KOESTANTININGSIH, S.Pd', 'Keterampilan'),
(725, 3, 'IPS', 'X-IPS2', 'Jumat', 6, 'NUR RAHMAWATI, S.Pd', 'Bhs & Sastra Ind'),
(726, 3, 'AGAMA', 'X-IAG', 'Jumat', 6, 'ARIF MUSTOFA, S.Ag., M.Pd.', 'Fiqih'),
(727, 3, 'IPA', 'XI-IPA 1', 'Jumat', 6, 'HADIAH, S.Pd.', 'Ekonomi'),
(728, 3, 'IPA', 'XI-IPA 2', 'Jumat', 6, 'ANITA KURNIA RAHAYU, S.P.', 'Biologi'),
(729, 3, 'IPS', 'XI-IPS 1', 'Jumat', 6, 'Drs. ABAS SIMAN', 'Pendidikan Kewarganegaraan'),
(730, 3, 'IPS', 'XI-IPS 2', 'Jumat', 6, 'MOHAMAD AFIF FARICHIN, M.Pd.I.', 'Muhadatsah'),
(731, 3, 'AGAMA', 'XI-AGAMA', 'Jumat', 6, 'UMAR FARUQ, S.Ag.', 'Ilmu Kalam'),
(732, 3, 'IPA', 'XII-IPA 1', 'Jumat', 6, 'INSA ASYAROH, S.Ag', 'Al Quran Hadis'),
(733, 3, 'IPA', 'XII-IPA 2', 'Jumat', 6, 'Dra. ULUMIYAH', 'BKTI'),
(734, 3, 'IPS', 'XII-IPS 1', 'Jumat', 6, 'NURUL AINI, S.Pd', 'Matematika'),
(735, 3, 'IPS', 'XII-IPS 2', 'Jumat', 6, 'NASHRUL ULUM, S.Pd.', 'Sosiologi'),
(736, 3, 'AGAMA', 'XII-AGAMA', 'Jumat', 6, 'Drs. AKHMAD EFENDI', 'Teknologi Informasi Komunikasi'),
(737, 3, 'IPA', 'X-MIPA1', 'Jumat', 7, 'Dra. AGUS SETYANINGSIH, M.Si', 'Matematika'),
(738, 3, 'IPA', 'X-MIPA2', 'Jumat', 7, 'YAYUK ISWATIN, S.Pd', 'Seni Budaya'),
(739, 3, 'IPA', 'X-MIPA3', 'Jumat', 7, 'ARIF MUSTOFA, S.Ag., M.Pd.', 'Fiqih'),
(740, 3, 'IPS', 'X-IPS1', 'Jumat', 7, 'NUR RAHMAWATI, S.Pd', 'Bhs & Sastra Ind'),
(741, 3, 'IPS', 'X-IPS2', 'Jumat', 7, 'Dra. ULUMIYAH', 'BKTI'),
(742, 3, 'AGAMA', 'X-IAG', 'Jumat', 7, 'INSA ASYAROH, S.Ag', 'Ilmu Hadits'),
(743, 3, 'IPA', 'XI-IPA 1', 'Jumat', 7, 'NUR RAHMAWATI, S.Pd', 'Bahasa Indonesia'),
(744, 3, 'IPA', 'XI-IPA 2', 'Jumat', 7, 'AHERI SUGIHARTONO, S.Th.I', 'Aqidah Akhlak'),
(745, 3, 'IPS', 'XI-IPS 1', 'Jumat', 7, 'Drs. YUDI SYAIFULLOH', 'Pendidikan Jasmani, ORKES'),
(746, 3, 'IPS', 'XI-IPS 2', 'Jumat', 7, 'TEGUH KOESTANTININGSIH, S.Pd', 'Keterampilan'),
(747, 3, 'AGAMA', 'XI-AGAMA', 'Jumat', 7, 'Drs. AKHMAD EFENDI', 'Teknologi Informasi Komunikasi'),
(748, 3, 'IPA', 'XII-IPA 1', 'Jumat', 7, 'MARIFA RIAMA, S.Pd.', 'Sejarah'),
(749, 3, 'IPA', 'XII-IPA 2', 'Jumat', 7, 'SITI MARIA ULFAH, S.Pd.I', 'Al Quran Hadis'),
(750, 3, 'IPS', 'XII-IPS 1', 'Jumat', 7, 'WIWIN SISWINARNI, S.Pd.', 'Pendidikan Kewarganegaraan'),
(751, 3, 'IPS', 'XII-IPS 2', 'Jumat', 7, 'MUHAMMAD SUWAR, S.Pd.I.', 'Bahasa Arab'),
(752, 3, 'AGAMA', 'XII-AGAMA', 'Jumat', 7, 'MARDWI ASDIYANTO, M.Pd.I.', 'Ilmu Tafsir'),
(753, 3, 'IPA', 'X-MIPA1', 'Jumat', 8, 'ANITA KURNIA RAHAYU, S.P.', 'Biologi'),
(754, 3, 'IPA', 'X-MIPA2', 'Jumat', 8, 'SURAWAN, S.Pd.', 'Kimia'),
(755, 3, 'IPA', 'X-MIPA3', 'Jumat', 8, 'TRI SUDIK WIYONO, S.Pd', 'Ekonomi'),
(756, 3, 'IPS', 'X-IPS1', 'Jumat', 8, 'NASHRUL ULUM, S.Pd.', 'Sosiologi'),
(757, 3, 'IPS', 'X-IPS2', 'Jumat', 8, 'SURAWAN, S.Pd.', 'Bahasa Inggris'),
(758, 3, 'AGAMA', 'X-IAG', 'Jumat', 8, 'EDDI HARIYADI, S,Pd.', 'Seni Budaya'),
(759, 3, 'IPA', 'XI-IPA 1', 'Jumat', 8, 'NUR JANAH, S.Pd', 'Keterampilan'),
(760, 3, 'IPA', 'XI-IPA 2', 'Jumat', 8, 'ISMI MARIYAM, S.Pd.', 'Bahasa Indonesia'),
(761, 3, 'IPS', 'XI-IPS 1', 'Jumat', 8, 'Dra. SUWINARTI', 'Geografi'),
(762, 3, 'IPS', 'XI-IPS 2', 'Jumat', 8, 'MARIFA RIAMA, S.Pd.', 'Sejarah'),
(763, 3, 'AGAMA', 'XI-AGAMA', 'Jumat', 8, 'MARDWI ASDIYANTO, M.Pd.I.', 'Ilmu Tafsir'),
(764, 3, 'IPA', 'XII-IPA 1', 'Jumat', 8, 'Drs. ABD. SALAM HS.', 'Fiqih'),
(765, 3, 'IPA', 'XII-IPA 2', 'Jumat', 8, 'YUDHA KURNIAWAN, S.Pd.', 'Pendidikan Jasmani, ORKES'),
(766, 3, 'IPS', 'XII-IPS 1', 'Jumat', 8, 'Dra. ULUMIYAH', 'BKTI'),
(767, 3, 'IPS', 'XII-IPS 2', 'Jumat', 8, 'MARDWI ASDIYANTO, M.Pd.I.', 'S K I'),
(768, 3, 'AGAMA', 'XII-AGAMA', 'Jumat', 8, 'NURUL AINI, S.Pd', 'Matematika');

-- --------------------------------------------------------

--
-- Table structure for table `guru`
--

CREATE TABLE `guru` (
  `idguru` int(11) NOT NULL,
  `nama_guru` varchar(200) NOT NULL,
  `mapel_ajar` varchar(200) NOT NULL,
  `jurusannya` varchar(200) NOT NULL,
  `kelas_ajar` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `guru`
--

INSERT INTO `guru` (`idguru`, `nama_guru`, `mapel_ajar`, `jurusannya`, `kelas_ajar`) VALUES
(1, '1234567890 - Drs. DENNY MF., S.Pd.', 'Fisika', 'IPA', 'X-MIPA1'),
(2, '1234567890 - INGRID ARIANY SAVITRI, S.Pd.', 'Biologi', 'IPA', 'X-MIPA1'),
(3, '1234567890 - Drs. YUDI SYAIFULLOH', 'Pendidikan Jasmani, ORKES', 'IPA', 'X-MIPA1'),
(4, '1234567890 - Drs. YUDI SYAIFULLOH', 'Pendidikan Jasmani, ORKES', 'IPS', 'X-IPS1'),
(5, '1234567890 - Drs. MOKH. HASAN B., M.Pd.', 'Fisika', 'IPA', 'X-MIPA2'),
(6, '1234567890 - Dra. MAZIDAH INAYATI', 'Matematika', 'IPA', 'X-MIPA1'),
(7, '1234567890 - ENNI SUBCHANDINI, S.Pd', 'Kimia', 'IPA', 'X-MIPA1'),
(8, '1234567890 - Drs. ABD. SALAM HS.', 'Fiqih', 'IPA', 'X-MIPA1'),
(9, '1234567890 - Drs. ABD. SALAM HS.', 'Fiqih', 'IPS', 'X-IPS1'),
(10, '1234567890 - Drs. ABD. SALAM HS.', 'Fiqih', 'AGAMA', 'X-IAG'),
(11, '1234567890 - Drs. ABD. SALAM HS.', 'Ushul Fiqih', 'AGAMA', 'X-IAG'),
(12, '1234567890 - SAYUDI, S. Pd.', 'Bahasa Indonesia', 'AGAMA', 'X-IAG'),
(13, '1234567890 - HADIAH, S.Pd.', 'Ekonomi', 'IPS', 'X-IPS1'),
(14, '1234567890 - TEGUH KOESTANTININGSIH, S.Pd', 'Keterampilan', 'IPA', 'X-MIPA1'),
(15, '1234567890 - Drs. AKHMAD EFENDI', 'Teknologi Informasi Komunikasi', 'IPA', 'X-MIPA1'),
(16, '1234567890 - Drs. ALI MUSTOFA, M.Pd', 'Geografi', 'IPA', 'X-MIPA1'),
(17, '1234567890 - Dra. SUWINARTI', 'Geografi', 'IPS', 'X-IPS1'),
(18, '1234567890 - ALIFIYAH RUSDIYANA, S.Pd.', 'Bahasa Inggris', 'IPA', 'X-MIPA1'),
(19, '1234567890 - NUR JANAH, S.Pd', 'Keterampilan', 'AGAMA', 'X-MIPA1'),
(20, '1234567890 - Dra. AGUS SETYANINGSIH, M.Si', 'Matematika', 'IPA', 'X-MIPA2'),
(21, '1234567890 - Drs. YUDI SYAIFULLOH', 'Pendidikan Jasmani, ORKES', 'AGAMA', 'X-IAG'),
(22, '1234567890 - SAYUDI, S. Pd.', 'Bahasa Indonesia', 'IPA', 'X-MIPA2'),
(23, '1234567890 - HADIAH, S.Pd.', 'Ekonomi', 'IPA', 'X-MIPA2'),
(24, '1234567890 - TEGUH KOESTANTININGSIH, S.Pd', 'Keterampilan', 'IPS', 'X-IPS1'),
(25, '1234567890 - Drs. AKHMAD EFENDI', 'Teknologi Informasi Komunikasi', 'IPS', 'X-IPS1'),
(26, '1234567890 - Drs. ALI MUSTOFA, M.Pd', 'Geografi', 'IPS', ''),
(27, '1234567890 - Dra. SUWINARTI', 'Geografi', 'IPA', ''),
(28, '1234567890 - ALIFIYAH RUSDIYANA, S.Pd.', 'Bahasa Inggris', 'AGAMA', ''),
(29, '1234567890 - NUR JANAH, S.Pd', 'Keterampilan', 'IPA', ''),
(30, '1234567890 - Dra. AGUS SETYANINGSIH, M.Si', 'Matematika', 'AGAMA', ''),
(31, '1234567890 - USMAN, S.Pd.', 'Bahasa Indonesia', 'AGAMA', 'X-IAG'),
(32, '1234567890 - Dra. ULUMIYAH', 'BKTI', 'IPS', ''),
(34, '1234567890 - TEGUH KOESTANTININGSIH, S.Pd', 'Keterampilan', 'AGAMA', ''),
(35, '1234567890 - Drs. AKHMAD EFENDI', 'Teknologi Informasi Komunikasi', 'AGAMA', ''),
(36, '1234567890 - Dra. ULUMIYAH', 'BKTI', 'AGAMA', ''),
(37, '1234567890 - YUDHA KURNIAWAN, S.Pd.', 'Pendidikan Jasmani, ORKES', 'IPA', ''),
(40, '1234567890 - Dra. AGUS SETYANINGSIH, M.Si', 'Matematika', 'IPS', ''),
(41, '1234567890 - USMAN, S.Pd.', 'Bahasa Indonesia', 'IPS', ''),
(42, '1234567890 - Dra. ULUMIYAH', 'BKTI', 'IPA', ''),
(43, '1234567890 - YUDHA KURNIAWAN, S.Pd.', 'Pendidikan Jasmani, ORKES', 'AGAMA', ''),
(44, '1234567890 - WIWIN SISWINARNI, S.Pd.', 'Pendidikan Kewarganegaraan', 'IPS', ''),
(45, '1234567890 - WIJI LAELATUL JUMAH, S.Pd.', 'Bahasa Indonesia', 'IPS', ''),
(46, '1234567890 - TRI SUDIK WIYONO, S.Pd', 'Ekonomi', 'IPS', ''),
(47, '1234567890 - ALIEF PURNOMO AJU, S.Pd.', 'Kimia', 'IPA', ''),
(48, '1234567890 - SURAWAN, S.Pd.', 'Bahasa Inggris', 'IPS', ''),
(49, '1234567890 - MARIFA RIAMA, S.Pd.', 'Sejarah', 'AGAMA', ''),
(50, '1234567890 - ARI KUSUMAWATI, M.Pd', 'Matematika', 'IPA', ''),
(51, '1234567890 - YAYUK ISWATIN, S.Pd', 'Seni Budaya', 'AGAMA', ''),
(52, '1234567890 - NURUL AINI, S.Pd', 'Matematika', 'AGAMA', ''),
(53, '1234567890 - NENI SUHARTINI, S.Pd, M.Psi', 'BK', 'IPA', ''),
(54, '1234567890 - WIWIN SISWINARNI, S.Pd.', 'Pendidikan Kewarganegaraan', 'IPA', ''),
(55, '1234567890 - WIJI LAELATUL JUMAH, S.Pd.', 'Bahasa Indonesia', 'IPA', ''),
(56, '1234567890 - TRI SUDIK WIYONO, S.Pd', 'Ekonomi', 'IPA', ''),
(57, '1234567890 - ARYS SUSANTO, M.Pd', 'Fisika', 'IPA', ''),
(58, '1234567890 - SURAWAN, S.Pd.', 'Bahasa Inggris', 'AGAMA', ''),
(59, '1234567890 - MARIFA RIAMA, S.Pd.', 'Sejarah', 'IPA', ''),
(60, '1234567890 - ANITA KURNIA RAHAYU, S.P.', 'Biologi', 'IPA', ''),
(61, '1234567890 - YAYUK ISWATIN, S.Pd', 'Seni Budaya', 'IPS', ''),
(62, '1234567890 - NURUL AINI, S.Pd', 'Matematika', 'IPA', ''),
(63, '1234567890 - ARYS SUSANTO, M.Pd', 'Fisika', 'IPA', ''),
(64, '1234567890 - WIWIN SISWINARNI, S.Pd.', 'Pendidikan Kewarganegaraan', 'AGAMA', ''),
(65, '1234567890 - ARIF MUSTOFA, S.Ag., M.Pd.', 'Fiqih', 'IPA', ''),
(66, '1234567890 - MUHAMMAD SUWAR, S.Pd.I.', 'Bahasa Arab', 'IPA', ''),
(67, '1234567890 - ISMI MARIYAM, S.Pd.', 'Bahasa Indonesia', 'IPA', ''),
(68, '1234567890 - MARIFA RIAMA, S.Pd.', 'Sejarah', 'IPS', ''),
(69, '1234567890 - SURAWAN, S.Pd.', 'Bahasa Inggris', 'IPA', ''),
(70, '1234567890 - ARIF MUSTOFA, S.Ag., M.Pd.', 'Ushul Fiqih', 'AGAMA', ''),
(71, '1234567890 - YAYUK ISWATIN, S.Pd', 'Seni Budaya', 'IPA', ''),
(72, '1234567890 - NURUL AINI, S.Pd', 'Matematika', 'IPS', ''),
(73, '1234567890 - NENI SUHARTINI, S.Pd, M.Psi', 'BK', 'AGAMA', ''),
(74, '1234567890 - MUHAMMAD SUWAR, S.Pd.I.', 'Bahasa Arab', 'IPS', ''),
(75, '1234567890 - ARIF MUSTOFA, S.Ag., M.Pd.', 'Fiqih', 'AGAMA', ''),
(76, '1234567890 - ISMI MARIYAM, S.Pd.', 'Bhs & Sastra Ind', 'IPS', ''),
(77, '1234567890 - NUR RAHMAWATI, S.Pd', 'Bahasa Indonesia', 'IPA', ''),
(78, '1234567890 - AHERI SUGIHARTONO, S.Th.I', 'Aqidah Akhlak', 'IPA', ''),
(79, '1234567890 - MOCH. FARID WADJIDI Lc, S.Pd.', 'Biologi', 'IPA', ''),
(80, '1234567890 - MUHAMMAD SUWAR, S.Pd.I.', 'Bahasa Arab', 'AGAMA', ''),
(81, '1234567890 - ISMI MARIYAM, S.Pd.', 'Bhs & Sastra Ind', 'AGAMA', ''),
(82, '1234567890 - NUR RAHMAWATI, S.Pd', 'Bhs & Sastra Ind', 'IPS', ''),
(83, '1234567890 - AHERI SUGIHARTONO, S.Th.I', 'Aqidah Akhlak', 'IPS', ''),
(84, '1234567890 - INSA ASYAROH, S.Ag', 'Al Quran Hadis', 'IPS', ''),
(85, '1234567890 - ARIF MUSTOFA, S.Ag., M.Pd.', 'Fiqih', 'IPS', ''),
(86, '1234567890 - NUR RAHMAWATI, S.Pd', 'Bhs & Sastra Ind', 'AGAMA', ''),
(87, '1234567890 - SURAWAN, S.Pd.', 'Kimia', 'IPA', ''),
(88, '1234567890 - Drs. ABAS SIMAN', 'Pendidikan Kewarganegaraan', 'IPA', ''),
(90, '1234567890 - AHERI SUGIHARTONO, S.Th.I', 'Aqidah Akhlak', 'AGAMA', ''),
(91, '1234567890 - INSA ASYAROH, S.Ag', 'Al Quran Hadis', 'IPA', ''),
(92, '1234567890 - SITI MARIA ULFAH, S.Pd.I', 'Al Quran Hadis', 'IPA', ''),
(93, '1234567890 - Drs. ABAS SIMAN', 'Pendidikan Kewarganegaraan', 'IPS', ''),
(94, '1234567890 - MURSALIN, ST, S.Pd', 'Matematika', 'IPA', ''),
(95, '1234567890 - INSA ASYAROH, S.Ag', 'Ilmu Hadits', 'AGAMA', ''),
(96, '1234567890 - SITI MARIA ULFAH, S.Pd.I', 'Ilmu Hadits', 'AGAMA', ''),
(97, '1234567890 - Drs. ABAS SIMAN', 'Pendidikan Kewarganegaraan', 'AGAMA', ''),
(98, '1234567890 - MURSALIN, ST, S.Pd', 'Matematika', 'AGAMA', ''),
(99, '1234567890 - HANIM NURUL AINI, S.Pd.', 'Bahasa Indonesia', 'IPA', ''),
(100, '1234567890 - AGUS SALIM, S.Pd.', 'Bahasa Inggris', 'IPS', ''),
(101, '1234567890 - EDDI HARIYADI, S,Pd.', 'Seni Budaya', 'IPA', ''),
(102, '1234567890 - MARDWI ASDIYANTO, M.Pd.I.', 'Ilmu Tafsir', 'AGAMA', ''),
(103, '1234567890 - NASHRUL ULUM, S.Pd.', 'Sosiologi', 'IPS', ''),
(104, '1234567890 - UMAR FARUQ, S.Ag.', 'Ilmu Kalam', 'AGAMA', ''),
(105, '1234567890 - AGUS SALIM, S.Pd.', 'Bahasa Inggris', 'AGAMA', ''),
(106, '1234567890 - EDDI HARIYADI, S,Pd.', 'Seni Budaya', 'AGAMA', ''),
(107, '1234567890 - MARDWI ASDIYANTO, M.Pd.I.', 'S K I', 'IPS', ''),
(108, '1234567890 - NASHRUL ULUM, S.Pd.', 'S K I', 'IPS', ''),
(109, '1234567890 - MARDWI ASDIYANTO, M.Pd.I.', 'S K I', 'IPA', ''),
(110, '1234567890 - EDDI HARIYADI, S,Pd.', 'Seni Budaya', 'IPS', ''),
(111, '1234567890 - ALY FUADI, S.Pd.', 'Fisika', 'IPA', ''),
(112, '1234567890 - FATUKHA, S.Pd.', 'Matematika', 'IPS', ''),
(113, '1234567890 - MOHAMAD AFIF FARICHIN, M.Pd.I.', 'Muhadatsah', 'IPS', ''),
(114, '1234567890 - MOHAMAD AFIF FARICHIN, M.Pd.I.', 'Bahasa Arab', 'AGAMA', ''),
(115, '1234567890 - MOHAMAD AFIF FARICHIN, M.Pd.I.', 'Muhadatsah', 'IPA', ''),
(116, '1234567890 - MOHAMAD AFIF FARICHIN, M.Pd.I.', 'Muhadatsah', 'AGAMA', '');

-- --------------------------------------------------------

--
-- Table structure for table `hari`
--

CREATE TABLE `hari` (
  `idhari` int(11) NOT NULL,
  `nama_hari` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `hari`
--

INSERT INTO `hari` (`idhari`, `nama_hari`) VALUES
(1, 'Senin'),
(2, 'Selasa'),
(3, 'Rabu'),
(4, 'Kamis'),
(5, 'Jumat');

-- --------------------------------------------------------

--
-- Table structure for table `jadwal`
--

CREATE TABLE `jadwal` (
  `idjadwal` int(11) NOT NULL,
  `hari` varchar(200) NOT NULL,
  `idguru` varchar(200) NOT NULL,
  `idjam` varchar(200) NOT NULL,
  `idperiode` varchar(200) NOT NULL,
  `idkelas` varchar(255) NOT NULL,
  `idjur` varchar(255) NOT NULL,
  `id_vertex` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `jadwal`
--

INSERT INTO `jadwal` (`idjadwal`, `hari`, `idguru`, `idjam`, `idperiode`, `idkelas`, `idjur`, `id_vertex`) VALUES
(1, 'Senin', '1234567890 - Drs. YUDI SYAIFULLOH ( Pendidikan Jasmani, ORKES / IPA )', '1 ( 06:45:00 - 07:30:00 )', 'Ganjil 2017 / 2018', 'X-MIPA1', 'IPA', '1'),
(2, 'Senin', '1234567890 - Drs. YUDI SYAIFULLOH ( Pendidikan Jasmani, ORKES / IPA )', '2 ( 07:30:00 - 08:15:00 )', 'Ganjil 2016 / 2017', 'X-MIPA1', 'IPA', '1'),
(3, 'Senin', '1234567890 - SAYUDI, S. Pd. ( Bahasa Indonesia / IPA )', '3 ( 08:15:00 - 09:00:00 )', 'Ganjil 2016 / 2017', 'X-MIPA1', 'IPA', '2'),
(4, 'Senin', '1234567890 - SAYUDI, S. Pd. ( Bahasa Indonesia / IPA )', '4 ( 09:00:00 - 09:45:00 )', 'Ganjil 2016 / 2017', 'X-MIPA1', 'IPA', '2'),
(5, 'Senin', '1234567890 - SURAWAN, S.Pd. ( Bahasa Inggris / IPA )', '5 ( 10:05:00 - 10:50:00 )', 'Ganjil 2016 / 2017', 'X-MIPA1', 'IPA', '3'),
(6, 'Senin', '1234567890 - SURAWAN, S.Pd. ( Bahasa Inggris / IPA )', '6 ( 10:50:00 - 11:30:00 )', 'Ganjil 2016 / 2017', 'X-MIPA1', 'IPA', '3'),
(7, 'Senin', '1234567890 - Drs. ABD. SALAM HS. ( Fiqih / IPA )', '7 ( 12:30:00 - 13:15:00 )', 'Ganjil 2016 / 2017', 'X-MIPA1', 'IPA', '4'),
(8, 'Senin', '1234567890 - Drs. ABD. SALAM HS. ( Fiqih / IPA )', '8 ( 13:15:00 - 14:00:00 )', 'Ganjil 2016 / 2017', 'X-MIPA1', 'IPA', '4'),
(9, 'Senin', '1234567890 - INSA ASYAROH, S.Ag ( Al Quran Hadis / IPA )', '9 ( 14:00:00 - 14:45:00 )', 'Ganjil 2016 / 2017', 'X-MIPA1', 'IPA', '5'),
(10, 'Senin', '1234567890 - INSA ASYAROH, S.Ag ( Al Quran Hadis / IPA )', '10 ( 14:45:00 - 15:30:00 )', 'Ganjil 2016 / 2017', 'X-MIPA1', 'IPA', '5'),
(11, 'Selasa', '1234567890 - AHERI SUGIHARTONO, S.Th.I ( Aqidah Akhlak / IPA )', '1 ( 06:45:00 - 07:30:00 )', 'Ganjil 2016 / 2017', 'X-MIPA1', 'IPA', '6'),
(12, 'Selasa', '1234567890 - AHERI SUGIHARTONO, S.Th.I ( Aqidah Akhlak / IPA )', '2 ( 07:30:00 - 08:15:00 )', 'Ganjil 2016 / 2017', 'X-MIPA1', 'IPA', '6'),
(13, 'Selasa', '1234567890 - MARDWI ASDIYANTO, M.Pd.I. ( S K I / IPA )', '3 ( 08:15:00 - 09:00:00 )', 'Ganjil 2016 / 2017', 'X-MIPA1', 'IPA', '7'),
(14, 'Selasa', '1234567890 - MARDWI ASDIYANTO, M.Pd.I. ( S K I / IPA )', '4 ( 09:00:00 - 09:45:00 )', 'Ganjil 2016 / 2017', 'X-MIPA1', 'IPA', '7'),
(15, 'Selasa', '1234567890 - Drs. ABAS SIMAN ( Pendidikan Kewarganegaraan / IPA )', '5 ( 10:05:00 - 10:50:00 )', 'Ganjil 2016 / 2017', 'X-MIPA1', 'IPA', '8'),
(16, 'Selasa', '1234567890 - Drs. ABAS SIMAN ( Pendidikan Kewarganegaraan / IPA )', '6 ( 10:50:00 - 11:30:00 )', 'Ganjil 2016 / 2017', 'X-MIPA1', 'IPA', '8'),
(17, 'Selasa', '1234567890 - SAYUDI, S. Pd. ( Bahasa Indonesia / IPA )', '7 ( 12:30:00 - 13:15:00 )', 'Ganjil 2016 / 2017', 'X-MIPA1', 'IPA', '2'),
(18, 'Selasa', '1234567890 - SAYUDI, S. Pd. ( Bahasa Indonesia / IPA )', '8 ( 13:15:00 - 14:00:00 )', 'Ganjil 2016 / 2017', 'X-MIPA1', 'IPA', '2'),
(19, 'Selasa', '1234567890 - MUHAMMAD SUWAR, S.Pd.I. ( Bahasa Arab / IPA )', '9 ( 14:00:00 - 14:45:00 )', 'Ganjil 2016 / 2017', 'X-MIPA1', 'IPA', '9'),
(20, 'Selasa', '1234567890 - MUHAMMAD SUWAR, S.Pd.I. ( Bahasa Arab / IPA )', '10 ( 14:45:00 - 15:30:00 )', 'Ganjil 2016 / 2017', 'X-MIPA1', 'IPA', '9'),
(21, 'Rabu', '1234567890 - SURAWAN, S.Pd. ( Bahasa Inggris / IPA )', '1 ( 06:45:00 - 07:30:00 )', 'Ganjil 2016 / 2017', 'X-MIPA1', 'IPA', '3'),
(22, 'Rabu', '1234567890 - SURAWAN, S.Pd. ( Bahasa Inggris / IPA )', '2 ( 07:30:00 - 08:15:00 )', 'Ganjil 2016 / 2017', 'X-MIPA1', 'IPA', '3'),
(23, 'Rabu', '1234567890 - MURSALIN, ST, S.Pd ( Matematika / IPA )', '3 ( 08:15:00 - 09:00:00 )', 'Ganjil 2016 / 2017', 'X-MIPA1', 'IPA', '10'),
(24, 'Rabu', '1234567890 - MURSALIN, ST, S.Pd ( Matematika / IPA )', '4 ( 09:00:00 - 09:45:00 )', 'Ganjil 2016 / 2017', 'X-MIPA1', 'IPA', '10'),
(25, 'Rabu', '1234567890 - MARIFA RIAMA, S.Pd. ( Sejarah / IPA )', '5 ( 10:05:00 - 10:50:00 )', 'Ganjil 2016 / 2017', 'X-MIPA1', 'IPA', '11'),
(26, 'Rabu', '1234567890 - MARIFA RIAMA, S.Pd. ( Sejarah / IPA )', '6 ( 10:50:00 - 11:30:00 )', 'Ganjil 2016 / 2017', 'X-MIPA1', 'IPA', '11'),
(27, 'Rabu', '1234567890 - ARYS SUSANTO, M.Pd ( Fisika / IPA )', '7 ( 12:30:00 - 13:15:00 )', 'Ganjil 2016 / 2017', 'X-MIPA1', 'IPA', '12'),
(28, 'Rabu', '1234567890 - ARYS SUSANTO, M.Pd ( Fisika / IPA )', '8 ( 13:15:00 - 14:00:00 )', 'Ganjil 2016 / 2017', 'X-MIPA1', 'IPA', '12'),
(29, 'Rabu', '1234567890 - SURAWAN, S.Pd. ( Kimia / IPA )', '9 ( 14:00:00 - 14:45:00 )', 'Ganjil 2016 / 2017', 'X-MIPA1', 'IPA', '3'),
(30, 'Rabu', '1234567890 - SURAWAN, S.Pd. ( Kimia / IPA )', '10 ( 14:45:00 - 15:30:00 )', 'Ganjil 2016 / 2017', 'X-MIPA1', 'IPA', '3'),
(31, 'Kamis', '1234567890 - MOCH. FARID WADJIDI Lc, S.Pd. ( Biologi / IPA )', '1 ( 06:45:00 - 07:30:00 )', 'Ganjil 2016 / 2017', 'X-MIPA1', 'IPA', '14'),
(32, 'Kamis', '1234567890 - MOCH. FARID WADJIDI Lc, S.Pd. ( Biologi / IPA )', '2 ( 07:30:00 - 08:15:00 )', 'Ganjil 2016 / 2017', 'X-MIPA1', 'IPA', '14'),
(33, 'Kamis', '1234567890 - Drs. ALI MUSTOFA, M.Pd ( Geografi / IPA )', '3 ( 08:15:00 - 09:00:00 )', 'Ganjil 2016 / 2017', 'X-MIPA1', 'IPA', '15'),
(34, 'Kamis', '1234567890 - Drs. ALI MUSTOFA, M.Pd ( Geografi / IPA )', '4 ( 09:00:00 - 09:45:00 )', 'Ganjil 2016 / 2017', 'X-MIPA1', 'IPA', '15'),
(35, 'Kamis', '1234567890 - TRI SUDIK WIYONO, S.Pd ( Ekonomi / IPA )', '5 ( 10:05:00 - 10:50:00 )', 'Ganjil 2016 / 2017', 'X-MIPA1', 'IPA', '16'),
(36, 'Kamis', '1234567890 - TRI SUDIK WIYONO, S.Pd ( Ekonomi / IPA )', '6 ( 10:50:00 - 11:30:00 )', 'Ganjil 2016 / 2017', 'X-MIPA1', 'IPA', '16'),
(37, 'Kamis', '1234567890 - YAYUK ISWATIN, S.Pd ( Seni Budaya / IPA )', '7 ( 12:30:00 - 13:15:00 )', 'Ganjil 2016 / 2017', 'X-MIPA1', 'IPA', '17'),
(38, 'Kamis', '1234567890 - YAYUK ISWATIN, S.Pd ( Seni Budaya / IPA )', '8 ( 13:15:00 - 14:00:00 )', 'Ganjil 2016 / 2017', 'X-MIPA1', 'IPS', '17'),
(39, 'Kamis', '1234567890 - MURSALIN, ST, S.Pd ( Matematika / IPA )', '9 ( 14:00:00 - 14:45:00 )', 'Ganjil 2016 / 2017', 'X-MIPA1', 'IPA', '10'),
(40, 'Kamis', '1234567890 - MURSALIN, ST, S.Pd ( Matematika / IPA )', '10 ( 14:45:00 - 15:30:00 )', 'Ganjil 2016 / 2017', 'X-MIPA1', 'IPA', '10'),
(41, 'Jumat', '1234567890 - MOCH. FARID WADJIDI Lc, S.Pd. ( Biologi / IPA )', '1 ( 06:45:00 - 07:30:00 )', 'Ganjil 2016 / 2017', 'X-MIPA1', 'IPA', '18'),
(42, 'Jumat', '1234567890 - MOCH. FARID WADJIDI Lc, S.Pd. ( Biologi / IPA )', '2 ( 07:30:00 - 08:15:00 )', 'Ganjil 2016 / 2017', 'X-MIPA1', 'IPA', '18'),
(43, 'Jumat', '1234567890 - NUR JANAH, S.Pd ( Keterampilan / IPA )', '3 ( 08:15:00 - 09:00:00 )', 'Ganjil 2016 / 2017', 'X-MIPA1', 'IPA', '19'),
(44, 'Jumat', '1234567890 - NUR JANAH, S.Pd ( Keterampilan / IPA )', '4 ( 09:00:00 - 09:45:00 )', 'Ganjil 2016 / 2017', 'X-MIPA1', 'IPA', '19'),
(45, 'Jumat', '1234567890 - NENI SUHARTINI, S.Pd, M.Psi ( BK / IPA )', '5 ( 10:05:00 - 10:50:00 )', 'Ganjil 2016 / 2017', 'X-MIPA1', 'IPA', '20'),
(46, 'Jumat', '1234567890 - NENI SUHARTINI, S.Pd, M.Psi ( BK / IPA )', '6 ( 10:50:00 - 11:30:00 )', 'Ganjil 2016 / 2017', 'X-MIPA1', 'IPA', '20'),
(47, 'Jumat', '1234567890 - MOHAMAD AFIF FARICHIN, M.Pd.I. ( Muhadatsah / IPA )', '7 ( 12:30:00 - 13:15:00 )', 'Ganjil 2016 / 2017', 'X-MIPA1', 'IPA', '13'),
(48, 'Jumat', '1234567890 - MOHAMAD AFIF FARICHIN, M.Pd.I. ( Muhadatsah / IPA )', '8 ( 13:15:00 - 14:00:00 )', 'Ganjil 2016 / 2017', 'X-MIPA1', 'IPA', '13'),
(49, 'Senin', '1234567890 - MOCH. FARID WADJIDI Lc, S.Pd. ( Biologi / IPA )', '1 ( 06:45:00 - 07:30:00 )', 'Ganjil 2016 / 2017', 'X-MIPA2', 'IPA', '18'),
(50, 'Senin', '1234567890 - MOCH. FARID WADJIDI Lc, S.Pd. ( Biologi / IPA )', '2 ( 07:30:00 - 08:15:00 )', 'Ganjil 2016 / 2017', 'X-MIPA2', 'IPA', '18'),
(51, 'Senin', '1234567890 - ARYS SUSANTO, M.Pd ( Fisika / IPA )', '3 ( 08:15:00 - 09:00:00 )', 'Ganjil 2016 / 2017', 'X-MIPA2', 'IPA', '12'),
(52, 'Senin', '1234567890 - ARYS SUSANTO, M.Pd ( Fisika / IPA )', '4 ( 09:00:00 - 09:45:00 )', 'Ganjil 2016 / 2017', 'X-MIPA2', 'IPA', '12'),
(53, 'Senin', '1234567890 - SURAWAN, S.Pd. ( Kimia / IPA )', '5 ( 10:05:00 - 10:50:00 )', 'Ganjil 2016 / 2017', 'X-MIPA2', 'IPA', '3'),
(54, 'Senin', '1234567890 - SURAWAN, S.Pd. ( Kimia / IPA )', '6 ( 10:50:00 - 11:30:00 )', 'Ganjil 2016 / 2017', 'X-MIPA2', 'IPA', '3'),
(55, 'Senin', '1234567890 - MOHAMAD AFIF FARICHIN, M.Pd.I. ( Muhadatsah / IPA )', '7 ( 12:30:00 - 13:15:00 )', 'Ganjil 2016 / 2017', 'X-MIPA2', 'IPA', '13'),
(56, 'Senin', '1234567890 - MOHAMAD AFIF FARICHIN, M.Pd.I. ( Muhadatsah / IPA )', '8 ( 13:15:00 - 14:00:00 )', 'Ganjil 2016 / 2017', 'X-MIPA2', 'IPA', '13'),
(57, 'Senin', '1234567890 - NENI SUHARTINI, S.Pd, M.Psi ( BK / IPA )', '9 ( 14:00:00 - 14:45:00 )', 'Ganjil 2017 / 2018', 'X-MIPA2', 'IPA', '20'),
(58, 'Senin', '1234567890 - NENI SUHARTINI, S.Pd, M.Psi ( BK / IPA )', '10 ( 14:45:00 - 15:30:00 )', 'Ganjil 2017 / 2018', 'X-MIPA2', 'IPA', '20'),
(59, 'Selasa', '1234567890 - MOCH. FARID WADJIDI Lc, S.Pd. ( Biologi / IPA )', '1 ( 06:45:00 - 07:30:00 )', 'Ganjil 2017 / 2018', 'X-MIPA2', 'IPA', '18'),
(60, 'Selasa', '1234567890 - MOCH. FARID WADJIDI Lc, S.Pd. ( Biologi / IPA )', '2 ( 07:30:00 - 08:15:00 )', 'Ganjil 2017 / 2018', 'X-MIPA2', 'IPA', '18'),
(61, 'Selasa', '1234567890 - MURSALIN, ST, S.Pd ( Matematika / IPA )', '3 ( 08:15:00 - 09:00:00 )', 'Ganjil 2017 / 2018', 'X-MIPA2', 'IPA', '10'),
(62, 'Selasa', '1234567890 - MURSALIN, ST, S.Pd ( Matematika / IPA )', '4 ( 09:00:00 - 09:45:00 )', 'Ganjil 2017 / 2018', 'X-MIPA2', 'IPA', '10'),
(63, 'Selasa', '1234567890 - Drs. YUDI SYAIFULLOH ( Pendidikan Jasmani, ORKES / IPA )', '5 ( 10:05:00 - 10:50:00 )', 'Ganjil 2017 / 2018', 'X-MIPA2', 'IPA', '1'),
(64, 'Selasa', '1234567890 - Drs. YUDI SYAIFULLOH ( Pendidikan Jasmani, ORKES / IPA )', '6 ( 10:50:00 - 11:30:00 )', 'Ganjil 2017 / 2018', 'X-MIPA2', 'IPA', '1'),
(65, 'Selasa', '1234567890 - YAYUK ISWATIN, S.Pd ( Seni Budaya / IPA )', '7 ( 12:30:00 - 13:15:00 )', 'Ganjil 2017 / 2018', 'X-MIPA2', 'IPA', '17'),
(66, 'Selasa', '1234567890 - YAYUK ISWATIN, S.Pd ( Seni Budaya / IPA )', '8 ( 13:15:00 - 14:00:00 )', 'Ganjil 2017 / 2018', 'X-MIPA2', 'IPA', '17'),
(67, 'Selasa', '1234567890 - TRI SUDIK WIYONO, S.Pd ( Ekonomi / IPA )', '9 ( 14:00:00 - 14:45:00 )', 'Ganjil 2017 / 2018', 'X-MIPA2', 'IPA', '16'),
(68, 'Selasa', '1234567890 - TRI SUDIK WIYONO, S.Pd ( Ekonomi / IPA )', '10 ( 14:45:00 - 15:30:00 )', 'Ganjil 2017 / 2018', 'X-MIPA2', 'IPA', '16'),
(69, 'Rabu', '1234567890 - Drs. ALI MUSTOFA, M.Pd ( Geografi / IPA )', '1 ( 06:45:00 - 07:30:00 )', 'Ganjil 2017 / 2018', 'X-MIPA2', 'IPA', '15'),
(70, 'Rabu', '1234567890 - Drs. ALI MUSTOFA, M.Pd ( Geografi / IPA )', '2 ( 07:30:00 - 08:15:00 )', 'Ganjil 2017 / 2018', 'X-MIPA2', 'IPA', '15'),
(71, 'Rabu', '1234567890 - MOCH. FARID WADJIDI Lc, S.Pd. ( Biologi / IPA )', '3 ( 08:15:00 - 09:00:00 )', 'Ganjil 2017 / 2018', 'X-MIPA2', 'IPA', '18'),
(72, 'Rabu', '1234567890 - MOCH. FARID WADJIDI Lc, S.Pd. ( Biologi / IPA )', '4 ( 09:00:00 - 09:45:00 )', 'Ganjil 2017 / 2018', 'X-MIPA2', 'IPA', '18'),
(73, 'Rabu', '1234567890 - SURAWAN, S.Pd. ( Kimia / IPA )', '5 ( 10:05:00 - 10:50:00 )', 'Ganjil 2017 / 2018', 'X-MIPA2', 'IPA', '3'),
(74, 'Rabu', '1234567890 - SURAWAN, S.Pd. ( Kimia / IPA )', '6 ( 10:50:00 - 11:30:00 )', 'Ganjil 2017 / 2018', 'X-MIPA2', 'IPA', '3'),
(75, 'Rabu', '1234567890 - SURAWAN, S.Pd. ( Bahasa Inggris / IPA )', '7 ( 12:30:00 - 13:15:00 )', 'Ganjil 2017 / 2018', 'X-MIPA2', 'IPA', '3'),
(76, 'Rabu', '1234567890 - SURAWAN, S.Pd. ( Bahasa Inggris / IPA )', '8 ( 13:15:00 - 14:00:00 )', 'Ganjil 2017 / 2018', 'X-MIPA2', 'IPA', '3'),
(77, 'Rabu', '1234567890 - MARIFA RIAMA, S.Pd. ( Sejarah / IPA )', '9 ( 14:00:00 - 14:45:00 )', 'Ganjil 2017 / 2018', 'X-MIPA2', 'IPA', '11'),
(78, 'Rabu', '1234567890 - MARIFA RIAMA, S.Pd. ( Sejarah / IPA )', '10 ( 14:45:00 - 15:30:00 )', 'Ganjil 2017 / 2018', 'X-MIPA2', 'IPA', '11'),
(79, 'Kamis', '1234567890 - MURSALIN, ST, S.Pd ( Matematika / IPA )', '1 ( 06:45:00 - 07:30:00 )', 'Ganjil 2017 / 2018', 'X-MIPA2', 'IPA', '10'),
(80, 'Kamis', '1234567890 - MURSALIN, ST, S.Pd ( Matematika / IPA )', '2 ( 07:30:00 - 08:15:00 )', 'Ganjil 2017 / 2018', 'X-MIPA2', 'IPA', '10'),
(81, 'Kamis', '1234567890 - SURAWAN, S.Pd. ( Bahasa Inggris / IPA )', '3 ( 08:15:00 - 09:00:00 )', 'Ganjil 2017 / 2018', 'X-MIPA2', 'IPA', '3'),
(82, 'Kamis', '1234567890 - SURAWAN, S.Pd. ( Bahasa Inggris / IPA )', '4 ( 09:00:00 - 09:45:00 )', 'Ganjil 2017 / 2018', 'X-MIPA2', 'IPA', '3'),
(83, 'Kamis', '1234567890 - MUHAMMAD SUWAR, S.Pd.I. ( Bahasa Arab / IPA )', '5 ( 10:05:00 - 10:50:00 )', 'Ganjil 2017 / 2018', 'X-MIPA2', 'IPA', '9'),
(84, 'Kamis', '1234567890 - MUHAMMAD SUWAR, S.Pd.I. ( Bahasa Arab / IPA )', '6 ( 10:50:00 - 11:30:00 )', 'Ganjil 2017 / 2018', 'X-MIPA2', 'IPA', '9'),
(85, 'Kamis', '1234567890 - SAYUDI, S. Pd. ( Bahasa Indonesia / IPA )', '7 ( 12:30:00 - 13:15:00 )', 'Ganjil 2017 / 2018', 'X-MIPA2', 'IPA', '2'),
(86, 'Kamis', '1234567890 - SAYUDI, S. Pd. ( Bahasa Indonesia / IPA )', '8 ( 13:15:00 - 14:00:00 )', 'Ganjil 2017 / 2018', 'X-MIPA2', 'IPA', '2'),
(87, 'Kamis', '1234567890 - Drs. ABAS SIMAN ( Pendidikan Kewarganegaraan / IPA )', '9 ( 14:00:00 - 14:45:00 )', 'Ganjil 2017 / 2018', 'X-MIPA2', 'IPA', '8'),
(88, 'Kamis', '1234567890 - Drs. ABAS SIMAN ( Pendidikan Kewarganegaraan / IPA )', '10 ( 14:45:00 - 15:30:00 )', 'Ganjil 2017 / 2018', 'X-MIPA2', 'IPA', '8'),
(89, 'Jumat', '1234567890 - MARDWI ASDIYANTO, M.Pd.I. ( S K I / IPA )', '1 ( 06:45:00 - 07:30:00 )', 'Ganjil 2017 / 2018', 'X-MIPA2', 'IPA', '7'),
(90, 'Jumat', '1234567890 - MARDWI ASDIYANTO, M.Pd.I. ( S K I / IPA )', '2 ( 07:30:00 - 08:15:00 )', 'Ganjil 2017 / 2018', 'X-MIPA2', 'IPA', '7'),
(91, 'Jumat', '1234567890 - AHERI SUGIHARTONO, S.Th.I ( Aqidah Akhlak / IPA )', '3 ( 08:15:00 - 09:00:00 )', 'Ganjil 2017 / 2018', 'X-MIPA2', 'IPA', '6'),
(92, 'Jumat', '1234567890 - AHERI SUGIHARTONO, S.Th.I ( Aqidah Akhlak / IPA )', '4 ( 09:00:00 - 09:45:00 )', 'Ganjil 2017 / 2018', 'X-MIPA2', 'IPA', '6'),
(93, 'Jumat', '1234567890 - INSA ASYAROH, S.Ag ( Al Quran Hadis / IPA )', '5 ( 10:05:00 - 10:50:00 )', 'Ganjil 2017 / 2018', 'X-MIPA2', 'IPA', '5'),
(94, 'Jumat', '1234567890 - INSA ASYAROH, S.Ag ( Al Quran Hadis / IPA )', '6 ( 10:50:00 - 11:30:00 )', 'Ganjil 2017 / 2018', 'X-MIPA2', 'IPA', '5'),
(95, 'Jumat', '1234567890 - Drs. ABD. SALAM HS. ( Fiqih / IPA )', '7 ( 12:30:00 - 13:15:00 )', 'Ganjil 2017 / 2018', 'X-MIPA2', 'IPA', '4'),
(96, 'Jumat', '1234567890 - Drs. ABD. SALAM HS. ( Fiqih / IPA )', '8 ( 13:15:00 - 14:00:00 )', 'Ganjil 2017 / 2018', 'X-MIPA2', 'IPA', '4'),
(97, 'Senin', '1234567890 - Drs. ABD. SALAM HS. ( Fiqih / IPA )', '1 ( 06:45:00 - 07:30:00 )', 'Ganjil 2017 / 2018', 'X-MIPA3', 'IPA', '4'),
(98, 'Senin', '1234567890 - Drs. ABD. SALAM HS. ( Fiqih / IPA )', '2 ( 07:30:00 - 08:15:00 )', 'Ganjil 2017 / 2018', 'X-MIPA3', 'IPA', '4'),
(99, 'Senin', '1234567890 - INSA ASYAROH, S.Ag ( Al Quran Hadis / IPA )', '3 ( 08:15:00 - 09:00:00 )', 'Ganjil 2017 / 2018', 'X-MIPA3', 'IPA', '5'),
(100, 'Senin', '1234567890 - INSA ASYAROH, S.Ag ( Al Quran Hadis / IPA )', '4 ( 09:00:00 - 09:45:00 )', 'Ganjil 2017 / 2018', 'X-MIPA3', 'IPA', '5'),
(101, 'Senin', '1234567890 - ARYS SUSANTO, M.Pd ( Fisika / IPA )', '5 ( 10:05:00 - 10:50:00 )', 'Ganjil 2017 / 2018', 'X-MIPA3', 'IPA', '12'),
(102, 'Senin', '1234567890 - ARYS SUSANTO, M.Pd ( Fisika / IPA )', '6 ( 10:50:00 - 11:30:00 )', 'Ganjil 2017 / 2018', 'X-MIPA3', 'IPA', '12'),
(103, 'Senin', '1234567890 - SURAWAN, S.Pd. ( Kimia / IPA )', '7 ( 12:30:00 - 13:15:00 )', 'Ganjil 2017 / 2018', 'X-MIPA3', 'IPA', '3'),
(104, 'Senin', '1234567890 - SURAWAN, S.Pd. ( Kimia / IPA )', '8 ( 13:15:00 - 14:00:00 )', 'Ganjil 2017 / 2018', 'X-MIPA3', 'IPA', '3'),
(105, 'Senin', '1234567890 - MOHAMAD AFIF FARICHIN, M.Pd.I. ( Muhadatsah / IPA )', '9 ( 14:00:00 - 14:45:00 )', 'Ganjil 2017 / 2018', 'X-MIPA3', 'IPA', '13'),
(106, 'Senin', '1234567890 - MOHAMAD AFIF FARICHIN, M.Pd.I. ( Muhadatsah / IPA )', '10 ( 14:45:00 - 15:30:00 )', 'Ganjil 2017 / 2018', 'X-MIPA3', 'IPA', '13'),
(107, 'Selasa', '1234567890 - MOCH. FARID WADJIDI Lc, S.Pd. ( Biologi / IPA )', '1 ( 06:45:00 - 07:30:00 )', 'Ganjil 2017 / 2018', 'X-MIPA3', 'IPA', '14'),
(108, 'Selasa', '1234567890 - MOCH. FARID WADJIDI Lc, S.Pd. ( Biologi / IPA )', '2 ( 07:30:00 - 08:15:00 )', 'Ganjil 2017 / 2018', 'X-MIPA3', 'IPA', '14'),
(109, 'Selasa', '1234567890 - NENI SUHARTINI, S.Pd, M.Psi ( BK / IPA )', '3 ( 08:15:00 - 09:00:00 )', 'Ganjil 2017 / 2018', 'X-MIPA3', 'IPA', '20'),
(110, 'Selasa', '1234567890 - NENI SUHARTINI, S.Pd, M.Psi ( BK / IPA )', '4 ( 09:00:00 - 09:45:00 )', 'Ganjil 2017 / 2018', 'X-MIPA3', 'IPA', '20'),
(111, 'Selasa', '1234567890 - NUR JANAH, S.Pd ( Keterampilan / IPA )', '5 ( 10:05:00 - 10:50:00 )', 'Ganjil 2017 / 2018', 'X-MIPA3', 'IPA', '19'),
(112, 'Selasa', '1234567890 - NUR JANAH, S.Pd ( Keterampilan / IPA )', '6 ( 10:50:00 - 11:30:00 )', 'Ganjil 2017 / 2018', 'X-MIPA3', 'IPA', '19'),
(113, 'Selasa', '1234567890 - Drs. ALI MUSTOFA, M.Pd ( Geografi / IPA )', '7 ( 12:30:00 - 13:15:00 )', 'Ganjil 2017 / 2018', 'X-MIPA3', 'IPA', '15'),
(114, 'Selasa', '1234567890 - Drs. ALI MUSTOFA, M.Pd ( Geografi / IPA )', '8 ( 13:15:00 - 14:00:00 )', 'Ganjil 2017 / 2018', 'X-MIPA3', 'IPA', '15'),
(115, 'Selasa', '1234567890 - YAYUK ISWATIN, S.Pd ( Seni Budaya / IPA )', '9 ( 14:00:00 - 14:45:00 )', 'Ganjil 2017 / 2018', 'X-MIPA3', 'IPA', '17'),
(116, 'Selasa', '1234567890 - YAYUK ISWATIN, S.Pd ( Seni Budaya / IPA )', '10 ( 14:45:00 - 15:30:00 )', 'Ganjil 2017 / 2018', 'X-MIPA3', 'IPA', '17'),
(117, 'Rabu', '1234567890 - TRI SUDIK WIYONO, S.Pd ( Ekonomi / IPA )', '1 ( 06:45:00 - 07:30:00 )', 'Ganjil 2017 / 2018', 'X-MIPA3', 'IPA', '16'),
(118, 'Rabu', '1234567890 - TRI SUDIK WIYONO, S.Pd ( Ekonomi / IPA )', '2 ( 07:30:00 - 08:15:00 )', 'Ganjil 2017 / 2018', 'X-MIPA3', 'IPA', '16'),
(119, 'Rabu', '1234567890 - SURAWAN, S.Pd. ( Kimia / IPA )', '3 ( 08:15:00 - 09:00:00 )', 'Ganjil 2017 / 2018', 'X-MIPA3', 'IPA', '3'),
(120, 'Rabu', '1234567890 - SURAWAN, S.Pd. ( Kimia / IPA )', '4 ( 09:00:00 - 09:45:00 )', 'Ganjil 2017 / 2018', 'X-MIPA3', 'IPA', '3'),
(121, 'Rabu', '1234567890 - MOCH. FARID WADJIDI Lc, S.Pd. ( Biologi / IPA )', '5 ( 10:05:00 - 10:50:00 )', 'Ganjil 2017 / 2018', 'X-MIPA3', 'IPA', '14'),
(122, 'Rabu', '1234567890 - MOCH. FARID WADJIDI Lc, S.Pd. ( Biologi / IPA )', '6 ( 10:50:00 - 11:30:00 )', 'Ganjil 2017 / 2018', 'X-MIPA3', 'IPA', '14'),
(123, 'Rabu', '1234567890 - Drs. ABD. SALAM HS. ( Fiqih / IPA )', '7 ( 12:30:00 - 13:15:00 )', 'Ganjil 2017 / 2018', 'X-MIPA3', 'IPA', '4'),
(124, 'Rabu', '1234567890 - Drs. ABD. SALAM HS. ( Fiqih / IPA )', '8 ( 13:15:00 - 14:00:00 )', 'Ganjil 2017 / 2018', 'X-MIPA3', 'IPA', '4'),
(125, 'Rabu', '1234567890 - AHERI SUGIHARTONO, S.Th.I ( Aqidah Akhlak / IPA )', '9 ( 14:00:00 - 14:45:00 )', 'Ganjil 2017 / 2018', 'X-MIPA3', 'IPA', '6'),
(126, 'Rabu', '1234567890 - AHERI SUGIHARTONO, S.Th.I ( Aqidah Akhlak / IPA )', '10 ( 14:45:00 - 15:30:00 )', 'Ganjil 2017 / 2018', 'X-MIPA3', 'IPA', '6'),
(127, 'Kamis', '1234567890 - Drs. YUDI SYAIFULLOH ( Pendidikan Jasmani, ORKES / IPA )', '1 ( 06:45:00 - 07:30:00 )', 'Ganjil 2017 / 2018', 'X-MIPA3', 'IPA', '1'),
(128, 'Kamis', '1234567890 - Drs. YUDI SYAIFULLOH ( Pendidikan Jasmani, ORKES / IPA )', '2 ( 07:30:00 - 08:15:00 )', 'Ganjil 2017 / 2018', 'X-MIPA3', 'IPA', '1'),
(129, 'Kamis', '1234567890 - MARDWI ASDIYANTO, M.Pd.I. ( S K I / IPA )', '3 ( 08:15:00 - 09:00:00 )', 'Ganjil 2017 / 2018', 'X-MIPA3', 'IPA', '7'),
(130, 'Kamis', '1234567890 - MARDWI ASDIYANTO, M.Pd.I. ( S K I / IPA )', '4 ( 09:00:00 - 09:45:00 )', 'Ganjil 2017 / 2018', 'X-MIPA3', 'IPA', '7'),
(131, 'Kamis', '1234567890 - SAYUDI, S. Pd. ( Bahasa Indonesia / IPA )', '5 ( 10:05:00 - 10:50:00 )', 'Ganjil 2017 / 2018', 'X-MIPA3', 'IPA', '2'),
(132, 'Kamis', '1234567890 - SAYUDI, S. Pd. ( Bahasa Indonesia / IPA )', '6 ( 10:50:00 - 11:30:00 )', 'Ganjil 2017 / 2018', 'X-MIPA3', 'IPA', '2'),
(133, 'Kamis', '1234567890 - Drs. ABAS SIMAN ( Pendidikan Kewarganegaraan / IPA )', '7 ( 12:30:00 - 13:15:00 )', 'Ganjil 2017 / 2018', 'X-MIPA3', 'IPA', '8'),
(134, 'Kamis', '1234567890 - Drs. ABAS SIMAN ( Pendidikan Kewarganegaraan / IPA )', '8 ( 13:15:00 - 14:00:00 )', 'Ganjil 2017 / 2018', 'X-MIPA3', 'IPA', '8'),
(135, 'Kamis', '1234567890 - MUHAMMAD SUWAR, S.Pd.I. ( Bahasa Arab / IPA )', '9 ( 14:00:00 - 14:45:00 )', 'Ganjil 2017 / 2018', 'X-MIPA3', 'IPA', '9'),
(136, 'Kamis', '1234567890 - MUHAMMAD SUWAR, S.Pd.I. ( Bahasa Arab / IPA )', '10 ( 14:45:00 - 15:30:00 )', 'Ganjil 2017 / 2018', 'X-MIPA3', 'IPA', '9'),
(137, 'Jumat', '1234567890 - MARDWI ASDIYANTO, M.Pd.I. ( S K I / IPA )', '1 ( 06:45:00 - 07:30:00 )', 'Ganjil 2017 / 2018', 'X-MIPA3', 'IPA', '7'),
(138, 'Jumat', '1234567890 - MARDWI ASDIYANTO, M.Pd.I. ( S K I / IPA )', '2 ( 07:30:00 - 08:15:00 )', 'Ganjil 2017 / 2018', 'X-MIPA3', 'IPA', '7'),
(139, 'Jumat', '1234567890 - MURSALIN, ST, S.Pd ( Matematika / IPA )', '3 ( 08:15:00 - 09:00:00 )', 'Ganjil 2017 / 2018', 'X-MIPA3', 'IPA', '10'),
(140, 'Jumat', '1234567890 - MURSALIN, ST, S.Pd ( Matematika / IPA )', '4 ( 09:00:00 - 09:45:00 )', 'Ganjil 2017 / 2018', 'X-MIPA3', 'IPA', '10'),
(141, 'Jumat', '1234567890 - MARIFA RIAMA, S.Pd. ( Sejarah / IPA )', '5 ( 10:05:00 - 10:50:00 )', 'Ganjil 2017 / 2018', 'X-MIPA3', 'IPA', '11'),
(142, 'Jumat', '1234567890 - MARIFA RIAMA, S.Pd. ( Sejarah / IPA )', '6 ( 10:50:00 - 11:30:00 )', 'Ganjil 2017 / 2018', 'X-MIPA3', 'IPA', '11'),
(143, 'Jumat', '1234567890 - ARYS SUSANTO, M.Pd ( Fisika / IPA )', '7 ( 12:30:00 - 13:15:00 )', 'Ganjil 2017 / 2018', 'X-MIPA3', 'IPA', '12'),
(144, 'Jumat', '1234567890 - ARYS SUSANTO, M.Pd ( Fisika / IPA )', '8 ( 13:15:00 - 14:00:00 )', 'Ganjil 2017 / 2018', 'X-MIPA3', 'IPA', '12'),
(145, 'Senin', '1234567890 - Dra. SUWINARTI ( Geografi / IPS )', '1 ( 06:45:00 - 07:30:00 )', 'Ganjil 2017 / 2018', 'X-IPS1', 'IPS', '21'),
(146, 'Senin', '1234567890 - Dra. SUWINARTI ( Geografi / IPS )', '2 ( 07:30:00 - 08:15:00 )', 'Ganjil 2017 / 2018', 'X-IPS1', 'IPS', '21'),
(147, 'Senin', '1234567890 - Drs. YUDI SYAIFULLOH ( Pendidikan Jasmani, ORKES / IPS )', '3 ( 08:15:00 - 09:00:00 )', 'Ganjil 2017 / 2018', 'X-IPS1', 'IPS', '1'),
(148, 'Senin', '1234567890 - Drs. YUDI SYAIFULLOH ( Pendidikan Jasmani, ORKES / IPS )', '4 ( 09:00:00 - 09:45:00 )', 'Ganjil 2017 / 2018', 'X-IPS1', 'IPS', '1'),
(149, 'Senin', '1234567890 - MARIFA RIAMA, S.Pd. ( Sejarah / IPS )', '5 ( 10:05:00 - 10:50:00 )', 'Ganjil 2017 / 2018', 'X-IPS1', 'IPS', '11'),
(150, 'Senin', '1234567890 - MARIFA RIAMA, S.Pd. ( Sejarah / IPS )', '6 ( 10:50:00 - 11:30:00 )', 'Ganjil 2017 / 2018', 'X-IPS1', 'IPS', '11'),
(151, 'Senin', '1234567890 - MOHAMAD AFIF FARICHIN, M.Pd.I. ( Muhadatsah / IPS )', '7 ( 12:30:00 - 13:15:00 )', 'Ganjil 2017 / 2018', 'X-IPS1', 'IPS', '13'),
(152, 'Senin', '1234567890 - MOHAMAD AFIF FARICHIN, M.Pd.I. ( Muhadatsah / IPS )', '8 ( 13:15:00 - 14:00:00 )', 'Ganjil 2017 / 2018', 'X-IPS1', 'IPS', '13'),
(153, 'Senin', '1234567890 - SURAWAN, S.Pd. ( Bahasa Inggris / IPS )', '9 ( 14:00:00 - 14:45:00 )', 'Ganjil 2017 / 2018', 'X-IPS1', 'IPS', '3'),
(154, 'Senin', '1234567890 - SURAWAN, S.Pd. ( Bahasa Inggris / IPS )', '10 ( 14:45:00 - 15:30:00 )', 'Ganjil 2017 / 2018', 'X-IPS1', 'IPS', '3'),
(155, 'Selasa', '1234567890 - ISMI MARIYAM, S.Pd. ( Bhs & Sastra Ind / IPS )', '1 ( 06:45:00 - 07:30:00 )', 'Ganjil 2017 / 2018', 'X-IPS1', 'IPS', '22'),
(156, 'Selasa', '1234567890 - ISMI MARIYAM, S.Pd. ( Bhs & Sastra Ind / IPS )', '2 ( 07:30:00 - 08:15:00 )', 'Ganjil 2017 / 2018', 'X-IPS1', 'IPS', '22'),
(157, 'Selasa', '1234567890 - HADIAH, S.Pd. ( Ekonomi / IPS )', '3 ( 08:15:00 - 09:00:00 )', 'Ganjil 2017 / 2018', 'X-IPS1', 'IPA', '23'),
(158, 'Selasa', '1234567890 - HADIAH, S.Pd. ( Ekonomi / IPS )', '4 ( 09:00:00 - 09:45:00 )', 'Ganjil 2017 / 2018', 'X-IPS1', 'IPA', '23'),
(159, 'Selasa', '1234567890 - USMAN, S.Pd. ( Bahasa Indonesia / IPS )', '5 ( 10:05:00 - 10:50:00 )', 'Ganjil 2017 / 2018', 'X-IPS1', 'IPS', '24'),
(160, 'Selasa', '1234567890 - USMAN, S.Pd. ( Bahasa Indonesia / IPS )', '6 ( 10:50:00 - 11:30:00 )', 'Ganjil 2017 / 2018', 'X-IPS1', 'IPS', '24'),
(161, 'Selasa', '1234567890 - TEGUH KOESTANTININGSIH, S.Pd ( Keterampilan / IPS )', '7 ( 12:30:00 - 13:15:00 )', 'Ganjil 2017 / 2018', 'X-IPS1', 'IPS', '25'),
(162, 'Selasa', '1234567890 - TEGUH KOESTANTININGSIH, S.Pd ( Keterampilan / IPS )', '8 ( 13:15:00 - 14:00:00 )', 'Ganjil 2017 / 2018', 'X-IPS1', 'IPS', '25'),
(163, 'Selasa', '1234567890 - YAYUK ISWATIN, S.Pd ( Seni Budaya / IPS )', '9 ( 14:00:00 - 14:45:00 )', 'Ganjil 2017 / 2018', 'X-IPS1', 'IPS', '17'),
(164, 'Selasa', '1234567890 - YAYUK ISWATIN, S.Pd ( Seni Budaya / IPS )', '10 ( 14:45:00 - 15:30:00 )', 'Ganjil 2017 / 2018', 'X-IPS1', 'IPS', '17'),
(165, 'Rabu', '1234567890 - NASHRUL ULUM, S.Pd. ( Sosiologi / IPS )', '1 ( 06:45:00 - 07:30:00 )', 'Ganjil 2017 / 2018', 'X-IPS1', 'IPS', '26'),
(166, 'Rabu', '1234567890 - NASHRUL ULUM, S.Pd. ( Sosiologi / IPS )', '2 ( 07:30:00 - 08:15:00 )', 'Ganjil 2017 / 2018', 'X-IPS1', 'IPS', '26'),
(167, 'Rabu', '1234567890 - NENI SUHARTINI, S.Pd, M.Psi ( BK / IPS )', '3 ( 08:15:00 - 09:00:00 )', 'Ganjil 2017 / 2018', 'X-IPS1', 'IPS', '20'),
(168, 'Rabu', '1234567890 - NENI SUHARTINI, S.Pd, M.Psi ( BK / IPS )', '4 ( 09:00:00 - 09:45:00 )', 'Ganjil 2017 / 2018', 'X-IPS1', 'IPS', '20'),
(169, 'Rabu', '1234567890 - Dra. SUWINARTI ( Geografi / IPS )', '5 ( 10:05:00 - 10:50:00 )', 'Ganjil 2017 / 2018', 'X-IPS1', 'IPS', '21'),
(170, 'Rabu', '1234567890 - Dra. SUWINARTI ( Geografi / IPS )', '6 ( 10:50:00 - 11:30:00 )', 'Ganjil 2017 / 2018', 'X-IPS1', 'IPS', '21'),
(171, 'Rabu', '1234567890 - MARIFA RIAMA, S.Pd. ( Sejarah / IPS )', '7 ( 12:30:00 - 13:15:00 )', 'Ganjil 2017 / 2018', 'X-IPS1', 'IPS', '11'),
(172, 'Rabu', '1234567890 - MARIFA RIAMA, S.Pd. ( Sejarah / IPS )', '8 ( 13:15:00 - 14:00:00 )', 'Ganjil 2017 / 2018', 'X-IPS1', 'IPS', '11'),
(173, 'Rabu', '1234567890 - Dra. AGUS SETYANINGSIH, M.Si ( Matematika / IPS )', '9 ( 14:00:00 - 14:45:00 )', 'Ganjil 2017 / 2018', 'X-IPS1', 'IPS', '27'),
(174, 'Rabu', '1234567890 - Dra. AGUS SETYANINGSIH, M.Si ( Matematika / IPS )', '10 ( 14:45:00 - 15:30:00 )', 'Ganjil 2017 / 2018', 'X-IPS1', 'IPS', '27'),
(175, 'Kamis', '1234567890 - SURAWAN, S.Pd. ( Bahasa Inggris / IPS )', '1 ( 06:45:00 - 07:30:00 )', 'Ganjil 2017 / 2018', 'X-IPS1', 'IPS', '3'),
(176, 'Kamis', '1234567890 - SURAWAN, S.Pd. ( Bahasa Inggris / IPS )', '2 ( 07:30:00 - 08:15:00 )', 'Ganjil 2017 / 2018', 'X-IPS1', 'IPS', '3'),
(177, 'Kamis', '1234567890 - MUHAMMAD SUWAR, S.Pd.I. ( Bahasa Arab / IPS )', '3 ( 08:15:00 - 09:00:00 )', 'Ganjil 2017 / 2018', 'X-IPS1', 'IPS', '9'),
(178, 'Kamis', '1234567890 - MUHAMMAD SUWAR, S.Pd.I. ( Bahasa Arab / IPS )', '4 ( 09:00:00 - 09:45:00 )', 'Ganjil 2017 / 2018', 'X-IPS1', 'IPS', '9'),
(179, 'Kamis', '1234567890 - ISMI MARIYAM, S.Pd. ( Bhs & Sastra Ind / IPS )', '5 ( 10:05:00 - 10:50:00 )', 'Ganjil 2017 / 2018', 'X-IPS1', 'IPS', '22'),
(180, 'Kamis', '1234567890 - ISMI MARIYAM, S.Pd. ( Bhs & Sastra Ind / IPS )', '6 ( 10:50:00 - 11:30:00 )', 'Ganjil 2017 / 2018', 'X-IPS1', 'IPS', '22'),
(181, 'Kamis', '1234567890 - WIWIN SISWINARNI, S.Pd. ( Pendidikan Kewarganegaraan / IPS )', '7 ( 12:30:00 - 13:15:00 )', 'Ganjil 2017 / 2018', 'X-IPS1', 'IPS', '28'),
(182, 'Kamis', '1234567890 - WIWIN SISWINARNI, S.Pd. ( Pendidikan Kewarganegaraan / IPS )', '8 ( 13:15:00 - 14:00:00 )', 'Ganjil 2017 / 2018', 'X-IPS1', 'IPS', '28'),
(183, 'Kamis', '1234567890 - USMAN, S.Pd. ( Bahasa Indonesia / IPS )', '9 ( 14:00:00 - 14:45:00 )', 'Ganjil 2017 / 2018', 'X-IPS1', 'IPS', '24'),
(184, 'Kamis', '1234567890 - USMAN, S.Pd. ( Bahasa Indonesia / IPS )', '10 ( 14:45:00 - 15:30:00 )', 'Ganjil 2017 / 2018', 'X-IPS1', 'IPS', '24'),
(185, 'Jumat', '1234567890 - ARIF MUSTOFA, S.Ag., M.Pd. ( Fiqih / IPS )', '1 ( 06:45:00 - 07:30:00 )', 'Ganjil 2017 / 2018', 'X-IPS1', 'IPS', '29'),
(186, 'Jumat', '1234567890 - ARIF MUSTOFA, S.Ag., M.Pd. ( Fiqih / IPS )', '2 ( 07:30:00 - 08:15:00 )', 'Ganjil 2017 / 2018', 'X-IPS1', 'IPS', '29'),
(187, 'Jumat', '1234567890 - INSA ASYAROH, S.Ag ( Al Quran Hadis / IPS )', '3 ( 08:15:00 - 09:00:00 )', 'Ganjil 2017 / 2018', 'X-IPS1', 'IPS', '5'),
(188, 'Jumat', '1234567890 - INSA ASYAROH, S.Ag ( Al Quran Hadis / IPS )', '4 ( 09:00:00 - 09:45:00 )', 'Ganjil 2017 / 2018', 'X-IPS1', 'IPS', '5'),
(189, 'Jumat', '1234567890 - NASHRUL ULUM, S.Pd. ( S K I / IPS )', '5 ( 10:05:00 - 10:50:00 )', 'Ganjil 2017 / 2018', 'X-IPS1', 'IPS', '26'),
(190, 'Jumat', '1234567890 - NASHRUL ULUM, S.Pd. ( S K I / IPS )', '6 ( 10:50:00 - 11:30:00 )', 'Ganjil 2017 / 2018', 'X-IPS1', 'IPS', '26'),
(191, 'Jumat', '1234567890 - AHERI SUGIHARTONO, S.Th.I ( Aqidah Akhlak / IPS )', '7 ( 12:30:00 - 13:15:00 )', 'Ganjil 2017 / 2018', 'X-IPS1', 'IPS', '6'),
(192, 'Jumat', '1234567890 - AHERI SUGIHARTONO, S.Th.I ( Aqidah Akhlak / IPS )', '8 ( 13:15:00 - 14:00:00 )', 'Ganjil 2017 / 2018', 'X-IPS1', 'IPS', '6'),
(193, 'Senin', '1234567890 - HADIAH, S.Pd. ( Ekonomi / IPS )', '1 ( 06:45:00 - 07:30:00 )', 'Ganjil 2017 / 2018', 'X-IPS2', 'IPS', '23'),
(194, 'Senin', '1234567890 - HADIAH, S.Pd. ( Ekonomi / IPS )', '2 ( 07:30:00 - 08:15:00 )', 'Ganjil 2017 / 2018', 'X-IPS2', 'IPS', '23'),
(195, 'Senin', '1234567890 - Drs. YUDI SYAIFULLOH ( Pendidikan Jasmani, ORKES / IPS )', '3 ( 08:15:00 - 09:00:00 )', 'Ganjil 2017 / 2018', 'X-IPS2', 'IPS', '1'),
(196, 'Senin', '1234567890 - Drs. YUDI SYAIFULLOH ( Pendidikan Jasmani, ORKES / IPS )', '4 ( 09:00:00 - 09:45:00 )', 'Ganjil 2017 / 2018', 'X-IPS2', 'IPS', '1'),
(197, 'Senin', '1234567890 - Dra. AGUS SETYANINGSIH, M.Si ( Matematika / IPS )', '5 ( 10:05:00 - 10:50:00 )', 'Ganjil 2017 / 2018', 'X-IPS2', 'IPS', '27'),
(198, 'Senin', '1234567890 - Dra. AGUS SETYANINGSIH, M.Si ( Matematika / IPS )', '6 ( 10:50:00 - 11:30:00 )', 'Ganjil 2017 / 2018', 'X-IPS2', 'IPS', '27'),
(199, 'Senin', '1234567890 - MARIFA RIAMA, S.Pd. ( Sejarah / IPS )', '7 ( 12:30:00 - 13:15:00 )', 'Ganjil 2017 / 2018', 'X-IPS2', 'IPS', '11'),
(200, 'Senin', '1234567890 - MARIFA RIAMA, S.Pd. ( Sejarah / IPS )', '8 ( 13:15:00 - 14:00:00 )', 'Ganjil 2017 / 2018', 'X-IPS2', 'IPS', '11'),
(201, 'Senin', '1234567890 - NASHRUL ULUM, S.Pd. ( Sosiologi / IPS )', '9 ( 14:00:00 - 14:45:00 )', 'Ganjil 2017 / 2018', 'X-IPS2', 'IPS', '26'),
(202, 'Senin', '1234567890 - NASHRUL ULUM, S.Pd. ( Sosiologi / IPS )', '10 ( 14:45:00 - 15:30:00 )', 'Ganjil 2017 / 2018', 'X-IPS2', 'IPS', '26'),
(203, 'Selasa', '1234567890 - ARIF MUSTOFA, S.Ag., M.Pd. ( Fiqih / IPS )', '1 ( 06:45:00 - 07:30:00 )', 'Ganjil 2017 / 2018', 'X-IPS2', 'IPS', '29'),
(204, 'Selasa', '1234567890 - ARIF MUSTOFA, S.Ag., M.Pd. ( Fiqih / IPS )', '2 ( 07:30:00 - 08:15:00 )', 'Ganjil 2017 / 2018', 'X-IPS2', 'IPS', '29'),
(205, 'Selasa', '1234567890 - INSA ASYAROH, S.Ag ( Al Quran Hadis / IPS )', '3 ( 08:15:00 - 09:00:00 )', 'Ganjil 2017 / 2018', 'X-IPS2', 'IPS', '5'),
(206, 'Selasa', '1234567890 - INSA ASYAROH, S.Ag ( Al Quran Hadis / IPS )', '4 ( 09:00:00 - 09:45:00 )', 'Ganjil 2017 / 2018', 'X-IPS2', 'IPS', '5'),
(207, 'Selasa', '1234567890 - WIWIN SISWINARNI, S.Pd. ( Pendidikan Kewarganegaraan / IPS )', '5 ( 10:05:00 - 10:50:00 )', 'Ganjil 2017 / 2018', 'X-IPS2', 'IPS', '28'),
(208, 'Selasa', '1234567890 - WIWIN SISWINARNI, S.Pd. ( Pendidikan Kewarganegaraan / IPS )', '6 ( 10:50:00 - 11:30:00 )', 'Ganjil 2017 / 2018', 'X-IPS2', 'IPS', '28'),
(209, 'Selasa', '1234567890 - NASHRUL ULUM, S.Pd. ( S K I / IPS )', '7 ( 12:30:00 - 13:15:00 )', 'Ganjil 2017 / 2018', 'X-IPS2', 'IPS', '26'),
(210, 'Selasa', '1234567890 - NASHRUL ULUM, S.Pd. ( S K I / IPS )', '8 ( 13:15:00 - 14:00:00 )', 'Ganjil 2017 / 2018', 'X-IPS2', 'IPS', '26'),
(211, 'Selasa', '1234567890 - AHERI SUGIHARTONO, S.Th.I ( Aqidah Akhlak / IPS )', '9 ( 14:00:00 - 14:45:00 )', 'Ganjil 2017 / 2018', 'X-IPS2', 'IPS', '6'),
(212, 'Selasa', '1234567890 - AHERI SUGIHARTONO, S.Th.I ( Aqidah Akhlak / IPS )', '10 ( 14:45:00 - 15:30:00 )', 'Ganjil 2017 / 2018', 'X-IPS2', 'IPS', '6'),
(213, 'Rabu', '1234567890 - USMAN, S.Pd. ( Bahasa Indonesia / IPS )', '1 ( 06:45:00 - 07:30:00 )', 'Ganjil 2017 / 2018', 'X-IPS2', 'IPS', '24'),
(214, 'Rabu', '1234567890 - USMAN, S.Pd. ( Bahasa Indonesia / IPS )', '2 ( 07:30:00 - 08:15:00 )', 'Ganjil 2017 / 2018', 'X-IPS2', 'IPS', '24'),
(215, 'Rabu', '1234567890 - Dra. AGUS SETYANINGSIH, M.Si ( Matematika / IPS )', '3 ( 08:15:00 - 09:00:00 )', 'Ganjil 2017 / 2018', 'X-IPS2', 'IPS', '27'),
(216, 'Rabu', '1234567890 - Dra. AGUS SETYANINGSIH, M.Si ( Matematika / IPS )', '4 ( 09:00:00 - 09:45:00 )', 'Ganjil 2017 / 2018', 'X-IPS2', 'IPS', '27'),
(217, 'Rabu', '1234567890 - MUHAMMAD SUWAR, S.Pd.I. ( Bahasa Arab / IPS )', '5 ( 10:05:00 - 10:50:00 )', 'Ganjil 2017 / 2018', 'X-IPS2', 'IPS', '9'),
(218, 'Rabu', '1234567890 - MUHAMMAD SUWAR, S.Pd.I. ( Bahasa Arab / IPS )', '6 ( 10:50:00 - 11:30:00 )', 'Ganjil 2017 / 2018', 'X-IPS2', 'IPS', '9'),
(219, 'Rabu', '1234567890 - ISMI MARIYAM, S.Pd. ( Bhs & Sastra Ind / IPS )', '7 ( 12:30:00 - 13:15:00 )', 'Ganjil 2017 / 2018', 'X-IPS2', 'IPS', '22'),
(220, 'Rabu', '1234567890 - ISMI MARIYAM, S.Pd. ( Bhs & Sastra Ind / IPS )', '8 ( 13:15:00 - 14:00:00 )', 'Ganjil 2017 / 2018', 'X-IPS2', 'IPS', '22'),
(221, 'Rabu', '1234567890 - HADIAH, S.Pd. ( Ekonomi / IPS )', '9 ( 14:00:00 - 14:45:00 )', 'Ganjil 2017 / 2018', 'X-IPS2', 'IPS', '23'),
(222, 'Rabu', '1234567890 - HADIAH, S.Pd. ( Ekonomi / IPS )', '10 ( 14:45:00 - 15:30:00 )', 'Ganjil 2017 / 2018', 'X-IPS2', 'IPS', '23'),
(223, 'Kamis', '1234567890 - MARIFA RIAMA, S.Pd. ( Sejarah / IPS )', '1 ( 06:45:00 - 07:30:00 )', 'Ganjil 2017 / 2018', 'X-IPS2', 'IPS', '11'),
(224, 'Kamis', '1234567890 - MARIFA RIAMA, S.Pd. ( Sejarah / IPS )', '2 ( 07:30:00 - 08:15:00 )', 'Ganjil 2017 / 2018', 'X-IPS2', 'IPS', '11'),
(225, 'Kamis', '1234567890 - Dra. SUWINARTI ( Geografi / IPS )', '3 ( 08:15:00 - 09:00:00 )', 'Ganjil 2017 / 2018', 'X-IPS2', 'IPS', '21'),
(226, 'Kamis', '1234567890 - Dra. SUWINARTI ( Geografi / IPS )', '4 ( 09:00:00 - 09:45:00 )', 'Ganjil 2017 / 2018', 'X-IPS2', 'IPS', '21'),
(227, 'Kamis', '1234567890 - SURAWAN, S.Pd. ( Bahasa Inggris / IPS )', '5 ( 10:05:00 - 10:50:00 )', 'Ganjil 2017 / 2018', 'X-IPS2', 'IPS', '3'),
(228, 'Kamis', '1234567890 - SURAWAN, S.Pd. ( Bahasa Inggris / IPS )', '6 ( 10:50:00 - 11:30:00 )', 'Ganjil 2017 / 2018', 'X-IPS2', 'IPS', '3'),
(229, 'Kamis', '1234567890 - YAYUK ISWATIN, S.Pd ( Seni Budaya / IPS )', '7 ( 12:30:00 - 13:15:00 )', 'Ganjil 2017 / 2018', 'X-IPS2', 'IPS', '17'),
(230, 'Kamis', '1234567890 - YAYUK ISWATIN, S.Pd ( Seni Budaya / IPS )', '8 ( 13:15:00 - 14:00:00 )', 'Ganjil 2017 / 2018', 'X-IPS2', 'IPS', '17'),
(231, 'Kamis', '1234567890 - NASHRUL ULUM, S.Pd. ( Sosiologi / IPS )', '9 ( 14:00:00 - 14:45:00 )', 'Ganjil 2017 / 2018', 'X-IPS2', 'IPS', '26'),
(232, 'Kamis', '1234567890 - NASHRUL ULUM, S.Pd. ( Sosiologi / IPS )', '10 ( 14:45:00 - 15:30:00 )', 'Ganjil 2017 / 2018', 'X-IPS2', 'IPS', '26'),
(233, 'Jumat', '1234567890 - HADIAH, S.Pd. ( Ekonomi / IPS )', '1 ( 06:45:00 - 07:30:00 )', 'Ganjil 2017 / 2018', 'X-IPS2', 'IPS', '23'),
(234, 'Jumat', '1234567890 - HADIAH, S.Pd. ( Ekonomi / IPS )', '2 ( 07:30:00 - 08:15:00 )', 'Ganjil 2017 / 2018', 'X-IPS2', 'IPS', '23'),
(235, 'Jumat', '1234567890 - TEGUH KOESTANTININGSIH, S.Pd ( Keterampilan / IPS )', '3 ( 08:15:00 - 09:00:00 )', 'Ganjil 2017 / 2018', 'X-IPS2', 'IPS', '25'),
(236, 'Jumat', '1234567890 - TEGUH KOESTANTININGSIH, S.Pd ( Keterampilan / IPS )', '4 ( 09:00:00 - 09:45:00 )', 'Ganjil 2017 / 2018', 'X-IPS2', 'IPS', '25'),
(237, 'Jumat', '1234567890 - NENI SUHARTINI, S.Pd, M.Psi ( BK / IPS )', '5 ( 10:05:00 - 10:50:00 )', 'Ganjil 2017 / 2018', 'X-IPS2', 'IPS', '20'),
(238, 'Jumat', '1234567890 - NENI SUHARTINI, S.Pd, M.Psi ( BK / IPS )', '6 ( 10:50:00 - 11:30:00 )', 'Ganjil 2017 / 2018', 'X-IPS2', 'IPS', '20'),
(239, 'Jumat', '1234567890 - MOHAMAD AFIF FARICHIN, M.Pd.I. ( Muhadatsah / IPS )', '7 ( 12:30:00 - 13:15:00 )', 'Ganjil 2017 / 2018', 'X-IPS2', 'IPS', '13'),
(240, 'Jumat', '1234567890 - MOHAMAD AFIF FARICHIN, M.Pd.I. ( Muhadatsah / IPS )', '8 ( 13:15:00 - 14:00:00 )', 'Ganjil 2017 / 2018', 'X-IPS2', 'IPS', '13'),
(241, 'Senin', '1234567890 - MARIFA RIAMA, S.Pd. ( Sejarah / AGAMA )', '1 ( 06:45:00 - 07:30:00 )', 'Ganjil 2017 / 2018', 'X-IAG', 'AGAMA', '11'),
(242, 'Senin', '1234567890 - MARIFA RIAMA, S.Pd. ( Sejarah / AGAMA )', '2 ( 07:30:00 - 08:15:00 )', 'Ganjil 2017 / 2018', 'X-IAG', 'AGAMA', '11'),
(243, 'Senin', '1234567890 - YAYUK ISWATIN, S.Pd ( Seni Budaya / AGAMA )', '3 ( 08:15:00 - 09:00:00 )', 'Ganjil 2017 / 2018', 'X-IAG', 'AGAMA', '17'),
(244, 'Senin', '1234567890 - YAYUK ISWATIN, S.Pd ( Seni Budaya / AGAMA )', '4 ( 09:00:00 - 09:45:00 )', 'Ganjil 2017 / 2018', 'X-IAG', 'AGAMA', '17'),
(245, 'Senin', '1234567890 - ARIF MUSTOFA, S.Ag., M.Pd. ( Ushul Fiqih / AGAMA )', '5 ( 10:05:00 - 10:50:00 )', 'Ganjil 2017 / 2018', 'X-IAG', 'AGAMA', '29'),
(246, 'Senin', '1234567890 - ARIF MUSTOFA, S.Ag., M.Pd. ( Ushul Fiqih / AGAMA )', '6 ( 10:50:00 - 11:30:00 )', 'Ganjil 2017 / 2018', 'X-IAG', 'AGAMA', '29'),
(247, 'Senin', '1234567890 - UMAR FARUQ, S.Ag. ( Ilmu Kalam / AGAMA )', '7 ( 12:30:00 - 13:15:00 )', 'Ganjil 2017 / 2018', 'X-IAG', 'AGAMA', '30'),
(248, 'Senin', '1234567890 - UMAR FARUQ, S.Ag. ( Ilmu Kalam / AGAMA )', '8 ( 13:15:00 - 14:00:00 )', 'Ganjil 2017 / 2018', 'X-IAG', 'AGAMA', '30'),
(249, 'Senin', '1234567890 - WIWIN SISWINARNI, S.Pd. ( Pendidikan Kewarganegaraan / AGAMA )', '9 ( 14:00:00 - 14:45:00 )', 'Ganjil 2017 / 2018', 'X-IAG', 'AGAMA', '28'),
(250, 'Senin', '1234567890 - WIWIN SISWINARNI, S.Pd. ( Pendidikan Kewarganegaraan / AGAMA )', '10 ( 14:45:00 - 15:30:00 )', 'Ganjil 2017 / 2018', 'X-IAG', 'AGAMA', '28'),
(251, 'Selasa', '1234567890 - SITI MARIA ULFAH, S.Pd.I ( Ilmu Hadits / AGAMA )', '1 ( 06:45:00 - 07:30:00 )', 'Ganjil 2017 / 2018', 'X-IAG', 'AGAMA', '31'),
(252, 'Selasa', '1234567890 - SITI MARIA ULFAH, S.Pd.I ( Ilmu Hadits / AGAMA )', '2 ( 07:30:00 - 08:15:00 )', 'Ganjil 2017 / 2018', 'X-IAG', 'AGAMA', '31'),
(253, 'Selasa', '1234567890 - TEGUH KOESTANTININGSIH, S.Pd ( Keterampilan / IPS )', '3 ( 08:15:00 - 09:00:00 )', 'Ganjil 2017 / 2018', 'X-IAG', 'AGAMA', '25'),
(254, 'Selasa', '1234567890 - TEGUH KOESTANTININGSIH, S.Pd ( Keterampilan / IPS )', '4 ( 09:00:00 - 09:45:00 )', 'Ganjil 2017 / 2018', 'X-IAG', 'AGAMA', '25'),
(255, 'Selasa', '1234567890 - MARIFA RIAMA, S.Pd. ( Sejarah / AGAMA )', '5 ( 10:05:00 - 10:50:00 )', 'Ganjil 2017 / 2018', 'X-IAG', 'AGAMA', '11'),
(256, 'Selasa', '1234567890 - MARIFA RIAMA, S.Pd. ( Sejarah / AGAMA )', '6 ( 10:50:00 - 11:30:00 )', 'Ganjil 2017 / 2018', 'X-IAG', 'AGAMA', '11'),
(257, 'Selasa', '1234567890 - MOHAMAD AFIF FARICHIN, M.Pd.I. ( Muhadatsah / AGAMA )', '7 ( 12:30:00 - 13:15:00 )', 'Ganjil 2017 / 2018', 'X-IAG', 'AGAMA', '13'),
(258, 'Selasa', '1234567890 - MOHAMAD AFIF FARICHIN, M.Pd.I. ( Muhadatsah / AGAMA )', '8 ( 13:15:00 - 14:00:00 )', 'Ganjil 2017 / 2018', 'X-IAG', 'AGAMA', '13'),
(259, 'Selasa', '1234567890 - INSA ASYAROH, S.Ag ( Ilmu Hadits / AGAMA )', '9 ( 14:00:00 - 14:45:00 )', 'Ganjil 2017 / 2018', 'X-IAG', 'AGAMA', '5'),
(260, 'Selasa', '1234567890 - INSA ASYAROH, S.Ag ( Ilmu Hadits / AGAMA )', '10 ( 14:45:00 - 15:30:00 )', 'Ganjil 2017 / 2018', 'X-IAG', 'AGAMA', '5'),
(261, 'Rabu', '1234567890 - UMAR FARUQ, S.Ag. ( Ilmu Kalam / AGAMA )', '1 ( 06:45:00 - 07:30:00 )', 'Ganjil 2017 / 2018', 'X-IAG', 'AGAMA', '30'),
(262, 'Rabu', '1234567890 - UMAR FARUQ, S.Ag. ( Ilmu Kalam / AGAMA )', '2 ( 07:30:00 - 08:15:00 )', 'Ganjil 2017 / 2018', 'X-IAG', 'AGAMA', '30'),
(263, 'Rabu', '1234567890 - NENI SUHARTINI, S.Pd, M.Psi ( BK / AGAMA )', '3 ( 08:15:00 - 09:00:00 )', 'Ganjil 2017 / 2018', 'X-IAG', 'AGAMA', '20'),
(264, 'Rabu', '1234567890 - NENI SUHARTINI, S.Pd, M.Psi ( BK / AGAMA )', '4 ( 09:00:00 - 09:45:00 )', 'Ganjil 2017 / 2018', 'X-IAG', 'AGAMA', '20'),
(265, 'Rabu', '1234567890 - Dra. AGUS SETYANINGSIH, M.Si ( Matematika / AGAMA )', '5 ( 10:05:00 - 10:50:00 )', 'Ganjil 2017 / 2018', 'X-IAG', 'AGAMA', '27'),
(266, 'Rabu', '1234567890 - Dra. AGUS SETYANINGSIH, M.Si ( Matematika / AGAMA )', '6 ( 10:50:00 - 11:30:00 )', 'Ganjil 2017 / 2018', 'X-IAG', 'AGAMA', '27'),
(267, 'Rabu', '1234567890 - ALIFIYAH RUSDIYANA, S.Pd. ( Bahasa Inggris / AGAMA )', '7 ( 12:30:00 - 13:15:00 )', 'Ganjil 2017 / 2018', 'X-IAG', 'AGAMA', '32'),
(268, 'Rabu', '1234567890 - ALIFIYAH RUSDIYANA, S.Pd. ( Bahasa Inggris / AGAMA )', '8 ( 13:15:00 - 14:00:00 )', 'Ganjil 2017 / 2018', 'X-IAG', 'AGAMA', '32'),
(269, 'Rabu', '1234567890 - MOHAMAD AFIF FARICHIN, M.Pd.I. ( Bahasa Arab / AGAMA )', '9 ( 14:00:00 - 14:45:00 )', 'Ganjil 2017 / 2018', 'X-IAG', 'AGAMA', '13'),
(270, 'Rabu', '1234567890 - MOHAMAD AFIF FARICHIN, M.Pd.I. ( Bahasa Arab / AGAMA )', '10 ( 14:45:00 - 15:30:00 )', 'Ganjil 2017 / 2018', 'X-IAG', 'AGAMA', '13'),
(271, 'Kamis', '1234567890 - ISMI MARIYAM, S.Pd. ( Bhs & Sastra Ind / AGAMA )', '1 ( 06:45:00 - 07:30:00 )', 'Ganjil 2017 / 2018', 'X-IAG', 'AGAMA', '22'),
(272, 'Kamis', '1234567890 - ISMI MARIYAM, S.Pd. ( Bhs & Sastra Ind / AGAMA )', '2 ( 07:30:00 - 08:15:00 )', 'Ganjil 2017 / 2018', 'X-IAG', 'AGAMA', '22'),
(273, 'Kamis', '1234567890 - MARDWI ASDIYANTO, M.Pd.I. ( Ilmu Tafsir / AGAMA )', '3 ( 08:15:00 - 09:00:00 )', 'Ganjil 2017 / 2018', 'X-IAG', 'AGAMA', '7'),
(274, 'Kamis', '1234567890 - MARDWI ASDIYANTO, M.Pd.I. ( Ilmu Tafsir / AGAMA )', '4 ( 09:00:00 - 09:45:00 )', 'Ganjil 2017 / 2018', 'X-IAG', 'AGAMA', '7'),
(275, 'Kamis', '1234567890 - USMAN, S.Pd. ( Bahasa Indonesia / AGAMA )', '5 ( 10:05:00 - 10:50:00 )', 'Ganjil 2017 / 2018', 'X-IAG', 'AGAMA', '24'),
(276, 'Kamis', '1234567890 - USMAN, S.Pd. ( Bahasa Indonesia / AGAMA )', '6 ( 10:50:00 - 11:30:00 )', 'Ganjil 2017 / 2018', 'X-IAG', 'AGAMA', '24'),
(277, 'Kamis', '1234567890 - UMAR FARUQ, S.Ag. ( Ilmu Kalam / AGAMA )', '7 ( 12:30:00 - 13:15:00 )', 'Ganjil 2017 / 2018', 'X-IAG', 'AGAMA', '30'),
(278, 'Kamis', '1234567890 - UMAR FARUQ, S.Ag. ( Ilmu Kalam / AGAMA )', '8 ( 13:15:00 - 14:00:00 )', 'Ganjil 2017 / 2018', 'X-IAG', 'AGAMA', '30'),
(279, 'Kamis', '1234567890 - AHERI SUGIHARTONO, S.Th.I ( Akhlak / AGAMA )', '9 ( 14:00:00 - 14:45:00 )', 'Ganjil 2017 / 2018', 'X-IAG', 'AGAMA', '6'),
(280, 'Kamis', '1234567890 - AHERI SUGIHARTONO, S.Th.I ( Akhlak / AGAMA )', '10 ( 14:45:00 - 15:30:00 )', 'Ganjil 2017 / 2018', 'X-IAG', 'AGAMA', '6'),
(281, 'Jumat', '1234567890 - AHERI SUGIHARTONO, S.Th.I ( Aqidah Akhlak / AGAMA )', '1 ( 06:45:00 - 07:30:00 )', 'Ganjil 2017 / 2018', 'X-IAG', 'AGAMA', '6'),
(282, 'Jumat', '1234567890 - AHERI SUGIHARTONO, S.Th.I ( Aqidah Akhlak / AGAMA )', '2 ( 07:30:00 - 08:15:00 )', 'Ganjil 2017 / 2018', 'X-IAG', 'AGAMA', '6'),
(283, 'Jumat', '1234567890 - INSA ASYAROH, S.Ag ( Al Quran Hadis / AGAMA )', '3 ( 08:15:00 - 09:00:00 )', 'Ganjil 2017 / 2018', 'X-IAG', 'AGAMA', '5'),
(284, 'Jumat', '1234567890 - INSA ASYAROH, S.Ag ( Al Quran Hadis / AGAMA )', '4 ( 09:00:00 - 09:45:00 )', 'Ganjil 2017 / 2018', 'X-IAG', 'AGAMA', '5'),
(285, 'Jumat', '1234567890 - YUDHA KURNIAWAN, S.Pd. ( Pendidikan Jasmani, ORKES / AGAMA )', '5 ( 10:05:00 - 10:50:00 )', 'Ganjil 2017 / 2018', 'X-IAG', 'AGAMA', '33'),
(286, 'Jumat', '1234567890 - YUDHA KURNIAWAN, S.Pd. ( Pendidikan Jasmani, ORKES / AGAMA )', '6 ( 10:50:00 - 11:30:00 )', 'Ganjil 2017 / 2018', 'X-IAG', 'AGAMA', '33'),
(287, 'Jumat', '1234567890 - ARIF MUSTOFA, S.Ag., M.Pd. ( Fiqih / AGAMA )', '7 ( 12:30:00 - 13:15:00 )', 'Ganjil 2017 / 2018', 'X-IAG', 'AGAMA', '34'),
(288, 'Jumat', '1234567890 - ARIF MUSTOFA, S.Ag., M.Pd. ( Fiqih / AGAMA )', '8 ( 13:15:00 - 14:00:00 )', 'Ganjil 2017 / 2018', 'X-IAG', 'AGAMA', '34'),
(289, 'Senin', '1234567890 - TRI SUDIK WIYONO, S.Pd ( Ekonomi / IPA )', '1 ( 06:45:00 - 07:30:00 )', 'Ganjil 2017 / 2018', 'XI-IPA 1', 'IPA', '16'),
(290, 'Senin', '1234567890 - TRI SUDIK WIYONO, S.Pd ( Ekonomi / IPA )', '2 ( 07:30:00 - 08:15:00 )', 'Ganjil 2017 / 2018', 'XI-IPA 1', 'IPA', '16'),
(291, 'Senin', '1234567890 - EDDI HARIYADI, S,Pd. ( Seni Budaya / IPA )', '3 ( 08:15:00 - 09:00:00 )', 'Ganjil 2017 / 2018', 'XI-IPA 1', 'IPA', '35'),
(292, 'Senin', '1234567890 - EDDI HARIYADI, S,Pd. ( Seni Budaya / IPA )', '4 ( 09:00:00 - 09:45:00 )', 'Ganjil 2017 / 2018', 'XI-IPA 1', 'IPA', '35'),
(293, 'Senin', '1234567890 - YUDHA KURNIAWAN, S.Pd. ( Pendidikan Jasmani, ORKES / IPA )', '5 ( 10:05:00 - 10:50:00 )', 'Ganjil 2017 / 2018', 'XI-IPA 1', 'IPA', '33'),
(294, 'Senin', '1234567890 - YUDHA KURNIAWAN, S.Pd. ( Pendidikan Jasmani, ORKES / IPA )', '6 ( 10:50:00 - 11:30:00 )', 'Ganjil 2017 / 2018', 'XI-IPA 1', 'IPA', '33'),
(295, 'Senin', '1234567890 - MOHAMAD AFIF FARICHIN, M.Pd.I. ( Muhadatsah / IPA )', '7 ( 12:30:00 - 13:15:00 )', 'Ganjil 2017 / 2018', 'XI-IPA 1', 'IPA', '13'),
(296, 'Senin', '1234567890 - MOHAMAD AFIF FARICHIN, M.Pd.I. ( Muhadatsah / IPA )', '8 ( 13:15:00 - 14:00:00 )', 'Ganjil 2017 / 2018', 'XI-IPA 1', 'IPA', '13'),
(297, 'Senin', '1234567890 - TEGUH KOESTANTININGSIH, S.Pd ( Keterampilan / IPA )', '9 ( 14:00:00 - 14:45:00 )', 'Ganjil 2017 / 2018', 'XI-IPA 1', 'IPA', '25'),
(298, 'Senin', '1234567890 - TEGUH KOESTANTININGSIH, S.Pd ( Keterampilan / IPA )', '10 ( 14:45:00 - 15:30:00 )', 'Ganjil 2017 / 2018', 'XI-IPA 1', 'IPA', '25'),
(299, 'Selasa', '1234567890 - Dra. ULUMIYAH ( BKTI / IPA )', '1 ( 06:45:00 - 07:30:00 )', 'Ganjil 2017 / 2018', 'XI-IPA 1', 'IPA', '35'),
(300, 'Selasa', '1234567890 - Dra. ULUMIYAH ( BKTI / IPA )', '2 ( 07:30:00 - 08:15:00 )', 'Ganjil 2017 / 2018', 'XI-IPA 1', 'IPA', '35'),
(301, 'Selasa', '1234567890 - ALY FUADI, S.Pd. ( Fisika / IPA )', '3 ( 08:15:00 - 09:00:00 )', 'Ganjil 2017 / 2018', 'XI-IPA 1', 'IPA', '36'),
(302, 'Selasa', '1234567890 - ALY FUADI, S.Pd. ( Fisika / IPA )', '4 ( 09:00:00 - 09:45:00 )', 'Ganjil 2017 / 2018', 'XI-IPA 1', 'IPA', '36'),
(303, 'Selasa', '1234567890 - Dra. MAZIDAH INAYATI ( Matematika / IPA )', '5 ( 10:05:00 - 10:50:00 )', 'Ganjil 2017 / 2018', 'XI-IPA 1', 'IPA', '37'),
(304, 'Selasa', '1234567890 - Dra. MAZIDAH INAYATI ( Matematika / IPA )', '6 ( 10:50:00 - 11:30:00 )', 'Ganjil 2017 / 2018', 'XI-IPA 1', 'IPA', '37'),
(305, 'Selasa', '1234567890 - INGRID ARIANY SAVITRI, S.Pd. ( Biologi / IPA )', '7 ( 12:30:00 - 13:15:00 )', 'Ganjil 2017 / 2018', 'XI-IPA 1', 'IPA', '38'),
(306, 'Selasa', '1234567890 - INGRID ARIANY SAVITRI, S.Pd. ( Biologi / IPA )', '8 ( 13:15:00 - 14:00:00 )', 'Ganjil 2017 / 2018', 'XI-IPA 1', 'IPA', '38'),
(307, 'Selasa', '1234567890 - ENNI SUBCHANDINI, S.Pd ( Kimia / IPA )', '9 ( 14:00:00 - 14:45:00 )', 'Ganjil 2017 / 2018', 'XI-IPA 1', 'IPA', '39'),
(308, 'Selasa', '1234567890 - ENNI SUBCHANDINI, S.Pd ( Kimia / IPA )', '10 ( 14:45:00 - 15:30:00 )', 'Ganjil 2017 / 2018', 'XI-IPA 1', 'IPA', '39'),
(309, '', '', '', 'Ganjil 2017 / 2018', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `jadwalku`
--

CREATE TABLE `jadwalku` (
  `idjadwalnya` int(11) NOT NULL,
  `idperiode` varchar(200) NOT NULL,
  `idhari` varchar(200) NOT NULL,
  `idjam` varchar(100) NOT NULL,
  `idguru` varchar(100) NOT NULL,
  `idmapel` varchar(100) NOT NULL,
  `idkelas` varchar(100) NOT NULL,
  `idjur` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `jampel`
--

CREATE TABLE `jampel` (
  `idjam` int(11) NOT NULL,
  `jamke` varchar(200) NOT NULL,
  `jam_mulai` time NOT NULL,
  `jam_selesai` time NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `jampel`
--

INSERT INTO `jampel` (`idjam`, `jamke`, `jam_mulai`, `jam_selesai`) VALUES
(1, '1', '06:45:00', '07:30:00'),
(2, '2', '07:30:00', '08:15:00'),
(3, '3', '08:15:00', '09:00:00'),
(4, '4', '09:00:00', '09:45:00'),
(5, '5', '10:05:00', '10:50:00'),
(6, '6', '10:50:00', '11:30:00'),
(7, '7', '12:30:00', '13:15:00'),
(8, '8', '13:15:00', '14:00:00'),
(9, '9', '14:00:00', '14:45:00'),
(10, '10', '14:45:00', '15:30:00');

-- --------------------------------------------------------

--
-- Table structure for table `jurusan`
--

CREATE TABLE `jurusan` (
  `idjur` int(11) NOT NULL,
  `nama_jurusan` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `jurusan`
--

INSERT INTO `jurusan` (`idjur`, `nama_jurusan`) VALUES
(1, 'IPA'),
(2, 'IPS'),
(3, 'AGAMA');

-- --------------------------------------------------------

--
-- Table structure for table `kelas`
--

CREATE TABLE `kelas` (
  `idkelas` int(11) NOT NULL,
  `nama_kelas` varchar(200) NOT NULL,
  `idjur` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `kelas`
--

INSERT INTO `kelas` (`idkelas`, `nama_kelas`, `idjur`) VALUES
(1, 'X-MIPA1', '1'),
(2, 'X-MIPA2', '1'),
(3, 'X-MIPA3', '1'),
(4, 'X-IPS1', '2'),
(5, 'X-IPS2', '2'),
(6, 'X-IAG', '3'),
(7, 'XI-IPA 1', '1'),
(8, 'XI-IPA 2', '1'),
(9, 'XI-IPS 1', '2'),
(10, 'XI-IPS 2', '2'),
(11, 'XI-AGAMA', '3'),
(12, 'XII-IPA 1', '1'),
(13, 'XII-IPA 2', '1'),
(14, 'XII-IPS 1', '2'),
(15, 'XII-IPS 2', '2'),
(16, 'XII-AGAMA', '3');

-- --------------------------------------------------------

--
-- Table structure for table `mapel`
--

CREATE TABLE `mapel` (
  `idmapel` int(11) NOT NULL,
  `nama_mapel` varchar(200) NOT NULL,
  `idjur` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `mapel`
--

INSERT INTO `mapel` (`idmapel`, `nama_mapel`, `idjur`) VALUES
(1, 'Fiqih', '1,2,3'),
(2, 'Ushul Fiqih', '2'),
(3, 'Al Quran Hadis', '3'),
(4, 'Aqidah Akhlak', '1'),
(5, 'Akhlak', '1'),
(6, 'S K I', '1'),
(7, 'Pendidikan Kewarganegaraan', '1'),
(8, 'Bahasa Indonesia', '2'),
(9, 'Bhs & Sastra Ind', '3'),
(10, 'Bahasa Arab', '1'),
(11, 'Bahasa Inggris', '2'),
(12, 'Bhs dan Sastra Ing', '2'),
(13, 'Matematika', ''),
(14, 'Sejarah', ''),
(15, 'Ilmu Tafsir', ''),
(16, 'Ilmu Hadits', ''),
(17, 'Ilmu Kalam', ''),
(18, 'Fisika', ''),
(19, 'Kimia', ''),
(20, 'Biologi', ''),
(21, 'Geografi', ''),
(22, 'Ekonomi', ''),
(23, 'Sosiologi', ''),
(24, 'Seni Budaya', ''),
(25, 'Pendidikan Jasmani, ORKES', ''),
(26, 'Teknologi Informasi Komunikasi', ''),
(27, 'Keterampilan', ''),
(28, 'BK', ''),
(29, 'Muhadatsah', ''),
(30, 'BKTI', ''),
(100, 'Abc', '');

-- --------------------------------------------------------

--
-- Table structure for table `periode`
--

CREATE TABLE `periode` (
  `idperiode` int(11) NOT NULL,
  `semester` varchar(200) NOT NULL,
  `tahun_awal` year(4) NOT NULL,
  `tahun_akhir` year(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `periode`
--

INSERT INTO `periode` (`idperiode`, `semester`, `tahun_awal`, `tahun_akhir`) VALUES
(1, 'Ganjil', 2017, 2018),
(2, 'Genap', 2017, 2018),
(3, 'Gasal', 2018, 2019);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id_user` int(11) NOT NULL,
  `email` varchar(200) NOT NULL,
  `password` varchar(200) NOT NULL,
  `nipuser` varchar(200) NOT NULL,
  `nama_lengkap` varchar(200) NOT NULL,
  `level` enum('admin','kepala sekolah','guru','') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id_user`, `email`, `password`, `nipuser`, `nama_lengkap`, `level`) VALUES
(1, 'rahma@mansurabaya.com', 'admin', '1234567890', 'Rahma Azmi Aziz, A.Md', 'admin'),
(2, 'faizal@mansurabaya.com', 'admin', '1234567890', 'Faizal Surya Afdhaludin, S.Kom.I', 'kepala sekolah'),
(3, 'denny1@mansurabaya.com', 'admin', '1234567890', 'Drs. DENNY MF., S.Pdi.', 'guru'),
(4, 'hasan@mansurabaya.com', 'admin', '1234567890', 'Drs. MOKH. HASAN B., M.Pd.', 'guru'),
(5, 'ingrid@mansurabaya.com', 'admin', '1234567890', 'INGRID ARIANY SAVITRI, S.Pd.', 'guru'),
(6, 'ihda@mansurabaya.com', 'admin', '1234567890', 'Dra. IHDA AFIFAH', 'guru'),
(7, 'mazidah@mansurabaya.com', 'admin', '1234567890', 'Dra. MAZIDAH INAYATI', 'guru'),
(8, 'enni@mansurabaya.com', 'admin', '1234567890', 'ENNI SUBCHANDINI, S.Pd', 'guru'),
(9, 'salam@mansurabaya.com', 'admin', '1234567890', 'Drs. ABD. SALAM HS.', 'guru'),
(10, 'sayudi@mansurabaya.com', 'admin', '1234567890', 'SAYUDI, S. Pd.', 'guru'),
(11, 'hadiah@mansurabaya.com', 'admin', '1234567890', 'HADIAH, S.Pd.', 'guru'),
(12, 'teguh@mansurabaya.com', 'admin', '1234567890', 'TEGUH KOESTANTININGSIH, S.Pd', 'guru'),
(13, 'efendi@mansurabaya.com', 'admin', '1234567890', 'Drs. AKHMAD EFENDI', 'guru'),
(14, 'mustofa@mansurabaya.com', 'admin', '1234567890', 'Drs. ALI MUSTOFA, M.Pd', 'guru'),
(15, 'suwinarti@mansurabaya.com', 'admin', '1234567890', 'Dra. SUWINARTI', 'guru'),
(16, 'alfiyah@mansurabaya.com', 'admin', '1234567890', 'ALIFIYAH RUSDIYANA, S.Pd.', 'guru'),
(17, 'nur@mansurabaya.com', 'admin', '1234567890', 'NUR JANAH, S.Pd', 'guru'),
(18, 'agus@mansurabaya.com', 'admin', '1234567890', 'Dra. AGUS SETYANINGSIH, M.Si', 'guru'),
(19, 'yudi@mansurabaya.com', 'admin', '1234567890', 'Drs. YUDI SYAIFULLOH', 'guru'),
(20, 'usman@mansurabaya.com', 'admin', '1234567890', 'USMAN, S.Pd.', 'guru'),
(21, 'ulumiyah@mansurabaya.com', 'admin', '1234567890', 'Dra. ULUMIYAH', 'guru'),
(22, 'yudha@mansurabaya.com', 'admin', '1234567890', 'YUDHA KURNIAWAN, S.Pd.', 'guru'),
(23, 'wiwin@mansurabaya.com', 'admin', '1234567890', 'WIWIN SISWINARNI, S.Pd.', 'guru'),
(24, 'wiji@mansurabaya.com', 'admin', '1234567890', 'WIJI  LAELATUL  JUMAH, S.Pd.', 'guru'),
(25, 'sudik@mansurabaya.com', 'admin', '1234567890', 'TRI SUDIK WIYONO, S.Pd', 'guru'),
(26, 'alief@mansurabaya.com', 'admin', '1234567890', 'ALIEF PURNOMO AJU, S.Pd.', 'guru'),
(27, 'surawan@mansurabaya.com', 'admin', '1234567890', 'SURAWAN, S.Pd.', 'guru'),
(28, 'marifa@mansurabaya.com', 'admin', '1234567890', 'MARIFA RIAMA, S.Pd.', 'guru'),
(29, 'ari@mansurabaya.com', 'admin', '1234567890', 'ARI KUSUMAWATI, M.Pd', 'guru'),
(30, 'yayuk@mansurabaya.com', 'admin', '1234567890', 'YAYUK ISWATIN, S.Pd', 'guru'),
(31, 'aini@mansurabaya.com', 'admin', '1234567890', 'NURUL AINI, S.Pd', 'guru'),
(32, 'neni@mansurabaya.com', 'admin', '1234567890', 'NENI SUHARTINI, S.Pd, M.Psi', 'guru'),
(33, 'arys@mansurabaya.com', 'admin', '1234567890', 'ARYS SUSANTO, M.Pd', 'guru'),
(34, 'anita@mansurabaya.com', 'admin', '1234567890', 'ANITA KURNIA RAHAYU, S.P.', 'guru'),
(35, 'arif@mansurabaya.com', 'admin', '1234567890', 'ARIF MUSTOFA, S.Ag., M.Pd.', 'guru'),
(36, 'suwar@mansurabaya.com', 'admin', '1234567890', 'MUHAMMAD SUWAR, S.Pd.I.', 'guru'),
(37, 'ismi@mansurabaya.com', 'admin', '1234567890', 'ISMI  MARIYAM, S.Pd.', 'guru'),
(38, 'rahmawati@mansurabaya.com', 'admin', '1234567890', 'NUR RAHMAWATI, S.Pd', 'guru'),
(39, 'aheri@mansurabaya.com', 'admin', '1234567890', 'AHERI SUGIHARTONO, S.Th.I', 'guru'),
(40, 'farid@mansurabaya.com', 'admin', '1234567890', 'MOCH. FARID WADJIDI Lc, S.Pd.', 'guru'),
(41, 'insa@mansurabaya.com', 'admin', '1234567890', 'INSA ASYAROH, S.Ag', 'guru'),
(42, 'sunarwan@mansurabaya.com', 'admin', '1234567890', 'SUNARWAN, S.Pd.', 'guru'),
(43, 'abas@mansurabaya.com', 'admin', '1234567890', 'Drs. ABAS SIMAN', 'guru'),
(44, 'maria@mansurabaya.com', 'admin', '1234567890', 'SITI MARIA ULFAH, S.Pd.I', 'guru'),
(45, 'mursalin@mansurabaya.com', 'admin', '1234567890', 'MURSALIN, ST, S.Pd', 'guru'),
(46, 'hanim@mansurabaya.com', 'admin', '1234567890', 'HANIM NURUL AINI, S.Pd.', 'guru'),
(47, 'salim@mansurabaya.com', 'admin', '1234567890', 'AGUS SALIM, S.Pd.', 'guru'),
(48, 'eddi@mansurabaya.com', 'admin', '1234567890', 'EDDI HARIYADI, S,Pd.', 'guru'),
(49, 'mardwi@mansurabaya.com', 'admin', '1234567890', 'MARDWI ASDIYANTO, M.Pd.I.', 'guru'),
(50, 'nashrul@mansurabaya.com', 'admin', '1234567890', 'NASHRUL ULUM, S.Pd.', 'guru'),
(51, 'umar@mansurabaya.com', 'admin', '1234567890', 'UMAR FARUQ, S.Ag.', 'guru'),
(52, 'fuadi@mansurabaya.com', 'admin', '1234567890', 'ALY FUADI, S.Pd.', 'guru'),
(53, 'fatukha@mansurabaya.com', 'admin', '1234567890', 'FATUKHA, S.Pd.', 'guru'),
(54, 'afif@mansurabaya.com', 'admin', '1234567890', 'MOHAMAD AFIF FARICHIN, M.Pd.I.', 'guru');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `dt_ngajar`
--
ALTER TABLE `dt_ngajar`
  ADD PRIMARY KEY (`iddata`);

--
-- Indexes for table `generate_jadwal`
--
ALTER TABLE `generate_jadwal`
  ADD PRIMARY KEY (`id_jadwal`);

--
-- Indexes for table `guru`
--
ALTER TABLE `guru`
  ADD PRIMARY KEY (`idguru`);

--
-- Indexes for table `hari`
--
ALTER TABLE `hari`
  ADD PRIMARY KEY (`idhari`);

--
-- Indexes for table `jadwal`
--
ALTER TABLE `jadwal`
  ADD PRIMARY KEY (`idjadwal`);

--
-- Indexes for table `jadwalku`
--
ALTER TABLE `jadwalku`
  ADD PRIMARY KEY (`idjadwalnya`);

--
-- Indexes for table `jampel`
--
ALTER TABLE `jampel`
  ADD PRIMARY KEY (`idjam`);

--
-- Indexes for table `jurusan`
--
ALTER TABLE `jurusan`
  ADD PRIMARY KEY (`idjur`);

--
-- Indexes for table `kelas`
--
ALTER TABLE `kelas`
  ADD PRIMARY KEY (`idkelas`);

--
-- Indexes for table `mapel`
--
ALTER TABLE `mapel`
  ADD PRIMARY KEY (`idmapel`);

--
-- Indexes for table `periode`
--
ALTER TABLE `periode`
  ADD PRIMARY KEY (`idperiode`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id_user`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `dt_ngajar`
--
ALTER TABLE `dt_ngajar`
  MODIFY `iddata` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `generate_jadwal`
--
ALTER TABLE `generate_jadwal`
  MODIFY `id_jadwal` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=769;
--
-- AUTO_INCREMENT for table `guru`
--
ALTER TABLE `guru`
  MODIFY `idguru` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=117;
--
-- AUTO_INCREMENT for table `hari`
--
ALTER TABLE `hari`
  MODIFY `idhari` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `jadwal`
--
ALTER TABLE `jadwal`
  MODIFY `idjadwal` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=310;
--
-- AUTO_INCREMENT for table `jadwalku`
--
ALTER TABLE `jadwalku`
  MODIFY `idjadwalnya` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `jampel`
--
ALTER TABLE `jampel`
  MODIFY `idjam` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `jurusan`
--
ALTER TABLE `jurusan`
  MODIFY `idjur` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `kelas`
--
ALTER TABLE `kelas`
  MODIFY `idkelas` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;
--
-- AUTO_INCREMENT for table `mapel`
--
ALTER TABLE `mapel`
  MODIFY `idmapel` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=101;
--
-- AUTO_INCREMENT for table `periode`
--
ALTER TABLE `periode`
  MODIFY `idperiode` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id_user` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=55;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
