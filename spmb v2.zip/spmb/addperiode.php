<?php 
if(isset($_POST['add'])){
	include "koneksi.php";
	$idperiode = $_POST['idperiode'];
	$semester = $_POST['semester'];
	$tahun_awal = $_POST['tahun_awal'];
	$tahun_akhir = $_POST['tahun_akhir'];
	$sql = "insert into periode (idperiode, semester, tahun_awal, tahun_akhir) 
	VALUES('$idperiode', '$semester', '$tahun_awal', '$tahun_akhir')";
	if (mysqli_query($conn, $sql)) {
		header ('location:periode.php');
	} else {
		echo 'Error: ' . $sql. " . " .mysqli_error($conn);
	}
}
?>