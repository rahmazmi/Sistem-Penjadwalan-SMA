<?php
if(isset($_POST['delete'])){
	include "koneksi.php";
	$hapusmapel = $_POST['idmapel'];
	$del = "delete from mapel where idmapel = '$hapusmapel'";
	if (mysqli_query($conn, $del)) {
		header ('location:dtmapel.php');
	} else {
		echo 'Error deleting record: ' . mysqli_error($conn);
	}
}
?>