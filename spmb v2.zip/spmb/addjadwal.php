<?php 
if(isset($_POST['add'])){
	include "koneksi.php";
	$tahun = $_POST['id_periode'];
	$hari = $_POST['idhari'];
	$jam = $_POST['idjam'];
	$guru = $_POST['idguru'];
	$jurusan = $_POST['idjur'];
	$kelas = $_POST['idkelas'];
	$sql = "insert into jadwal (idperiode, hari, idjam, idguru, idjur, idkelas) 
	VALUES('$tahun', '$hari', '$jam', '$guru', '$jurusan', '$kelas')";
	if (mysqli_query($conn, $sql)) {
		header ('location:jadwals.php');
	} else {
		echo 'Error: ' . $sql. " . " .mysqli_error($conn);
	}
}
?>