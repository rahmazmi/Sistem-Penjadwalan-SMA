<?php 
if(isset($_POST['add'])){
	include "koneksi.php";
	$idmapel = $_POST['idmapel'];
	$nama_mapel = $_POST['nama_mapel'];
	$jurusan = $_POST['idjur'];
	$sql = "insert into mapel (idmapel, nama_mapel, idjur) 
	VALUES('$idmapel', '$nama_mapel', '$jurusan')";
	if (mysqli_query($conn, $sql)) {
		header ('location:dtmapel.php');
	} else {
		echo 'Error: ' . $sql. " . " .mysqli_error($conn);
	}
}
?>