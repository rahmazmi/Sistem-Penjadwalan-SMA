<?php
if(isset($_POST['delete'])){
	include "koneksi.php";
	$hapusperiode = $_POST['idperiode'];
	$del = "delete from periode where idperiode = '$hapusperiode'";
	if (mysqli_query($conn, $del)) {
		header ('location:periode.php');
	} else {
		echo 'Error deleting record: ' . mysqli_error($conn);
	}
}
?>