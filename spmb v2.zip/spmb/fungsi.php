<?php 
function insertupdate($num)
{
    include 'connect.php';

    $minggu = floor($num / 10000) % 10;
    $hari   = floor($num / 1000) % 10;
    $jam    = (floor($num / 100)) % 10;
    $ruang  = floor($num / 10) % 10;
    $con    = $num % 10;
    if ($minggu == 0) {
        $minggu = "jadwal_lab";
    } else {
        $minggu = "jadwal_lab2";
    }
    ;
    if ($con == 0) {
        $sql = "SELECT * FROM " . $minggu . " WHERE hari=" . $hari . " and waktu =" . $jam . " and ruangan=" . $ruang . ";";
        $tes = mysqli_query($conn, $sql);
        if (!mysqli_num_rows($tes)) //agar tidak dobel
        {
            $sql = "INSERT INTO " . $minggu . " (kode_matkul,grup,waktu,hari,ruangan) VALUES ('" . $_POST["kode_matkul"] . "'," . $_POST["kode_grup"] . "," . $jam . "," . $hari . "," . $ruang . ");";
        }
    } else if ($con == 1) {
        $sql = "update " . $minggu . " set kode_kelas='" . $_POST["data"] . "' where hari=" . $_POST["hari"] . " and waktu =" . $_POST["jam"] . " and ruangan=" . $_POST['ruang'] . ";";
    } else {
        $sql = "DELETE FROM " . $minggu . " WHERE hari=" . $hari . " and waktu =" . $jam . " and ruangan=" . $ruang . ";";
    }
    if (mysqli_query($conn, $sql))
        return true;
    else
        return true;
}

?>