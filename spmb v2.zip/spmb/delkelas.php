<?php
if(isset($_POST['delete'])){
	include "koneksi.php";
	$hapuskelas = $_POST['idkelas'];
	$del = "delete from kelas where idkelas = '$hapuskelas'";
	if (mysqli_query($conn, $del)) {
		header ('location:dtkelas.php');
	} else {
		echo 'Error deleting record: ' . mysqli_error($conn);
	}
}
?>