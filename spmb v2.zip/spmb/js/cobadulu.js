<?php
class GraphColoring
{
   private $graph      = array();
   private $savedGraph = array();
   private $colored    = array();
   private $colors     = array();
   private $k = 1;
   private $d = 0;
   private $source;
   private $sourceType;
   private $vertexTotal;
   private $vertexNo;
 
   function initSource($source, $sourceType = "file")
   {
      $this->source      =  $source;
     
      $this->sourceType  =  $sourceType;		
   }
   
   function initGraph()
   {     
      $isValidFile = ($this->sourceType == "file" && file_exists(trim($this->source)));
      
      if($isValidFile)
      {
         $this->getGraphFromFile($this->source);	
      }
      elseif($this->sourceType == "DB")
      {
         $this->getGraphFromDb($this->source);		
      }
      else
      {
         die("Invalid Information");	
      }            
      
   }
   
   function initColoring()
   {
      $this->vertexNo = $this->vertexTotal;            
      $this->dBug('No. of Vertices of the Input Graph : '.$this->vertexNo);            
      $this->dBug('------ Array Representation of the Input Graph --------');                        
      $this->dBug($this->graph);
      $this->dBug('-------------------------------------------------------');
      
      
      while($this->vertexNo)
      {
         	$this->colorTheGraph();         	          
          $this->recoverTheGraph();         	         	         
      }
      
            
   }
   
   function colorTheGraph()
   {               	     	  
      $this->d++; //No. of colors
      
      for($i=1;$i<=$this->vertexTotal;$i++)
      {
          for($j=1;$j<=$this->vertexTotal;$j++)
          {
             if($this->graph[$i][$j] == 1)
             {
                $this->vertexNo = $this->vertexNo - 1;  //remaining vertices                                              
                $this->k++;
                $this->colored[$this->k] = $i;          // storage of colored vertices
                $this->colors[$this->d][$this->k] = $i; // storage of colored vertices
                $this->processGraph($i);
             }
             else
             {
                $this->graph[$i][$j] = 0;                
             }  
          }
      }
   }
   
   function displayColorResult()
   {
   	  $this->dBug('------------ Coloring Result ---------------------');
      $this->dBug('No. of Colors : '.count($this->colors));
      foreach($this->colors as $i=>$v)
      {
         $this->dBug("Color : $i");
         $this->dBug('Vertices : '.implode(",", $v));         
      } 
        	      
      $this->dBug('--------------------------------------------------');
      
   }//EOFn
   
   /**
   * Disconnects a colered vertex from its connected ones -- duplex disconnection
   * @param colored vertex
   * @return none
   */
   function processGraph($j)
   {
      for($i=1;$i<=$this->vertexTotal; $i++)
      {
         if($this->graph[$j][$i]==1)
         {
            $this->graph[$j][$i]=0;
            $this->subProcess($i);
         }
      }
   }//EOfn
   
   /**
   * Disconnects a vertex(which is connected to a colored vertex) from its connected ones -- simplex disconnection
   * @param a vertex connected to the newly colored vertex
   * @return none
   */
   function subProcess($m)
   {
      for($i=1;$i<=$this->vertexTotal;$i++)
      {
         if($this->graph[$m][$i]==1)
         {
            $this->graph[$m][$i]=0;
         }
      }	
   
   }//EOFn
   
  function recoverTheGraph()
  {
      for($i=1 ; $i<=$this->vertexTotal ; $i++)
      {
         for($j=1 ; $j<=$this->vertexTotal ; $j++)
         {
             if(!array_search($i, $this->colored))
             {
	              $this->graph[$i][$j]=$this->savedGraph[$i][$j];
             }
             else
             {
	              $this->graph[$i][$j]=0;
	              $this->graph[$j][$i]=0;
             }
         }
      }
      
  }//EOFn

  /**
  * Gets graph data from file
  * @param filename
  * @return none
  */
 
  function getGraphFromDb($sourceTable)
  {
  	 //DB Connection
    include "koneksi.php";
          
     $q = "SELECT * FROM graph_a";               
     $res = mysqli_query($conn, $q);
     
     // If data found
     if(mysqli_num_rows($res))
     {
        while($row = mysqli_fetch_array($res))
        {
        	  $i = trim($row['vertex']);
        	  $j = trim($row['koneksi']);
        	 
        	 // Initializing the graph - Initializing the connections
           $this->graph[$i][$j]      = 1;
           $this->graph[$j][$i]      = 1;	
           $this->savedGraph[$i][$j] = 1;	
           $this->savedGraph[$j][$i] = 1;		
        }
     }
     else
     {
        die("Data Invalid OR Does Not Exist..");
     }	
     
     $this->vertexTotal = count($this->graph); //Total vertices
     
     //Filling up the reminding connections with zero     
     if(count($this->graph))
     {
        for($i=1; $i <= $this->vertexTotal; $i++)
        {
           for($j=1; $j <= $this->vertexTotal; $j++)	
           {
              if($this->graph[$i][$j]!=1)
              {
                 $this->graph[$i][$j] = 0;
                 $this->savedGraph[$i][$j] = 0;
              }	
           }
        }	
     }
  }//EOFn
  
  /**
  * Displays/dumps data
  * @param data to be dumped
  * @return none
  */
  function dBug($dump)
  {
     echo "<PRE>";	
     print_r($dump);
     echo "</PRE>";	
  }//EOFn

}//EO Class GraphColoring
?>