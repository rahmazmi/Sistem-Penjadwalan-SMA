<?php
if(isset($_POST['delete'])){
	include "koneksi.php";
	$hapus = $_POST['idepangajar'];
	$del = "delete from guru where idguru = '$hapus'";
	if (mysqli_query($conn, $del)) {
		header ('location:dtguru.php');
	} else {
		echo 'Error deleting record: ' . mysqli_error($conn);
	}
}
?>