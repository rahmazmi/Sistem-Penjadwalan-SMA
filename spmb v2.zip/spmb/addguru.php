<?php 
if(isset($_POST['add'])){
	include "koneksi.php";
	$idguru = $_POST['idpengajar'];
	$namaguru = $_POST['id_user'];
	$jurusan = $_POST['idjur'];
	$mapel = $_POST['idmapel'];
	$sql = "insert into guru (idguru, nama_guru, jurusannya, mapel_ajar) 
	VALUES('$idguru', '$namaguru', '$jurusan', '$mapel')";
	if (mysqli_query($conn, $sql)) {
		header ('location:dtguru.php');
	} else {
		echo 'Error: ' . $sql. " . " .mysqli_error($conn);
	}
}
?>