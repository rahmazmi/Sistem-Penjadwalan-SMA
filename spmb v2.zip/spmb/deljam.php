<?php
if(isset($_POST['delete'])){
	include "koneksi.php";
	$hapusjam = $_POST['idjam'];
	$del = "delete from jampel where idjam = '$hapusjam'";
	if (mysqli_query($conn, $del)) {
		header ('location:dtjam.php');
	} else {
		echo 'Error deleting record: ' . mysqli_error($conn);
	}
}
?>