<?php
include "koneksi1.php";
  $id   = $_POST['hapususer'];
  $query = mysql_query("DELETE FROM `user` WHERE `user`.`id_user`='$iduser'");
  if(mysql_num_rows($query)==1){
    echo "<script>document.location='dtguru.php'</script>";
  }
  else{
    echo "Data Tidak Ditemukan";
  }
?>
