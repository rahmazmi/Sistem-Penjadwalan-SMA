<?php 
if(isset($_POST['add'])){
	include "koneksi.php";
	$idkelas = $_POST['idkelas'];
	$nama_kelas = $_POST['nama_kelas'];
	$jurusan = $_POST['idjur'];
	$sql = "insert into kelas (idkelas, nama_kelas, idjur) 
	VALUES('$idkelas', '$nama_kelas', '$jurusan')";
	if (mysqli_query($conn, $sql)) {
		header ('location:dtkelas.php');
	} else {
		echo 'Error: ' . $sql. " . " .mysqli_error($conn);
	}
}
?>