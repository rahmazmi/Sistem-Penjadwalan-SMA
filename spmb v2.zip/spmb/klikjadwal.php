<?php
// QUERY SAMPAH
//SELECT * FROM `mapel` WHERE nama_mapel not IN (SELECT mapel_ajar FROM guru) 

$config['host']		= 'localhost';
$config['username']	= 'root';
$config['password']	= '';
$config['database']	= 'db_jadwal';

mysql_connect($config['host'],$config['username'],$config['password']) or die("Access denied for user '".$config['username']."'");
mysql_select_db($config['database']) or die("Unknown database '".$config['database']."'");

ini_set('max_execution_time', 0);
error_reporting(0);

function jam($data){
	$data = explode(':',$data);
	return $data[0].':'.$data[1];
}

if(isset($_POST['act']) and $_POST['act'] == 'getJenis'){
	
	if($_POST['jenis'] == 'kelas'){
		$query = mysql_query("SELECT * FROM kelas");
		echo '<select name="filter" id="filter" class="form-control grid-4" onChange="filter(this.value);" >
          <option value="">Pilih Kelas</option>';
		 
		while($data = mysql_fetch_object($query)){
			echo '<option value="'.$data->nama_kelas.'">'.$data->nama_kelas.'</option>';
		};
		echo '</select>';
	}else if($_POST['jenis'] == 'guru'){
		$query = mysql_query("SELECT * FROM user");
		echo '<select name="filter" id="filter" class="form-control grid-4" onChange="filter(this.value);" >
          <option value="">Pilih Guru</option>';
		 
		while($data = mysql_fetch_object($query)){
			echo '<option value="'.$data->nama_lengkap.'">'.$data->nama_lengkap.'</option>';
		};
		echo '</select>';
	}else{
		echo '';
	}
	
	
	die();
};

if(isset($_POST['act']) and $_POST['act'] == 'getJadwal'){
	
	if(isset($_POST['jenis']) and $_POST['jenis'] == 'kelas'){
		$query = mysql_query("SELECT * FROM jurusan, kelas WHERE jurusan.idjur = kelas.idjur AND nama_kelas = '".$_POST['filter']."'");
		
	}else{
		$query = mysql_query("SELECT * FROM jurusan, kelas WHERE jurusan.idjur = kelas.idjur");
		
	}
	
	$qr_periode = mysql_query("SELECT * FROM periode ORDER BY idperiode DESC LIMIT 1");
	$periode = mysql_fetch_object($qr_periode);
	
	while($hasil = mysql_fetch_object($query)){
		
		echo '<table class="table table-bordered">';
		echo '<tr><td colspan="6" align="center">Kelas '.$hasil->nama_kelas.'<br/>Semester '.$periode->semester.' Tahun '.$periode->tahun_awal.'/'.$periode->tahun_akhir.'</td></tr>';
		echo  '<tr>
				<td>Jam</td>
				<td>Senin</td>
				<td>Selasa</td>
				<td>Rabu</td>
				<td>Kamis</td>
				<td>Jumat</td>
			  </tr>';
			
			$query2 = mysql_query("SELECT * FROM jampel");
			while($hasil2 = mysql_fetch_object($query2)){
				
				echo  '<tr>
						   <td>'.jam($hasil2->jam_mulai).' - '.jam($hasil2->jam_selesai).'</td>';
				$query3 = mysql_query("SELECT * FROM generate_jadwal WHERE nama_kelas = '".$hasil->nama_kelas."' AND jamke = '".$hasil2->jamke."'");
				while($hasil3 = mysql_fetch_object($query3)){
					if($_POST['jenis'] == 'guru'){
						if($hasil3->nama_guru == $_POST['filter']){
							echo  '<td>'.$hasil3->mapel_ajar.'<br/>'.$hasil3->nama_guru.'</td>';
						}else{
							echo  '<td>&nbsp;</td>';
						}
					}else{
						echo  '<td>'.$hasil3->mapel_ajar.'<br/>'.$hasil3->nama_guru.'</td>';
					}
				}
				echo '</tr>';
			}
			
		echo '</table>';
	};
}

if(isset($_POST['act']) and $_POST['act'] == 'generateJadwal'){
	mysql_query("TRUNCATE generate_jadwal");
	
	$qr_periode = mysql_query("SELECT * FROM periode ORDER BY idperiode DESC LIMIT 1");
	$periode = mysql_fetch_object($qr_periode);
	
	$query = mysql_query("SELECT * FROM hari");
	while($data = mysql_fetch_object($query)){
		//echo $data->nama_hari.'<br/>';
		
		$query1 = mysql_query("SELECT * FROM jampel");
		$jamke = 0;
		while($data1 = mysql_fetch_object($query1)){
			$jamke++;
	
			if($data->nama_hari == 'Jumat' and $data1->jamke > 8) continue;
			
			$query2 = mysql_query("SELECT * FROM kelas, jurusan WHERE kelas.idjur = jurusan.idjur");
			while($data2 = mysql_fetch_object($query2)){
				//echo $data2->nama_jurusan.'<br/>';
				//echo $data2->nama_kelas.'<br/>';
	
				$query3 = mysql_query("SELECT * FROM guru
										WHERE
										jurusannya = '".$data2->nama_jurusan."'
										AND mapel_ajar NOT IN
											(SELECT mapel_ajar FROM generate_jadwal WHERE hari = '".$data->nama_hari."' AND (jamke = '".$jamke."' OR nama_kelas = '".$data2->nama_kelas."'))
									   ORDER BY RAND()");
				$data3 = mysql_fetch_object($query3);
				
				$nama_guru = explode(' - ',$data3->nama_guru);
				$nama_guru = $nama_guru[1];
				
				mysql_query("INSERT INTO generate_jadwal(idperiode, nama_jurusan, nama_kelas, hari, jamke, nama_guru, mapel_ajar)
								 VALUES('".$periode->idperiode."','".$data2->nama_jurusan."','".$data2->nama_kelas."','".$data->nama_hari."','".$jamke."','".$nama_guru."','".$data3->mapel_ajar."')");
					
			};
		};
	};
};
