<!--
Author: W3layouts
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE HTML>
<html>
<head>
<title>Sistem Penjadwalan MAN Surabaya</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Modern Responsive web template, Bootstrap Web Templates, Flat Web Templates, Andriod Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyErricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
 <!-- Bootstrap Core CSS -->
<link href="css/bootstrap.min.css" rel='stylesheet' type='text/css' />
<!-- Custom CSS -->
<link href="css/style.css" rel='stylesheet' type='text/css' />
<link href="css/font-awesome.css" rel="stylesheet"> 
<!-- jQuery -->
<script src="js/jquery.min.js"></script>

<!-- Bootstrap Core JavaScript -->
<script src="js/bootstrap.min.js"></script>
</head>
<body>
<div id="wrapper">
     <!-- Navigation -->
        <nav class="top1 navbar navbar-default navbar-static-top" role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="home.php">SPMP</a>
            </div>
            <!-- /.navbar-header -->
            <ul class="nav navbar-nav navbar-right">
			    <li class="dropdown">
	        		<a href="#" class="dropdown-toggle avatar" data-toggle="dropdown">Haiii, Anda sedang Login Sebagai Admin</a>
	        		<ul class="dropdown-menu">
						<li class="dropdown-menu-header text-center">
							<strong>Settings</strong>
						</li>
						<li class="m_2"><a href="profile.php"><i class="fa fa-user"></i> Profile</a></li>
						<li class="divider"></li>
						<li class="m_2"><a href="logout.php"><i class="fa fa-lock"></i> Logout</a></li>	
	        		</ul>
	      		</li>
			</ul>
			
			
			
			
			
            <div class="navbar-default sidebar" role="navigation">
                <div class="sidebar-nav navbar-collapse">
                    <ul class="nav" id="side-menu">
                        <li>
                            <a href="home.php"><i class="fa fa-dashboard fa-fw nav_icon"></i>Beranda</a>
                        </li>
                        <li>
                            <a href="#"><i class="fa fa-laptop nav_icon"></i>Master<span class="fa arrow"></span></a>
                            <ul class="nav nav-second-level">
                                <li>
                                    <a href="dtuser.php">User</a>
                                </li>
								<li>
                                    <a href="dtguru.php">Guru</a>
                                </li>
								<li>
                                    <a href="dtmapel.php">Mata Pelajaran</a>
                                </li>
								<li>
                                    <a href="dtkelas.php">Kelas</a>
                                </li>
								<li>
                                    <a href="dtjurusan.php">Jurusan</a>
                                </li>
								<li>
                                    <a href="dtjam.php">Jam Pelajaran</a>
                                </li>
                            </ul>
							<!-- /.nav-second-level -->
                        </li>
                        <li>
                            <a href="periode.php"><i class="fa fa-indent nav_icon"></i>Periode</a>
                        </li>
                         <li>
						 <!-- /.nav-second-level -->
                        </li>
                        <li>
                            <a href="jadwal.php"><i class="fa fa-table nav_icon"></i>Jadwal</a>
                        </li>
                         <li>
                        </li>
                    </ul>
                </div>
                <!-- /.sidebar-collapse -->
            </div>
            <!-- /.navbar-static-side -->
        </nav>
		
		<?php 
		include ('koneksi.php');
		if (isset($_GET['id'])){
			$id = $_GET['id'];
			$edit = mysqli_query($conn, "select * from guru where idguru = '$id'"); 
			$data = mysqli_fetch_array($edit);
			$namanya = $data['nama_guru'];
			$mapelnya = $data['mapel_ajar'];
			$jurusannya = $data['jurusannya'];
			$kelasnya = $data['kelas_ajar'];
		} ?>
		
         <div id="page-wrapper">
        <div class="graphs">
	     <div class="xs">
		 
  	       <h3>Forms Edit Data</h3>
  	         <div class="tab-content">
						<div class="tab-pane active" id="horizontal-form">
							<form action="upguru.php" class="form-horizontal" method="post">
								<div class="form-group">
									<label for="focusedinput" class="col-sm-2 control-label">ID Guru</label>
									<div class="col-sm-8">
										<input type="number" name="id" value="<?php echo $_GET['id']; ?>" class="form-control1" id="focusedinput" placeholder="ID">
									</div>
								</div>
								<div class="form-group">
									<label for="focusedinput" class="col-sm-2 control-label">Nama Guru</label>
									<div class="col-sm-8">
										<input type="text" name="nama_guru" value="<?php echo $namanya; ?>" class="form-control1" id="focusedinput" placeholder="E-mail">
									</div>
								</div>
								<div class="form-group">
									<label for="focusedinput" class="col-sm-2 control-label">Mata Pelajaran</label>
									<div class="col-sm-8">
										<input type="text" name="mapel_ajar" value="<?php echo $mapelnya; ?>" class="form-control1" id="inputPassword" placeholder="Password">
									</div>
								</div>
								<div class="form-group">
									<label for="focusedinput" class="col-sm-2 control-label">Jurusan</label>
									<div class="col-sm-8">
										<input type="text" name="jurusannya" value="<?php echo $jurusannya; ?>" class="form-control1" id="focusedinput" placeholder="NIP">
									</div>
								</div>
								<div class="form-group">
									<label for="focusedinput" class="col-sm-2 control-label">Kelas</label>
									<div class="col-sm-8">
										<input type="text" name="kelas_ajar" value="<?php echo $kelasnya; ?>" class="form-control1" id="focusedinput" placeholder="Nama Lengkap">
									</div>
								</div>
								
							
						</div>
					</div>
					 <div class="panel-footer">
		<div class="row">
			<div class="col-sm-8 col-sm-offset-2">
				<button type="submit" name="update" class="btn-success btn">Edit</button>
				<button class="btn-default btn">Cancel</button>
			</div>
		</div>
		</form>

	 </div>
		
   <div class="copy_layout">
      <p>Copyright © 2015 Modern. All Rights Reserved | Design by <a href="http://w3layouts.com/" target="_blank">W3layouts</a> </p>
  </div>
   </div>
      </div>
      <!-- /#page-wrapper -->
   </div>
    <!-- /#wrapper -->
<!-- Nav CSS -->
<link href="css/custom.css" rel="stylesheet">
<!-- Metis Menu Plugin JavaScript -->
<script src="js/metisMenu.min.js"></script>
<script src="js/custom.js"></script>
</body>
</html>