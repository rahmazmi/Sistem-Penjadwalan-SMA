-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: 06 Jan 2018 pada 02.42
-- Versi Server: 10.1.16-MariaDB
-- PHP Version: 5.6.24

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_jadwal`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `dt_ngajar`
--

CREATE TABLE `dt_ngajar` (
  `iddata` int(11) NOT NULL,
  `gurunya` varchar(200) NOT NULL,
  `mapelnya` varchar(200) NOT NULL,
  `jurnya` varchar(200) NOT NULL,
  `kelasnya` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Struktur dari tabel `guru`
--

CREATE TABLE `guru` (
  `idguru` int(11) NOT NULL,
  `nama_guru` varchar(200) NOT NULL,
  `mapel_ajar` varchar(200) NOT NULL,
  `jurusannya` varchar(200) NOT NULL,
  `kelas_ajar` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `guru`
--

INSERT INTO `guru` (`idguru`, `nama_guru`, `mapel_ajar`, `jurusannya`, `kelas_ajar`) VALUES
(1, '1234567890 - Drs. DENNY MF., S.Pd.', 'Fisika', 'IPA', 'X-MIPA1'),
(2, '1234567890 - INGRID ARIANY SAVITRI, S.Pd.', 'Biologi', 'IPA', 'X-MIPA1'),
(3, '1234567890 - Drs. YUDI SYAIFULLOH', 'Pendidikan Jasmani, ORKES', 'IPA', 'X-MIPA1'),
(4, '1234567890 - Drs. YUDI SYAIFULLOH', 'Pendidikan Jasmani, ORKES', 'IPS', 'X-IPS1'),
(5, '1234567890 - Drs. MOKH. HASAN B., M.Pd.', 'Fisika', 'IPA', 'X-MIPA2'),
(6, '1234567890 - Dra. MAZIDAH INAYATI', 'Matematika', 'IPA', 'X-MIPA1'),
(7, '1234567890 - ENNI SUBCHANDINI, S.Pd', 'Kimia', 'IPA', 'X-MIPA1'),
(8, '1234567890 - Drs. ABD. SALAM HS.', 'Fiqih', 'IPA', 'X-MIPA1'),
(9, '1234567890 - Drs. ABD. SALAM HS.', 'Fiqih', 'IPS', 'X-IPS1'),
(10, '1234567890 - Drs. ABD. SALAM HS.', 'Fiqih', 'AGAMA', 'X-IAG'),
(11, '1234567890 - Drs. ABD. SALAM HS.', 'Ushul Fiqih', 'AGAMA', 'X-IAG'),
(12, '1234567890 - SAYUDI, S. Pd.', 'Bahasa Indonesia', 'AGAMA', 'X-IAG'),
(13, '1234567890 - HADIAH, S.Pd.', 'Ekonomi', 'IPS', 'X-IPS1'),
(14, '1234567890 - TEGUH KOESTANTININGSIH, S.Pd', 'Keterampilan', 'IPA', 'X-MIPA1'),
(15, '1234567890 - Drs. AKHMAD EFENDI', 'Teknologi Informasi Komunikasi', 'IPA', 'X-MIPA1'),
(16, '1234567890 - Drs. ALI MUSTOFA, M.Pd', 'Geografi', 'IPA', 'X-MIPA1'),
(17, '1234567890 - Dra. SUWINARTI', 'Geografi', 'IPS', 'X-IPS1'),
(18, '1234567890 - ALIFIYAH RUSDIYANA, S.Pd.', 'Bahasa Inggris', 'IPA', 'X-MIPA1'),
(19, '1234567890 - NUR JANAH, S.Pd', 'Keterampilan', 'AGAMA', 'X-MIPA1'),
(20, '1234567890 - Dra. AGUS SETYANINGSIH, M.Si', 'Matematika', 'IPA', 'X-MIPA2'),
(21, '1234567890 - Drs. YUDI SYAIFULLOH', 'Pendidikan Jasmani, ORKES', 'AGAMA', 'X-IAG'),
(22, '1234567890 - SAYUDI, S. Pd.', 'Bahasa Indonesia', 'IPA', 'X-MIPA2'),
(23, '1234567890 - HADIAH, S.Pd.', 'Ekonomi', 'IPA', 'X-MIPA2'),
(24, '1234567890 - TEGUH KOESTANTININGSIH, S.Pd', 'Keterampilan', 'IPS', 'X-IPS1'),
(25, '1234567890 - Drs. AKHMAD EFENDI', 'Teknologi Informasi Komunikasi', 'IPS', 'X-IPS1'),
(26, '1234567890 - Drs. ALI MUSTOFA, M.Pd', 'Geografi', 'IPS', ''),
(27, '1234567890 - Dra. SUWINARTI', 'Geografi', 'IPA', ''),
(28, '1234567890 - ALIFIYAH RUSDIYANA, S.Pd.', 'Bahasa Inggris', 'AGAMA', ''),
(29, '1234567890 - NUR JANAH, S.Pd', 'Keterampilan', 'IPA', ''),
(30, '1234567890 - Dra. AGUS SETYANINGSIH, M.Si', 'Matematika', 'AGAMA', ''),
(31, '1234567890 - USMAN, S.Pd.', 'Bahasa Indonesia', 'AGAMA', 'X-IAG'),
(32, '1234567890 - Dra. ULUMIYAH', 'BKTI', 'IPS', ''),
(34, '1234567890 - TEGUH KOESTANTININGSIH, S.Pd', 'Keterampilan', 'AGAMA', ''),
(35, '1234567890 - Drs. AKHMAD EFENDI', 'Teknologi Informasi Komunikasi', 'AGAMA', ''),
(36, '1234567890 - Dra. ULUMIYAH', 'BKTI', 'AGAMA', ''),
(37, '1234567890 - YUDHA KURNIAWAN, S.Pd.', 'Pendidikan Jasmani, ORKES', 'IPA', ''),
(40, '1234567890 - Dra. AGUS SETYANINGSIH, M.Si', 'Matematika', 'IPS', ''),
(41, '1234567890 - USMAN, S.Pd.', 'Bahasa Indonesia', 'IPS', ''),
(42, '1234567890 - Dra. ULUMIYAH', 'BKTI', 'IPA', ''),
(43, '1234567890 - YUDHA KURNIAWAN, S.Pd.', 'Pendidikan Jasmani, ORKES', 'AGAMA', ''),
(44, '1234567890 - WIWIN SISWINARNI, S.Pd.', 'Pendidikan Kewarganegaraan', 'IPS', ''),
(45, '1234567890 - WIJI LAELATUL JUMAH, S.Pd.', 'Bahasa Indonesia', 'IPS', ''),
(46, '1234567890 - TRI SUDIK WIYONO, S.Pd', 'Ekonomi', 'IPS', ''),
(47, '1234567890 - ALIEF PURNOMO AJU, S.Pd.', 'Kimia', 'IPA', ''),
(48, '1234567890 - SURAWAN, S.Pd.', 'Bahasa Inggris', 'IPS', ''),
(49, '1234567890 - MARIFA RIAMA, S.Pd.', 'Sejarah', 'AGAMA', ''),
(50, '1234567890 - ARI KUSUMAWATI, M.Pd', 'Matematika', 'IPA', ''),
(51, '1234567890 - YAYUK ISWATIN, S.Pd', 'Seni Budaya', 'AGAMA', ''),
(52, '1234567890 - NURUL AINI, S.Pd', 'Matematika', 'AGAMA', ''),
(53, '1234567890 - NENI SUHARTINI, S.Pd, M.Psi', 'BK', 'IPA', ''),
(54, '1234567890 - WIWIN SISWINARNI, S.Pd.', 'Pendidikan Kewarganegaraan', 'IPA', ''),
(55, '1234567890 - WIJI LAELATUL JUMAH, S.Pd.', 'Bahasa Indonesia', 'IPA', ''),
(56, '1234567890 - TRI SUDIK WIYONO, S.Pd', 'Ekonomi', 'IPA', ''),
(57, '1234567890 - ARYS SUSANTO, M.Pd', 'Fisika', 'IPA', ''),
(58, '1234567890 - SURAWAN, S.Pd.', 'Bahasa Inggris', 'AGAMA', ''),
(59, '1234567890 - MARIFA RIAMA, S.Pd.', 'Sejarah', 'IPA', ''),
(60, '1234567890 - ANITA KURNIA RAHAYU, S.P.', 'Biologi', 'IPA', ''),
(61, '1234567890 - YAYUK ISWATIN, S.Pd', 'Seni Budaya', 'IPS', ''),
(62, '1234567890 - NURUL AINI, S.Pd', 'Matematika', 'IPA', ''),
(63, '1234567890 - ARYS SUSANTO, M.Pd', 'Fisika', 'IPA', ''),
(64, '1234567890 - WIWIN SISWINARNI, S.Pd.', 'Pendidikan Kewarganegaraan', 'AGAMA', ''),
(65, '1234567890 - ARIF MUSTOFA, S.Ag., M.Pd.', 'Fiqih', 'IPA', ''),
(66, '1234567890 - MUHAMMAD SUWAR, S.Pd.I.', 'Bahasa Arab', 'IPA', ''),
(67, '1234567890 - ISMI MARIYAM, S.Pd.', 'Bahasa Indonesia', 'IPA', ''),
(68, '1234567890 - MARIFA RIAMA, S.Pd.', 'Sejarah', 'IPS', ''),
(69, '1234567890 - SURAWAN, S.Pd.', 'Bahasa Inggris', 'IPA', ''),
(70, '1234567890 - ARIF MUSTOFA, S.Ag., M.Pd.', 'Ushul Fiqih', 'AGAMA', ''),
(71, '1234567890 - YAYUK ISWATIN, S.Pd', 'Seni Budaya', 'IPA', ''),
(72, '1234567890 - NURUL AINI, S.Pd', 'Matematika', 'IPS', ''),
(73, '1234567890 - NENI SUHARTINI, S.Pd, M.Psi', 'BK', 'AGAMA', ''),
(74, '1234567890 - MUHAMMAD SUWAR, S.Pd.I.', 'Bahasa Arab', 'IPS', ''),
(75, '1234567890 - ARIF MUSTOFA, S.Ag., M.Pd.', 'Fiqih', 'AGAMA', ''),
(76, '1234567890 - ISMI MARIYAM, S.Pd.', 'Bhs & Sastra Ind', 'IPS', ''),
(77, '1234567890 - NUR RAHMAWATI, S.Pd', 'Bahasa Indonesia', 'IPA', ''),
(78, '1234567890 - AHERI SUGIHARTONO, S.Th.I', 'Aqidah Akhlak', 'IPA', ''),
(79, '1234567890 - MOCH. FARID WADJIDI Lc, S.Pd.', 'Biologi', 'IPA', ''),
(80, '1234567890 - MUHAMMAD SUWAR, S.Pd.I.', 'Bahasa Arab', 'AGAMA', ''),
(81, '1234567890 - ISMI MARIYAM, S.Pd.', 'Bhs & Sastra Ind', 'AGAMA', ''),
(82, '1234567890 - NUR RAHMAWATI, S.Pd', 'Bhs & Sastra Ind', 'IPS', ''),
(83, '1234567890 - AHERI SUGIHARTONO, S.Th.I', 'Aqidah Akhlak', 'IPS', ''),
(84, '1234567890 - INSA ASYAROH, S.Ag', 'Al Quran Hadis', 'IPS', ''),
(85, '1234567890 - ARIF MUSTOFA, S.Ag., M.Pd.', 'Fiqih', 'IPS', ''),
(86, '1234567890 - NUR RAHMAWATI, S.Pd', 'Bhs & Sastra Ind', 'AGAMA', ''),
(87, '1234567890 - SURAWAN, S.Pd.', 'Kimia', 'IPA', ''),
(88, '1234567890 - Drs. ABAS SIMAN', 'Pendidikan Kewarganegaraan', 'IPA', ''),
(90, '1234567890 - AHERI SUGIHARTONO, S.Th.I', 'Aqidah Akhlak', 'AGAMA', ''),
(91, '1234567890 - INSA ASYAROH, S.Ag', 'Al Quran Hadis', 'IPA', ''),
(92, '1234567890 - SITI MARIA ULFAH, S.Pd.I', 'Al Quran Hadis', 'IPA', ''),
(93, '1234567890 - Drs. ABAS SIMAN', 'Pendidikan Kewarganegaraan', 'IPS', ''),
(94, '1234567890 - MURSALIN, ST, S.Pd', 'Matematika', 'IPA', ''),
(95, '1234567890 - INSA ASYAROH, S.Ag', 'Ilmu Hadits', 'AGAMA', ''),
(96, '1234567890 - SITI MARIA ULFAH, S.Pd.I', 'Ilmu Hadits', 'AGAMA', ''),
(97, '1234567890 - Drs. ABAS SIMAN', 'Pendidikan Kewarganegaraan', 'AGAMA', ''),
(98, '1234567890 - MURSALIN, ST, S.Pd', 'Matematika', 'AGAMA', ''),
(99, '1234567890 - HANIM NURUL AINI, S.Pd.', 'Bahasa Indonesia', 'IPA', ''),
(100, '1234567890 - AGUS SALIM, S.Pd.', 'Bahasa Inggris', 'IPS', ''),
(101, '1234567890 - EDDI HARIYADI, S,Pd.', 'Seni Budaya', 'IPA', ''),
(102, '1234567890 - MARDWI ASDIYANTO, M.Pd.I.', 'Ilmu Tafsir', 'AGAMA', ''),
(103, '1234567890 - NASHRUL ULUM, S.Pd.', 'Sosiologi', 'IPS', ''),
(104, '1234567890 - UMAR FARUQ, S.Ag.', 'Ilmu Kalam', 'AGAMA', ''),
(105, '1234567890 - AGUS SALIM, S.Pd.', 'Bahasa Inggris', 'AGAMA', ''),
(106, '1234567890 - EDDI HARIYADI, S,Pd.', 'Seni Budaya', 'AGAMA', ''),
(107, '1234567890 - MARDWI ASDIYANTO, M.Pd.I.', 'S K I', 'IPS', ''),
(108, '1234567890 - NASHRUL ULUM, S.Pd.', 'S K I', 'IPS', ''),
(109, '1234567890 - MARDWI ASDIYANTO, M.Pd.I.', 'S K I', 'IPA', ''),
(110, '1234567890 - EDDI HARIYADI, S,Pd.', 'Seni Budaya', 'IPS', ''),
(111, '1234567890 - ALY FUADI, S.Pd.', 'Fisika', 'IPA', ''),
(112, '1234567890 - FATUKHA, S.Pd.', 'Matematika', 'IPS', ''),
(113, '1234567890 - MOHAMAD AFIF FARICHIN, M.Pd.I.', 'Muhadatsah', 'IPS', ''),
(114, '1234567890 - MOHAMAD AFIF FARICHIN, M.Pd.I.', 'Bahasa Arab', 'AGAMA', ''),
(115, '1234567890 - MOHAMAD AFIF FARICHIN, M.Pd.I.', 'Muhadatsah', 'IPA', ''),
(116, '1234567890 - MOHAMAD AFIF FARICHIN, M.Pd.I.', 'Muhadatsah', 'AGAMA', '');

-- --------------------------------------------------------

--
-- Struktur dari tabel `hari`
--

CREATE TABLE `hari` (
  `idhari` int(11) NOT NULL,
  `nama_hari` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `hari`
--

INSERT INTO `hari` (`idhari`, `nama_hari`) VALUES
(1, 'Senin'),
(2, 'Selasa'),
(3, 'Rabu'),
(4, 'Kamis'),
(5, 'Jumat');

-- --------------------------------------------------------

--
-- Struktur dari tabel `jadwal`
--

CREATE TABLE `jadwal` (
  `idjadwal` int(11) NOT NULL,
  `hari` varchar(200) NOT NULL,
  `idguru` varchar(200) NOT NULL,
  `idjam` varchar(200) NOT NULL,
  `idperiode` varchar(200) NOT NULL,
  `idkelas` varchar(255) NOT NULL,
  `idjur` varchar(255) NOT NULL,
  `id_vertex` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `jadwal`
--

INSERT INTO `jadwal` (`idjadwal`, `hari`, `idguru`, `idjam`, `idperiode`, `idkelas`, `idjur`, `id_vertex`) VALUES
(1, 'Senin', '1234567890 - Drs. YUDI SYAIFULLOH ( Pendidikan Jasmani, ORKES / IPA )', '1 ( 06:45:00 - 07:30:00 )', 'Ganjil 2017 / 2018', 'X-MIPA1', 'IPA', '1'),
(2, 'Senin', '1234567890 - Drs. YUDI SYAIFULLOH ( Pendidikan Jasmani, ORKES / IPA )', '2 ( 07:30:00 - 08:15:00 )', 'Ganjil 2016 / 2017', 'X-MIPA1', 'IPA', '1'),
(3, 'Senin', '1234567890 - SAYUDI, S. Pd. ( Bahasa Indonesia / IPA )', '3 ( 08:15:00 - 09:00:00 )', 'Ganjil 2016 / 2017', 'X-MIPA1', 'IPA', '2'),
(4, 'Senin', '1234567890 - SAYUDI, S. Pd. ( Bahasa Indonesia / IPA )', '4 ( 09:00:00 - 09:45:00 )', 'Ganjil 2016 / 2017', 'X-MIPA1', 'IPA', '2'),
(5, 'Senin', '1234567890 - SURAWAN, S.Pd. ( Bahasa Inggris / IPA )', '5 ( 10:05:00 - 10:50:00 )', 'Ganjil 2016 / 2017', 'X-MIPA1', 'IPA', '3'),
(6, 'Senin', '1234567890 - SURAWAN, S.Pd. ( Bahasa Inggris / IPA )', '6 ( 10:50:00 - 11:30:00 )', 'Ganjil 2016 / 2017', 'X-MIPA1', 'IPA', '3'),
(7, 'Senin', '1234567890 - Drs. ABD. SALAM HS. ( Fiqih / IPA )', '7 ( 12:30:00 - 13:15:00 )', 'Ganjil 2016 / 2017', 'X-MIPA1', 'IPA', '4'),
(8, 'Senin', '1234567890 - Drs. ABD. SALAM HS. ( Fiqih / IPA )', '8 ( 13:15:00 - 14:00:00 )', 'Ganjil 2016 / 2017', 'X-MIPA1', 'IPA', '4'),
(9, 'Senin', '1234567890 - INSA ASYAROH, S.Ag ( Al Quran Hadis / IPA )', '9 ( 14:00:00 - 14:45:00 )', 'Ganjil 2016 / 2017', 'X-MIPA1', 'IPA', '5'),
(10, 'Senin', '1234567890 - INSA ASYAROH, S.Ag ( Al Quran Hadis / IPA )', '10 ( 14:45:00 - 15:30:00 )', 'Ganjil 2016 / 2017', 'X-MIPA1', 'IPA', '5'),
(11, 'Selasa', '1234567890 - AHERI SUGIHARTONO, S.Th.I ( Aqidah Akhlak / IPA )', '1 ( 06:45:00 - 07:30:00 )', 'Ganjil 2016 / 2017', 'X-MIPA1', 'IPA', '6'),
(12, 'Selasa', '1234567890 - AHERI SUGIHARTONO, S.Th.I ( Aqidah Akhlak / IPA )', '2 ( 07:30:00 - 08:15:00 )', 'Ganjil 2016 / 2017', 'X-MIPA1', 'IPA', '6'),
(13, 'Selasa', '1234567890 - MARDWI ASDIYANTO, M.Pd.I. ( S K I / IPA )', '3 ( 08:15:00 - 09:00:00 )', 'Ganjil 2016 / 2017', 'X-MIPA1', 'IPA', '7'),
(14, 'Selasa', '1234567890 - MARDWI ASDIYANTO, M.Pd.I. ( S K I / IPA )', '4 ( 09:00:00 - 09:45:00 )', 'Ganjil 2016 / 2017', 'X-MIPA1', 'IPA', '7'),
(15, 'Selasa', '1234567890 - Drs. ABAS SIMAN ( Pendidikan Kewarganegaraan / IPA )', '5 ( 10:05:00 - 10:50:00 )', 'Ganjil 2016 / 2017', 'X-MIPA1', 'IPA', '8'),
(16, 'Selasa', '1234567890 - Drs. ABAS SIMAN ( Pendidikan Kewarganegaraan / IPA )', '6 ( 10:50:00 - 11:30:00 )', 'Ganjil 2016 / 2017', 'X-MIPA1', 'IPA', '8'),
(17, 'Selasa', '1234567890 - SAYUDI, S. Pd. ( Bahasa Indonesia / IPA )', '7 ( 12:30:00 - 13:15:00 )', 'Ganjil 2016 / 2017', 'X-MIPA1', 'IPA', '2'),
(18, 'Selasa', '1234567890 - SAYUDI, S. Pd. ( Bahasa Indonesia / IPA )', '8 ( 13:15:00 - 14:00:00 )', 'Ganjil 2016 / 2017', 'X-MIPA1', 'IPA', '2'),
(19, 'Selasa', '1234567890 - MUHAMMAD SUWAR, S.Pd.I. ( Bahasa Arab / IPA )', '9 ( 14:00:00 - 14:45:00 )', 'Ganjil 2016 / 2017', 'X-MIPA1', 'IPA', '9'),
(20, 'Selasa', '1234567890 - MUHAMMAD SUWAR, S.Pd.I. ( Bahasa Arab / IPA )', '10 ( 14:45:00 - 15:30:00 )', 'Ganjil 2016 / 2017', 'X-MIPA1', 'IPA', '9'),
(21, 'Rabu', '1234567890 - SURAWAN, S.Pd. ( Bahasa Inggris / IPA )', '1 ( 06:45:00 - 07:30:00 )', 'Ganjil 2016 / 2017', 'X-MIPA1', 'IPA', '3'),
(22, 'Rabu', '1234567890 - SURAWAN, S.Pd. ( Bahasa Inggris / IPA )', '2 ( 07:30:00 - 08:15:00 )', 'Ganjil 2016 / 2017', 'X-MIPA1', 'IPA', '3'),
(23, 'Rabu', '1234567890 - MURSALIN, ST, S.Pd ( Matematika / IPA )', '3 ( 08:15:00 - 09:00:00 )', 'Ganjil 2016 / 2017', 'X-MIPA1', 'IPA', '10'),
(24, 'Rabu', '1234567890 - MURSALIN, ST, S.Pd ( Matematika / IPA )', '4 ( 09:00:00 - 09:45:00 )', 'Ganjil 2016 / 2017', 'X-MIPA1', 'IPA', '10'),
(25, 'Rabu', '1234567890 - MARIFA RIAMA, S.Pd. ( Sejarah / IPA )', '5 ( 10:05:00 - 10:50:00 )', 'Ganjil 2016 / 2017', 'X-MIPA1', 'IPA', '11'),
(26, 'Rabu', '1234567890 - MARIFA RIAMA, S.Pd. ( Sejarah / IPA )', '6 ( 10:50:00 - 11:30:00 )', 'Ganjil 2016 / 2017', 'X-MIPA1', 'IPA', '11'),
(27, 'Rabu', '1234567890 - ARYS SUSANTO, M.Pd ( Fisika / IPA )', '7 ( 12:30:00 - 13:15:00 )', 'Ganjil 2016 / 2017', 'X-MIPA1', 'IPA', '12'),
(28, 'Rabu', '1234567890 - ARYS SUSANTO, M.Pd ( Fisika / IPA )', '8 ( 13:15:00 - 14:00:00 )', 'Ganjil 2016 / 2017', 'X-MIPA1', 'IPA', '12'),
(29, 'Rabu', '1234567890 - SURAWAN, S.Pd. ( Kimia / IPA )', '9 ( 14:00:00 - 14:45:00 )', 'Ganjil 2016 / 2017', 'X-MIPA1', 'IPA', '3'),
(30, 'Rabu', '1234567890 - SURAWAN, S.Pd. ( Kimia / IPA )', '10 ( 14:45:00 - 15:30:00 )', 'Ganjil 2016 / 2017', 'X-MIPA1', 'IPA', '3'),
(31, 'Kamis', '1234567890 - MOCH. FARID WADJIDI Lc, S.Pd. ( Biologi / IPA )', '1 ( 06:45:00 - 07:30:00 )', 'Ganjil 2016 / 2017', 'X-MIPA1', 'IPA', '14'),
(32, 'Kamis', '1234567890 - MOCH. FARID WADJIDI Lc, S.Pd. ( Biologi / IPA )', '2 ( 07:30:00 - 08:15:00 )', 'Ganjil 2016 / 2017', 'X-MIPA1', 'IPA', '14'),
(33, 'Kamis', '1234567890 - Drs. ALI MUSTOFA, M.Pd ( Geografi / IPA )', '3 ( 08:15:00 - 09:00:00 )', 'Ganjil 2016 / 2017', 'X-MIPA1', 'IPA', '15'),
(34, 'Kamis', '1234567890 - Drs. ALI MUSTOFA, M.Pd ( Geografi / IPA )', '4 ( 09:00:00 - 09:45:00 )', 'Ganjil 2016 / 2017', 'X-MIPA1', 'IPA', '15'),
(35, 'Kamis', '1234567890 - TRI SUDIK WIYONO, S.Pd ( Ekonomi / IPA )', '5 ( 10:05:00 - 10:50:00 )', 'Ganjil 2016 / 2017', 'X-MIPA1', 'IPA', '16'),
(36, 'Kamis', '1234567890 - TRI SUDIK WIYONO, S.Pd ( Ekonomi / IPA )', '6 ( 10:50:00 - 11:30:00 )', 'Ganjil 2016 / 2017', 'X-MIPA1', 'IPA', '16'),
(37, 'Kamis', '1234567890 - YAYUK ISWATIN, S.Pd ( Seni Budaya / IPA )', '7 ( 12:30:00 - 13:15:00 )', 'Ganjil 2016 / 2017', 'X-MIPA1', 'IPA', '17'),
(38, 'Kamis', '1234567890 - YAYUK ISWATIN, S.Pd ( Seni Budaya / IPA )', '8 ( 13:15:00 - 14:00:00 )', 'Ganjil 2016 / 2017', 'X-MIPA1', 'IPS', '17'),
(39, 'Kamis', '1234567890 - MURSALIN, ST, S.Pd ( Matematika / IPA )', '9 ( 14:00:00 - 14:45:00 )', 'Ganjil 2016 / 2017', 'X-MIPA1', 'IPA', '10'),
(40, 'Kamis', '1234567890 - MURSALIN, ST, S.Pd ( Matematika / IPA )', '10 ( 14:45:00 - 15:30:00 )', 'Ganjil 2016 / 2017', 'X-MIPA1', 'IPA', '10'),
(41, 'Jumat', '1234567890 - MOCH. FARID WADJIDI Lc, S.Pd. ( Biologi / IPA )', '1 ( 06:45:00 - 07:30:00 )', 'Ganjil 2016 / 2017', 'X-MIPA1', 'IPA', '18'),
(42, 'Jumat', '1234567890 - MOCH. FARID WADJIDI Lc, S.Pd. ( Biologi / IPA )', '2 ( 07:30:00 - 08:15:00 )', 'Ganjil 2016 / 2017', 'X-MIPA1', 'IPA', '18'),
(43, 'Jumat', '1234567890 - NUR JANAH, S.Pd ( Keterampilan / IPA )', '3 ( 08:15:00 - 09:00:00 )', 'Ganjil 2016 / 2017', 'X-MIPA1', 'IPA', '19'),
(44, 'Jumat', '1234567890 - NUR JANAH, S.Pd ( Keterampilan / IPA )', '4 ( 09:00:00 - 09:45:00 )', 'Ganjil 2016 / 2017', 'X-MIPA1', 'IPA', '19'),
(45, 'Jumat', '1234567890 - NENI SUHARTINI, S.Pd, M.Psi ( BK / IPA )', '5 ( 10:05:00 - 10:50:00 )', 'Ganjil 2016 / 2017', 'X-MIPA1', 'IPA', '20'),
(46, 'Jumat', '1234567890 - NENI SUHARTINI, S.Pd, M.Psi ( BK / IPA )', '6 ( 10:50:00 - 11:30:00 )', 'Ganjil 2016 / 2017', 'X-MIPA1', 'IPA', '20'),
(47, 'Jumat', '1234567890 - MOHAMAD AFIF FARICHIN, M.Pd.I. ( Muhadatsah / IPA )', '7 ( 12:30:00 - 13:15:00 )', 'Ganjil 2016 / 2017', 'X-MIPA1', 'IPA', '13'),
(48, 'Jumat', '1234567890 - MOHAMAD AFIF FARICHIN, M.Pd.I. ( Muhadatsah / IPA )', '8 ( 13:15:00 - 14:00:00 )', 'Ganjil 2016 / 2017', 'X-MIPA1', 'IPA', '13'),
(49, 'Senin', '1234567890 - MOCH. FARID WADJIDI Lc, S.Pd. ( Biologi / IPA )', '1 ( 06:45:00 - 07:30:00 )', 'Ganjil 2016 / 2017', 'X-MIPA2', 'IPA', '18'),
(50, 'Senin', '1234567890 - MOCH. FARID WADJIDI Lc, S.Pd. ( Biologi / IPA )', '2 ( 07:30:00 - 08:15:00 )', 'Ganjil 2016 / 2017', 'X-MIPA2', 'IPA', '18'),
(51, 'Senin', '1234567890 - ARYS SUSANTO, M.Pd ( Fisika / IPA )', '3 ( 08:15:00 - 09:00:00 )', 'Ganjil 2016 / 2017', 'X-MIPA2', 'IPA', '12'),
(52, 'Senin', '1234567890 - ARYS SUSANTO, M.Pd ( Fisika / IPA )', '4 ( 09:00:00 - 09:45:00 )', 'Ganjil 2016 / 2017', 'X-MIPA2', 'IPA', '12'),
(53, 'Senin', '1234567890 - SURAWAN, S.Pd. ( Kimia / IPA )', '5 ( 10:05:00 - 10:50:00 )', 'Ganjil 2016 / 2017', 'X-MIPA2', 'IPA', '3'),
(54, 'Senin', '1234567890 - SURAWAN, S.Pd. ( Kimia / IPA )', '6 ( 10:50:00 - 11:30:00 )', 'Ganjil 2016 / 2017', 'X-MIPA2', 'IPA', '3'),
(55, 'Senin', '1234567890 - MOHAMAD AFIF FARICHIN, M.Pd.I. ( Muhadatsah / IPA )', '7 ( 12:30:00 - 13:15:00 )', 'Ganjil 2016 / 2017', 'X-MIPA2', 'IPA', '13'),
(56, 'Senin', '1234567890 - MOHAMAD AFIF FARICHIN, M.Pd.I. ( Muhadatsah / IPA )', '8 ( 13:15:00 - 14:00:00 )', 'Ganjil 2016 / 2017', 'X-MIPA2', 'IPA', '13'),
(57, 'Senin', '1234567890 - NENI SUHARTINI, S.Pd, M.Psi ( BK / IPA )', '9 ( 14:00:00 - 14:45:00 )', 'Ganjil 2017 / 2018', 'X-MIPA2', 'IPA', '20'),
(58, 'Senin', '1234567890 - NENI SUHARTINI, S.Pd, M.Psi ( BK / IPA )', '10 ( 14:45:00 - 15:30:00 )', 'Ganjil 2017 / 2018', 'X-MIPA2', 'IPA', '20'),
(59, 'Selasa', '1234567890 - MOCH. FARID WADJIDI Lc, S.Pd. ( Biologi / IPA )', '1 ( 06:45:00 - 07:30:00 )', 'Ganjil 2017 / 2018', 'X-MIPA2', 'IPA', '18'),
(60, 'Selasa', '1234567890 - MOCH. FARID WADJIDI Lc, S.Pd. ( Biologi / IPA )', '2 ( 07:30:00 - 08:15:00 )', 'Ganjil 2017 / 2018', 'X-MIPA2', 'IPA', '18'),
(61, 'Selasa', '1234567890 - MURSALIN, ST, S.Pd ( Matematika / IPA )', '3 ( 08:15:00 - 09:00:00 )', 'Ganjil 2017 / 2018', 'X-MIPA2', 'IPA', '10'),
(62, 'Selasa', '1234567890 - MURSALIN, ST, S.Pd ( Matematika / IPA )', '4 ( 09:00:00 - 09:45:00 )', 'Ganjil 2017 / 2018', 'X-MIPA2', 'IPA', '10'),
(63, 'Selasa', '1234567890 - Drs. YUDI SYAIFULLOH ( Pendidikan Jasmani, ORKES / IPA )', '5 ( 10:05:00 - 10:50:00 )', 'Ganjil 2017 / 2018', 'X-MIPA2', 'IPA', '1'),
(64, 'Selasa', '1234567890 - Drs. YUDI SYAIFULLOH ( Pendidikan Jasmani, ORKES / IPA )', '6 ( 10:50:00 - 11:30:00 )', 'Ganjil 2017 / 2018', 'X-MIPA2', 'IPA', '1'),
(65, 'Selasa', '1234567890 - YAYUK ISWATIN, S.Pd ( Seni Budaya / IPA )', '7 ( 12:30:00 - 13:15:00 )', 'Ganjil 2017 / 2018', 'X-MIPA2', 'IPA', '17'),
(66, 'Selasa', '1234567890 - YAYUK ISWATIN, S.Pd ( Seni Budaya / IPA )', '8 ( 13:15:00 - 14:00:00 )', 'Ganjil 2017 / 2018', 'X-MIPA2', 'IPA', '17'),
(67, 'Selasa', '1234567890 - TRI SUDIK WIYONO, S.Pd ( Ekonomi / IPA )', '9 ( 14:00:00 - 14:45:00 )', 'Ganjil 2017 / 2018', 'X-MIPA2', 'IPA', '16'),
(68, 'Selasa', '1234567890 - TRI SUDIK WIYONO, S.Pd ( Ekonomi / IPA )', '10 ( 14:45:00 - 15:30:00 )', 'Ganjil 2017 / 2018', 'X-MIPA2', 'IPA', '16'),
(69, 'Rabu', '1234567890 - Drs. ALI MUSTOFA, M.Pd ( Geografi / IPA )', '1 ( 06:45:00 - 07:30:00 )', 'Ganjil 2017 / 2018', 'X-MIPA2', 'IPA', '15'),
(70, 'Rabu', '1234567890 - Drs. ALI MUSTOFA, M.Pd ( Geografi / IPA )', '2 ( 07:30:00 - 08:15:00 )', 'Ganjil 2017 / 2018', 'X-MIPA2', 'IPA', '15'),
(71, 'Rabu', '1234567890 - MOCH. FARID WADJIDI Lc, S.Pd. ( Biologi / IPA )', '3 ( 08:15:00 - 09:00:00 )', 'Ganjil 2017 / 2018', 'X-MIPA2', 'IPA', '18'),
(72, 'Rabu', '1234567890 - MOCH. FARID WADJIDI Lc, S.Pd. ( Biologi / IPA )', '4 ( 09:00:00 - 09:45:00 )', 'Ganjil 2017 / 2018', 'X-MIPA2', 'IPA', '18'),
(73, 'Rabu', '1234567890 - SURAWAN, S.Pd. ( Kimia / IPA )', '5 ( 10:05:00 - 10:50:00 )', 'Ganjil 2017 / 2018', 'X-MIPA2', 'IPA', '3'),
(74, 'Rabu', '1234567890 - SURAWAN, S.Pd. ( Kimia / IPA )', '6 ( 10:50:00 - 11:30:00 )', 'Ganjil 2017 / 2018', 'X-MIPA2', 'IPA', '3'),
(75, 'Rabu', '1234567890 - SURAWAN, S.Pd. ( Bahasa Inggris / IPA )', '7 ( 12:30:00 - 13:15:00 )', 'Ganjil 2017 / 2018', 'X-MIPA2', 'IPA', '3'),
(76, 'Rabu', '1234567890 - SURAWAN, S.Pd. ( Bahasa Inggris / IPA )', '8 ( 13:15:00 - 14:00:00 )', 'Ganjil 2017 / 2018', 'X-MIPA2', 'IPA', '3'),
(77, 'Rabu', '1234567890 - MARIFA RIAMA, S.Pd. ( Sejarah / IPA )', '9 ( 14:00:00 - 14:45:00 )', 'Ganjil 2017 / 2018', 'X-MIPA2', 'IPA', '11'),
(78, 'Rabu', '1234567890 - MARIFA RIAMA, S.Pd. ( Sejarah / IPA )', '10 ( 14:45:00 - 15:30:00 )', 'Ganjil 2017 / 2018', 'X-MIPA2', 'IPA', '11'),
(79, 'Kamis', '1234567890 - MURSALIN, ST, S.Pd ( Matematika / IPA )', '1 ( 06:45:00 - 07:30:00 )', 'Ganjil 2017 / 2018', 'X-MIPA2', 'IPA', '10'),
(80, 'Kamis', '1234567890 - MURSALIN, ST, S.Pd ( Matematika / IPA )', '2 ( 07:30:00 - 08:15:00 )', 'Ganjil 2017 / 2018', 'X-MIPA2', 'IPA', '10'),
(81, 'Kamis', '1234567890 - SURAWAN, S.Pd. ( Bahasa Inggris / IPA )', '3 ( 08:15:00 - 09:00:00 )', 'Ganjil 2017 / 2018', 'X-MIPA2', 'IPA', '3'),
(82, 'Kamis', '1234567890 - SURAWAN, S.Pd. ( Bahasa Inggris / IPA )', '4 ( 09:00:00 - 09:45:00 )', 'Ganjil 2017 / 2018', 'X-MIPA2', 'IPA', '3'),
(83, 'Kamis', '1234567890 - MUHAMMAD SUWAR, S.Pd.I. ( Bahasa Arab / IPA )', '5 ( 10:05:00 - 10:50:00 )', 'Ganjil 2017 / 2018', 'X-MIPA2', 'IPA', '9'),
(84, 'Kamis', '1234567890 - MUHAMMAD SUWAR, S.Pd.I. ( Bahasa Arab / IPA )', '6 ( 10:50:00 - 11:30:00 )', 'Ganjil 2017 / 2018', 'X-MIPA2', 'IPA', '9'),
(85, 'Kamis', '1234567890 - SAYUDI, S. Pd. ( Bahasa Indonesia / IPA )', '7 ( 12:30:00 - 13:15:00 )', 'Ganjil 2017 / 2018', 'X-MIPA2', 'IPA', '2'),
(86, 'Kamis', '1234567890 - SAYUDI, S. Pd. ( Bahasa Indonesia / IPA )', '8 ( 13:15:00 - 14:00:00 )', 'Ganjil 2017 / 2018', 'X-MIPA2', 'IPA', '2'),
(87, 'Kamis', '1234567890 - Drs. ABAS SIMAN ( Pendidikan Kewarganegaraan / IPA )', '9 ( 14:00:00 - 14:45:00 )', 'Ganjil 2017 / 2018', 'X-MIPA2', 'IPA', '8'),
(88, 'Kamis', '1234567890 - Drs. ABAS SIMAN ( Pendidikan Kewarganegaraan / IPA )', '10 ( 14:45:00 - 15:30:00 )', 'Ganjil 2017 / 2018', 'X-MIPA2', 'IPA', '8'),
(89, 'Jumat', '1234567890 - MARDWI ASDIYANTO, M.Pd.I. ( S K I / IPA )', '1 ( 06:45:00 - 07:30:00 )', 'Ganjil 2017 / 2018', 'X-MIPA2', 'IPA', '7'),
(90, 'Jumat', '1234567890 - MARDWI ASDIYANTO, M.Pd.I. ( S K I / IPA )', '2 ( 07:30:00 - 08:15:00 )', 'Ganjil 2017 / 2018', 'X-MIPA2', 'IPA', '7'),
(91, 'Jumat', '1234567890 - AHERI SUGIHARTONO, S.Th.I ( Aqidah Akhlak / IPA )', '3 ( 08:15:00 - 09:00:00 )', 'Ganjil 2017 / 2018', 'X-MIPA2', 'IPA', '6'),
(92, 'Jumat', '1234567890 - AHERI SUGIHARTONO, S.Th.I ( Aqidah Akhlak / IPA )', '4 ( 09:00:00 - 09:45:00 )', 'Ganjil 2017 / 2018', 'X-MIPA2', 'IPA', '6'),
(93, 'Jumat', '1234567890 - INSA ASYAROH, S.Ag ( Al Quran Hadis / IPA )', '5 ( 10:05:00 - 10:50:00 )', 'Ganjil 2017 / 2018', 'X-MIPA2', 'IPA', '5'),
(94, 'Jumat', '1234567890 - INSA ASYAROH, S.Ag ( Al Quran Hadis / IPA )', '6 ( 10:50:00 - 11:30:00 )', 'Ganjil 2017 / 2018', 'X-MIPA2', 'IPA', '5'),
(95, 'Jumat', '1234567890 - Drs. ABD. SALAM HS. ( Fiqih / IPA )', '7 ( 12:30:00 - 13:15:00 )', 'Ganjil 2017 / 2018', 'X-MIPA2', 'IPA', '4'),
(96, 'Jumat', '1234567890 - Drs. ABD. SALAM HS. ( Fiqih / IPA )', '8 ( 13:15:00 - 14:00:00 )', 'Ganjil 2017 / 2018', 'X-MIPA2', 'IPA', '4'),
(97, 'Senin', '1234567890 - Drs. ABD. SALAM HS. ( Fiqih / IPA )', '1 ( 06:45:00 - 07:30:00 )', 'Ganjil 2017 / 2018', 'X-MIPA3', 'IPA', '4'),
(98, 'Senin', '1234567890 - Drs. ABD. SALAM HS. ( Fiqih / IPA )', '2 ( 07:30:00 - 08:15:00 )', 'Ganjil 2017 / 2018', 'X-MIPA3', 'IPA', '4'),
(99, 'Senin', '1234567890 - INSA ASYAROH, S.Ag ( Al Quran Hadis / IPA )', '3 ( 08:15:00 - 09:00:00 )', 'Ganjil 2017 / 2018', 'X-MIPA3', 'IPA', '5'),
(100, 'Senin', '1234567890 - INSA ASYAROH, S.Ag ( Al Quran Hadis / IPA )', '4 ( 09:00:00 - 09:45:00 )', 'Ganjil 2017 / 2018', 'X-MIPA3', 'IPA', '5'),
(101, 'Senin', '1234567890 - ARYS SUSANTO, M.Pd ( Fisika / IPA )', '5 ( 10:05:00 - 10:50:00 )', 'Ganjil 2017 / 2018', 'X-MIPA3', 'IPA', '12'),
(102, 'Senin', '1234567890 - ARYS SUSANTO, M.Pd ( Fisika / IPA )', '6 ( 10:50:00 - 11:30:00 )', 'Ganjil 2017 / 2018', 'X-MIPA3', 'IPA', '12'),
(103, 'Senin', '1234567890 - SURAWAN, S.Pd. ( Kimia / IPA )', '7 ( 12:30:00 - 13:15:00 )', 'Ganjil 2017 / 2018', 'X-MIPA3', 'IPA', '3'),
(104, 'Senin', '1234567890 - SURAWAN, S.Pd. ( Kimia / IPA )', '8 ( 13:15:00 - 14:00:00 )', 'Ganjil 2017 / 2018', 'X-MIPA3', 'IPA', '3'),
(105, 'Senin', '1234567890 - MOHAMAD AFIF FARICHIN, M.Pd.I. ( Muhadatsah / IPA )', '9 ( 14:00:00 - 14:45:00 )', 'Ganjil 2017 / 2018', 'X-MIPA3', 'IPA', '13'),
(106, 'Senin', '1234567890 - MOHAMAD AFIF FARICHIN, M.Pd.I. ( Muhadatsah / IPA )', '10 ( 14:45:00 - 15:30:00 )', 'Ganjil 2017 / 2018', 'X-MIPA3', 'IPA', '13'),
(107, 'Selasa', '1234567890 - MOCH. FARID WADJIDI Lc, S.Pd. ( Biologi / IPA )', '1 ( 06:45:00 - 07:30:00 )', 'Ganjil 2017 / 2018', 'X-MIPA3', 'IPA', '14'),
(108, 'Selasa', '1234567890 - MOCH. FARID WADJIDI Lc, S.Pd. ( Biologi / IPA )', '2 ( 07:30:00 - 08:15:00 )', 'Ganjil 2017 / 2018', 'X-MIPA3', 'IPA', '14'),
(109, 'Selasa', '1234567890 - NENI SUHARTINI, S.Pd, M.Psi ( BK / IPA )', '3 ( 08:15:00 - 09:00:00 )', 'Ganjil 2017 / 2018', 'X-MIPA3', 'IPA', '20'),
(110, 'Selasa', '1234567890 - NENI SUHARTINI, S.Pd, M.Psi ( BK / IPA )', '4 ( 09:00:00 - 09:45:00 )', 'Ganjil 2017 / 2018', 'X-MIPA3', 'IPA', '20'),
(111, 'Selasa', '1234567890 - NUR JANAH, S.Pd ( Keterampilan / IPA )', '5 ( 10:05:00 - 10:50:00 )', 'Ganjil 2017 / 2018', 'X-MIPA3', 'IPA', '19'),
(112, 'Selasa', '1234567890 - NUR JANAH, S.Pd ( Keterampilan / IPA )', '6 ( 10:50:00 - 11:30:00 )', 'Ganjil 2017 / 2018', 'X-MIPA3', 'IPA', '19'),
(113, 'Selasa', '1234567890 - Drs. ALI MUSTOFA, M.Pd ( Geografi / IPA )', '7 ( 12:30:00 - 13:15:00 )', 'Ganjil 2017 / 2018', 'X-MIPA3', 'IPA', '15'),
(114, 'Selasa', '1234567890 - Drs. ALI MUSTOFA, M.Pd ( Geografi / IPA )', '8 ( 13:15:00 - 14:00:00 )', 'Ganjil 2017 / 2018', 'X-MIPA3', 'IPA', '15'),
(115, 'Selasa', '1234567890 - YAYUK ISWATIN, S.Pd ( Seni Budaya / IPA )', '9 ( 14:00:00 - 14:45:00 )', 'Ganjil 2017 / 2018', 'X-MIPA3', 'IPA', '17'),
(116, 'Selasa', '1234567890 - YAYUK ISWATIN, S.Pd ( Seni Budaya / IPA )', '10 ( 14:45:00 - 15:30:00 )', 'Ganjil 2017 / 2018', 'X-MIPA3', 'IPA', '17'),
(117, 'Rabu', '1234567890 - TRI SUDIK WIYONO, S.Pd ( Ekonomi / IPA )', '1 ( 06:45:00 - 07:30:00 )', 'Ganjil 2017 / 2018', 'X-MIPA3', 'IPA', '16'),
(118, 'Rabu', '1234567890 - TRI SUDIK WIYONO, S.Pd ( Ekonomi / IPA )', '2 ( 07:30:00 - 08:15:00 )', 'Ganjil 2017 / 2018', 'X-MIPA3', 'IPA', '16'),
(119, 'Rabu', '1234567890 - SURAWAN, S.Pd. ( Kimia / IPA )', '3 ( 08:15:00 - 09:00:00 )', 'Ganjil 2017 / 2018', 'X-MIPA3', 'IPA', '3'),
(120, 'Rabu', '1234567890 - SURAWAN, S.Pd. ( Kimia / IPA )', '4 ( 09:00:00 - 09:45:00 )', 'Ganjil 2017 / 2018', 'X-MIPA3', 'IPA', '3'),
(121, 'Rabu', '1234567890 - MOCH. FARID WADJIDI Lc, S.Pd. ( Biologi / IPA )', '5 ( 10:05:00 - 10:50:00 )', 'Ganjil 2017 / 2018', 'X-MIPA3', 'IPA', '14'),
(122, 'Rabu', '1234567890 - MOCH. FARID WADJIDI Lc, S.Pd. ( Biologi / IPA )', '6 ( 10:50:00 - 11:30:00 )', 'Ganjil 2017 / 2018', 'X-MIPA3', 'IPA', '14'),
(123, 'Rabu', '1234567890 - Drs. ABD. SALAM HS. ( Fiqih / IPA )', '7 ( 12:30:00 - 13:15:00 )', 'Ganjil 2017 / 2018', 'X-MIPA3', 'IPA', '4'),
(124, 'Rabu', '1234567890 - Drs. ABD. SALAM HS. ( Fiqih / IPA )', '8 ( 13:15:00 - 14:00:00 )', 'Ganjil 2017 / 2018', 'X-MIPA3', 'IPA', '4'),
(125, 'Rabu', '1234567890 - AHERI SUGIHARTONO, S.Th.I ( Aqidah Akhlak / IPA )', '9 ( 14:00:00 - 14:45:00 )', 'Ganjil 2017 / 2018', 'X-MIPA3', 'IPA', '6'),
(126, 'Rabu', '1234567890 - AHERI SUGIHARTONO, S.Th.I ( Aqidah Akhlak / IPA )', '10 ( 14:45:00 - 15:30:00 )', 'Ganjil 2017 / 2018', 'X-MIPA3', 'IPA', '6'),
(127, 'Kamis', '1234567890 - Drs. YUDI SYAIFULLOH ( Pendidikan Jasmani, ORKES / IPA )', '1 ( 06:45:00 - 07:30:00 )', 'Ganjil 2017 / 2018', 'X-MIPA3', 'IPA', '1'),
(128, 'Kamis', '1234567890 - Drs. YUDI SYAIFULLOH ( Pendidikan Jasmani, ORKES / IPA )', '2 ( 07:30:00 - 08:15:00 )', 'Ganjil 2017 / 2018', 'X-MIPA3', 'IPA', '1'),
(129, 'Kamis', '1234567890 - MARDWI ASDIYANTO, M.Pd.I. ( S K I / IPA )', '3 ( 08:15:00 - 09:00:00 )', 'Ganjil 2017 / 2018', 'X-MIPA3', 'IPA', '7'),
(130, 'Kamis', '1234567890 - MARDWI ASDIYANTO, M.Pd.I. ( S K I / IPA )', '4 ( 09:00:00 - 09:45:00 )', 'Ganjil 2017 / 2018', 'X-MIPA3', 'IPA', '7'),
(131, 'Kamis', '1234567890 - SAYUDI, S. Pd. ( Bahasa Indonesia / IPA )', '5 ( 10:05:00 - 10:50:00 )', 'Ganjil 2017 / 2018', 'X-MIPA3', 'IPA', '2'),
(132, 'Kamis', '1234567890 - SAYUDI, S. Pd. ( Bahasa Indonesia / IPA )', '6 ( 10:50:00 - 11:30:00 )', 'Ganjil 2017 / 2018', 'X-MIPA3', 'IPA', '2'),
(133, 'Kamis', '1234567890 - Drs. ABAS SIMAN ( Pendidikan Kewarganegaraan / IPA )', '7 ( 12:30:00 - 13:15:00 )', 'Ganjil 2017 / 2018', 'X-MIPA3', 'IPA', '8'),
(134, 'Kamis', '1234567890 - Drs. ABAS SIMAN ( Pendidikan Kewarganegaraan / IPA )', '8 ( 13:15:00 - 14:00:00 )', 'Ganjil 2017 / 2018', 'X-MIPA3', 'IPA', '8'),
(135, 'Kamis', '1234567890 - MUHAMMAD SUWAR, S.Pd.I. ( Bahasa Arab / IPA )', '9 ( 14:00:00 - 14:45:00 )', 'Ganjil 2017 / 2018', 'X-MIPA3', 'IPA', '9'),
(136, 'Kamis', '1234567890 - MUHAMMAD SUWAR, S.Pd.I. ( Bahasa Arab / IPA )', '10 ( 14:45:00 - 15:30:00 )', 'Ganjil 2017 / 2018', 'X-MIPA3', 'IPA', '9'),
(137, 'Jumat', '1234567890 - MARDWI ASDIYANTO, M.Pd.I. ( S K I / IPA )', '1 ( 06:45:00 - 07:30:00 )', 'Ganjil 2017 / 2018', 'X-MIPA3', 'IPA', '7'),
(138, 'Jumat', '1234567890 - MARDWI ASDIYANTO, M.Pd.I. ( S K I / IPA )', '2 ( 07:30:00 - 08:15:00 )', 'Ganjil 2017 / 2018', 'X-MIPA3', 'IPA', '7'),
(139, 'Jumat', '1234567890 - MURSALIN, ST, S.Pd ( Matematika / IPA )', '3 ( 08:15:00 - 09:00:00 )', 'Ganjil 2017 / 2018', 'X-MIPA3', 'IPA', '10'),
(140, 'Jumat', '1234567890 - MURSALIN, ST, S.Pd ( Matematika / IPA )', '4 ( 09:00:00 - 09:45:00 )', 'Ganjil 2017 / 2018', 'X-MIPA3', 'IPA', '10'),
(141, 'Jumat', '1234567890 - MARIFA RIAMA, S.Pd. ( Sejarah / IPA )', '5 ( 10:05:00 - 10:50:00 )', 'Ganjil 2017 / 2018', 'X-MIPA3', 'IPA', '11'),
(142, 'Jumat', '1234567890 - MARIFA RIAMA, S.Pd. ( Sejarah / IPA )', '6 ( 10:50:00 - 11:30:00 )', 'Ganjil 2017 / 2018', 'X-MIPA3', 'IPA', '11'),
(143, 'Jumat', '1234567890 - ARYS SUSANTO, M.Pd ( Fisika / IPA )', '7 ( 12:30:00 - 13:15:00 )', 'Ganjil 2017 / 2018', 'X-MIPA3', 'IPA', '12'),
(144, 'Jumat', '1234567890 - ARYS SUSANTO, M.Pd ( Fisika / IPA )', '8 ( 13:15:00 - 14:00:00 )', 'Ganjil 2017 / 2018', 'X-MIPA3', 'IPA', '12'),
(145, 'Senin', '1234567890 - Dra. SUWINARTI ( Geografi / IPS )', '1 ( 06:45:00 - 07:30:00 )', 'Ganjil 2017 / 2018', 'X-IPS1', 'IPS', '21'),
(146, 'Senin', '1234567890 - Dra. SUWINARTI ( Geografi / IPS )', '2 ( 07:30:00 - 08:15:00 )', 'Ganjil 2017 / 2018', 'X-IPS1', 'IPS', '21'),
(147, 'Senin', '1234567890 - Drs. YUDI SYAIFULLOH ( Pendidikan Jasmani, ORKES / IPS )', '3 ( 08:15:00 - 09:00:00 )', 'Ganjil 2017 / 2018', 'X-IPS1', 'IPS', '1'),
(148, 'Senin', '1234567890 - Drs. YUDI SYAIFULLOH ( Pendidikan Jasmani, ORKES / IPS )', '4 ( 09:00:00 - 09:45:00 )', 'Ganjil 2017 / 2018', 'X-IPS1', 'IPS', '1'),
(149, 'Senin', '1234567890 - MARIFA RIAMA, S.Pd. ( Sejarah / IPS )', '5 ( 10:05:00 - 10:50:00 )', 'Ganjil 2017 / 2018', 'X-IPS1', 'IPS', '11'),
(150, 'Senin', '1234567890 - MARIFA RIAMA, S.Pd. ( Sejarah / IPS )', '6 ( 10:50:00 - 11:30:00 )', 'Ganjil 2017 / 2018', 'X-IPS1', 'IPS', '11'),
(151, 'Senin', '1234567890 - MOHAMAD AFIF FARICHIN, M.Pd.I. ( Muhadatsah / IPS )', '7 ( 12:30:00 - 13:15:00 )', 'Ganjil 2017 / 2018', 'X-IPS1', 'IPS', '13'),
(152, 'Senin', '1234567890 - MOHAMAD AFIF FARICHIN, M.Pd.I. ( Muhadatsah / IPS )', '8 ( 13:15:00 - 14:00:00 )', 'Ganjil 2017 / 2018', 'X-IPS1', 'IPS', '13'),
(153, 'Senin', '1234567890 - SURAWAN, S.Pd. ( Bahasa Inggris / IPS )', '9 ( 14:00:00 - 14:45:00 )', 'Ganjil 2017 / 2018', 'X-IPS1', 'IPS', '3'),
(154, 'Senin', '1234567890 - SURAWAN, S.Pd. ( Bahasa Inggris / IPS )', '10 ( 14:45:00 - 15:30:00 )', 'Ganjil 2017 / 2018', 'X-IPS1', 'IPS', '3'),
(155, 'Selasa', '1234567890 - ISMI MARIYAM, S.Pd. ( Bhs & Sastra Ind / IPS )', '1 ( 06:45:00 - 07:30:00 )', 'Ganjil 2017 / 2018', 'X-IPS1', 'IPS', '22'),
(156, 'Selasa', '1234567890 - ISMI MARIYAM, S.Pd. ( Bhs & Sastra Ind / IPS )', '2 ( 07:30:00 - 08:15:00 )', 'Ganjil 2017 / 2018', 'X-IPS1', 'IPS', '22'),
(157, 'Selasa', '1234567890 - HADIAH, S.Pd. ( Ekonomi / IPS )', '3 ( 08:15:00 - 09:00:00 )', 'Ganjil 2017 / 2018', 'X-IPS1', 'IPA', '23'),
(158, 'Selasa', '1234567890 - HADIAH, S.Pd. ( Ekonomi / IPS )', '4 ( 09:00:00 - 09:45:00 )', 'Ganjil 2017 / 2018', 'X-IPS1', 'IPA', '23'),
(159, 'Selasa', '1234567890 - USMAN, S.Pd. ( Bahasa Indonesia / IPS )', '5 ( 10:05:00 - 10:50:00 )', 'Ganjil 2017 / 2018', 'X-IPS1', 'IPS', '24'),
(160, 'Selasa', '1234567890 - USMAN, S.Pd. ( Bahasa Indonesia / IPS )', '6 ( 10:50:00 - 11:30:00 )', 'Ganjil 2017 / 2018', 'X-IPS1', 'IPS', '24'),
(161, 'Selasa', '1234567890 - TEGUH KOESTANTININGSIH, S.Pd ( Keterampilan / IPS )', '7 ( 12:30:00 - 13:15:00 )', 'Ganjil 2017 / 2018', 'X-IPS1', 'IPS', '25'),
(162, 'Selasa', '1234567890 - TEGUH KOESTANTININGSIH, S.Pd ( Keterampilan / IPS )', '8 ( 13:15:00 - 14:00:00 )', 'Ganjil 2017 / 2018', 'X-IPS1', 'IPS', '25'),
(163, 'Selasa', '1234567890 - YAYUK ISWATIN, S.Pd ( Seni Budaya / IPS )', '9 ( 14:00:00 - 14:45:00 )', 'Ganjil 2017 / 2018', 'X-IPS1', 'IPS', '17'),
(164, 'Selasa', '1234567890 - YAYUK ISWATIN, S.Pd ( Seni Budaya / IPS )', '10 ( 14:45:00 - 15:30:00 )', 'Ganjil 2017 / 2018', 'X-IPS1', 'IPS', '17'),
(165, 'Rabu', '1234567890 - NASHRUL ULUM, S.Pd. ( Sosiologi / IPS )', '1 ( 06:45:00 - 07:30:00 )', 'Ganjil 2017 / 2018', 'X-IPS1', 'IPS', '26'),
(166, 'Rabu', '1234567890 - NASHRUL ULUM, S.Pd. ( Sosiologi / IPS )', '2 ( 07:30:00 - 08:15:00 )', 'Ganjil 2017 / 2018', 'X-IPS1', 'IPS', '26'),
(167, 'Rabu', '1234567890 - NENI SUHARTINI, S.Pd, M.Psi ( BK / IPS )', '3 ( 08:15:00 - 09:00:00 )', 'Ganjil 2017 / 2018', 'X-IPS1', 'IPS', '20'),
(168, 'Rabu', '1234567890 - NENI SUHARTINI, S.Pd, M.Psi ( BK / IPS )', '4 ( 09:00:00 - 09:45:00 )', 'Ganjil 2017 / 2018', 'X-IPS1', 'IPS', '20'),
(169, 'Rabu', '1234567890 - Dra. SUWINARTI ( Geografi / IPS )', '5 ( 10:05:00 - 10:50:00 )', 'Ganjil 2017 / 2018', 'X-IPS1', 'IPS', '21'),
(170, 'Rabu', '1234567890 - Dra. SUWINARTI ( Geografi / IPS )', '6 ( 10:50:00 - 11:30:00 )', 'Ganjil 2017 / 2018', 'X-IPS1', 'IPS', '21'),
(171, 'Rabu', '1234567890 - MARIFA RIAMA, S.Pd. ( Sejarah / IPS )', '7 ( 12:30:00 - 13:15:00 )', 'Ganjil 2017 / 2018', 'X-IPS1', 'IPS', '11'),
(172, 'Rabu', '1234567890 - MARIFA RIAMA, S.Pd. ( Sejarah / IPS )', '8 ( 13:15:00 - 14:00:00 )', 'Ganjil 2017 / 2018', 'X-IPS1', 'IPS', '11'),
(173, 'Rabu', '1234567890 - Dra. AGUS SETYANINGSIH, M.Si ( Matematika / IPS )', '9 ( 14:00:00 - 14:45:00 )', 'Ganjil 2017 / 2018', 'X-IPS1', 'IPS', '27'),
(174, 'Rabu', '1234567890 - Dra. AGUS SETYANINGSIH, M.Si ( Matematika / IPS )', '10 ( 14:45:00 - 15:30:00 )', 'Ganjil 2017 / 2018', 'X-IPS1', 'IPS', '27'),
(175, 'Kamis', '1234567890 - SURAWAN, S.Pd. ( Bahasa Inggris / IPS )', '1 ( 06:45:00 - 07:30:00 )', 'Ganjil 2017 / 2018', 'X-IPS1', 'IPS', '3'),
(176, 'Kamis', '1234567890 - SURAWAN, S.Pd. ( Bahasa Inggris / IPS )', '2 ( 07:30:00 - 08:15:00 )', 'Ganjil 2017 / 2018', 'X-IPS1', 'IPS', '3'),
(177, 'Kamis', '1234567890 - MUHAMMAD SUWAR, S.Pd.I. ( Bahasa Arab / IPS )', '3 ( 08:15:00 - 09:00:00 )', 'Ganjil 2017 / 2018', 'X-IPS1', 'IPS', '9'),
(178, 'Kamis', '1234567890 - MUHAMMAD SUWAR, S.Pd.I. ( Bahasa Arab / IPS )', '4 ( 09:00:00 - 09:45:00 )', 'Ganjil 2017 / 2018', 'X-IPS1', 'IPS', '9'),
(179, 'Kamis', '1234567890 - ISMI MARIYAM, S.Pd. ( Bhs & Sastra Ind / IPS )', '5 ( 10:05:00 - 10:50:00 )', 'Ganjil 2017 / 2018', 'X-IPS1', 'IPS', '22'),
(180, 'Kamis', '1234567890 - ISMI MARIYAM, S.Pd. ( Bhs & Sastra Ind / IPS )', '6 ( 10:50:00 - 11:30:00 )', 'Ganjil 2017 / 2018', 'X-IPS1', 'IPS', '22'),
(181, 'Kamis', '1234567890 - WIWIN SISWINARNI, S.Pd. ( Pendidikan Kewarganegaraan / IPS )', '7 ( 12:30:00 - 13:15:00 )', 'Ganjil 2017 / 2018', 'X-IPS1', 'IPS', '28'),
(182, 'Kamis', '1234567890 - WIWIN SISWINARNI, S.Pd. ( Pendidikan Kewarganegaraan / IPS )', '8 ( 13:15:00 - 14:00:00 )', 'Ganjil 2017 / 2018', 'X-IPS1', 'IPS', '28'),
(183, 'Kamis', '1234567890 - USMAN, S.Pd. ( Bahasa Indonesia / IPS )', '9 ( 14:00:00 - 14:45:00 )', 'Ganjil 2017 / 2018', 'X-IPS1', 'IPS', '24'),
(184, 'Kamis', '1234567890 - USMAN, S.Pd. ( Bahasa Indonesia / IPS )', '10 ( 14:45:00 - 15:30:00 )', 'Ganjil 2017 / 2018', 'X-IPS1', 'IPS', '24'),
(185, 'Jumat', '1234567890 - ARIF MUSTOFA, S.Ag., M.Pd. ( Fiqih / IPS )', '1 ( 06:45:00 - 07:30:00 )', 'Ganjil 2017 / 2018', 'X-IPS1', 'IPS', '29'),
(186, 'Jumat', '1234567890 - ARIF MUSTOFA, S.Ag., M.Pd. ( Fiqih / IPS )', '2 ( 07:30:00 - 08:15:00 )', 'Ganjil 2017 / 2018', 'X-IPS1', 'IPS', '29'),
(187, 'Jumat', '1234567890 - INSA ASYAROH, S.Ag ( Al Quran Hadis / IPS )', '3 ( 08:15:00 - 09:00:00 )', 'Ganjil 2017 / 2018', 'X-IPS1', 'IPS', '5'),
(188, 'Jumat', '1234567890 - INSA ASYAROH, S.Ag ( Al Quran Hadis / IPS )', '4 ( 09:00:00 - 09:45:00 )', 'Ganjil 2017 / 2018', 'X-IPS1', 'IPS', '5'),
(189, 'Jumat', '1234567890 - NASHRUL ULUM, S.Pd. ( S K I / IPS )', '5 ( 10:05:00 - 10:50:00 )', 'Ganjil 2017 / 2018', 'X-IPS1', 'IPS', '26'),
(190, 'Jumat', '1234567890 - NASHRUL ULUM, S.Pd. ( S K I / IPS )', '6 ( 10:50:00 - 11:30:00 )', 'Ganjil 2017 / 2018', 'X-IPS1', 'IPS', '26'),
(191, 'Jumat', '1234567890 - AHERI SUGIHARTONO, S.Th.I ( Aqidah Akhlak / IPS )', '7 ( 12:30:00 - 13:15:00 )', 'Ganjil 2017 / 2018', 'X-IPS1', 'IPS', '6'),
(192, 'Jumat', '1234567890 - AHERI SUGIHARTONO, S.Th.I ( Aqidah Akhlak / IPS )', '8 ( 13:15:00 - 14:00:00 )', 'Ganjil 2017 / 2018', 'X-IPS1', 'IPS', '6'),
(193, 'Senin', '1234567890 - HADIAH, S.Pd. ( Ekonomi / IPS )', '1 ( 06:45:00 - 07:30:00 )', 'Ganjil 2017 / 2018', 'X-IPS2', 'IPS', '23'),
(194, 'Senin', '1234567890 - HADIAH, S.Pd. ( Ekonomi / IPS )', '2 ( 07:30:00 - 08:15:00 )', 'Ganjil 2017 / 2018', 'X-IPS2', 'IPS', '23'),
(195, 'Senin', '1234567890 - Drs. YUDI SYAIFULLOH ( Pendidikan Jasmani, ORKES / IPS )', '3 ( 08:15:00 - 09:00:00 )', 'Ganjil 2017 / 2018', 'X-IPS2', 'IPS', '1'),
(196, 'Senin', '1234567890 - Drs. YUDI SYAIFULLOH ( Pendidikan Jasmani, ORKES / IPS )', '4 ( 09:00:00 - 09:45:00 )', 'Ganjil 2017 / 2018', 'X-IPS2', 'IPS', '1'),
(197, 'Senin', '1234567890 - Dra. AGUS SETYANINGSIH, M.Si ( Matematika / IPS )', '5 ( 10:05:00 - 10:50:00 )', 'Ganjil 2017 / 2018', 'X-IPS2', 'IPS', '27'),
(198, 'Senin', '1234567890 - Dra. AGUS SETYANINGSIH, M.Si ( Matematika / IPS )', '6 ( 10:50:00 - 11:30:00 )', 'Ganjil 2017 / 2018', 'X-IPS2', 'IPS', '27'),
(199, 'Senin', '1234567890 - MARIFA RIAMA, S.Pd. ( Sejarah / IPS )', '7 ( 12:30:00 - 13:15:00 )', 'Ganjil 2017 / 2018', 'X-IPS2', 'IPS', '11'),
(200, 'Senin', '1234567890 - MARIFA RIAMA, S.Pd. ( Sejarah / IPS )', '8 ( 13:15:00 - 14:00:00 )', 'Ganjil 2017 / 2018', 'X-IPS2', 'IPS', '11'),
(201, 'Senin', '1234567890 - NASHRUL ULUM, S.Pd. ( Sosiologi / IPS )', '9 ( 14:00:00 - 14:45:00 )', 'Ganjil 2017 / 2018', 'X-IPS2', 'IPS', '26'),
(202, 'Senin', '1234567890 - NASHRUL ULUM, S.Pd. ( Sosiologi / IPS )', '10 ( 14:45:00 - 15:30:00 )', 'Ganjil 2017 / 2018', 'X-IPS2', 'IPS', '26'),
(203, 'Selasa', '1234567890 - ARIF MUSTOFA, S.Ag., M.Pd. ( Fiqih / IPS )', '1 ( 06:45:00 - 07:30:00 )', 'Ganjil 2017 / 2018', 'X-IPS2', 'IPS', '29'),
(204, 'Selasa', '1234567890 - ARIF MUSTOFA, S.Ag., M.Pd. ( Fiqih / IPS )', '2 ( 07:30:00 - 08:15:00 )', 'Ganjil 2017 / 2018', 'X-IPS2', 'IPS', '29'),
(205, 'Selasa', '1234567890 - INSA ASYAROH, S.Ag ( Al Quran Hadis / IPS )', '3 ( 08:15:00 - 09:00:00 )', 'Ganjil 2017 / 2018', 'X-IPS2', 'IPS', '5'),
(206, 'Selasa', '1234567890 - INSA ASYAROH, S.Ag ( Al Quran Hadis / IPS )', '4 ( 09:00:00 - 09:45:00 )', 'Ganjil 2017 / 2018', 'X-IPS2', 'IPS', '5'),
(207, 'Selasa', '1234567890 - WIWIN SISWINARNI, S.Pd. ( Pendidikan Kewarganegaraan / IPS )', '5 ( 10:05:00 - 10:50:00 )', 'Ganjil 2017 / 2018', 'X-IPS2', 'IPS', '28'),
(208, 'Selasa', '1234567890 - WIWIN SISWINARNI, S.Pd. ( Pendidikan Kewarganegaraan / IPS )', '6 ( 10:50:00 - 11:30:00 )', 'Ganjil 2017 / 2018', 'X-IPS2', 'IPS', '28'),
(209, 'Selasa', '1234567890 - NASHRUL ULUM, S.Pd. ( S K I / IPS )', '7 ( 12:30:00 - 13:15:00 )', 'Ganjil 2017 / 2018', 'X-IPS2', 'IPS', '26'),
(210, 'Selasa', '1234567890 - NASHRUL ULUM, S.Pd. ( S K I / IPS )', '8 ( 13:15:00 - 14:00:00 )', 'Ganjil 2017 / 2018', 'X-IPS2', 'IPS', '26'),
(211, 'Selasa', '1234567890 - AHERI SUGIHARTONO, S.Th.I ( Aqidah Akhlak / IPS )', '9 ( 14:00:00 - 14:45:00 )', 'Ganjil 2017 / 2018', 'X-IPS2', 'IPS', '6'),
(212, 'Selasa', '1234567890 - AHERI SUGIHARTONO, S.Th.I ( Aqidah Akhlak / IPS )', '10 ( 14:45:00 - 15:30:00 )', 'Ganjil 2017 / 2018', 'X-IPS2', 'IPS', '6'),
(213, 'Rabu', '1234567890 - USMAN, S.Pd. ( Bahasa Indonesia / IPS )', '1 ( 06:45:00 - 07:30:00 )', 'Ganjil 2017 / 2018', 'X-IPS2', 'IPS', '24'),
(214, 'Rabu', '1234567890 - USMAN, S.Pd. ( Bahasa Indonesia / IPS )', '2 ( 07:30:00 - 08:15:00 )', 'Ganjil 2017 / 2018', 'X-IPS2', 'IPS', '24'),
(215, 'Rabu', '1234567890 - Dra. AGUS SETYANINGSIH, M.Si ( Matematika / IPS )', '3 ( 08:15:00 - 09:00:00 )', 'Ganjil 2017 / 2018', 'X-IPS2', 'IPS', '27'),
(216, 'Rabu', '1234567890 - Dra. AGUS SETYANINGSIH, M.Si ( Matematika / IPS )', '4 ( 09:00:00 - 09:45:00 )', 'Ganjil 2017 / 2018', 'X-IPS2', 'IPS', '27'),
(217, 'Rabu', '1234567890 - MUHAMMAD SUWAR, S.Pd.I. ( Bahasa Arab / IPS )', '5 ( 10:05:00 - 10:50:00 )', 'Ganjil 2017 / 2018', 'X-IPS2', 'IPS', '9'),
(218, 'Rabu', '1234567890 - MUHAMMAD SUWAR, S.Pd.I. ( Bahasa Arab / IPS )', '6 ( 10:50:00 - 11:30:00 )', 'Ganjil 2017 / 2018', 'X-IPS2', 'IPS', '9'),
(219, 'Rabu', '1234567890 - ISMI MARIYAM, S.Pd. ( Bhs & Sastra Ind / IPS )', '7 ( 12:30:00 - 13:15:00 )', 'Ganjil 2017 / 2018', 'X-IPS2', 'IPS', '22'),
(220, 'Rabu', '1234567890 - ISMI MARIYAM, S.Pd. ( Bhs & Sastra Ind / IPS )', '8 ( 13:15:00 - 14:00:00 )', 'Ganjil 2017 / 2018', 'X-IPS2', 'IPS', '22'),
(221, 'Rabu', '1234567890 - HADIAH, S.Pd. ( Ekonomi / IPS )', '9 ( 14:00:00 - 14:45:00 )', 'Ganjil 2017 / 2018', 'X-IPS2', 'IPS', '23'),
(222, 'Rabu', '1234567890 - HADIAH, S.Pd. ( Ekonomi / IPS )', '10 ( 14:45:00 - 15:30:00 )', 'Ganjil 2017 / 2018', 'X-IPS2', 'IPS', '23'),
(223, 'Kamis', '1234567890 - MARIFA RIAMA, S.Pd. ( Sejarah / IPS )', '1 ( 06:45:00 - 07:30:00 )', 'Ganjil 2017 / 2018', 'X-IPS2', 'IPS', '11'),
(224, 'Kamis', '1234567890 - MARIFA RIAMA, S.Pd. ( Sejarah / IPS )', '2 ( 07:30:00 - 08:15:00 )', 'Ganjil 2017 / 2018', 'X-IPS2', 'IPS', '11'),
(225, 'Kamis', '1234567890 - Dra. SUWINARTI ( Geografi / IPS )', '3 ( 08:15:00 - 09:00:00 )', 'Ganjil 2017 / 2018', 'X-IPS2', 'IPS', '21'),
(226, 'Kamis', '1234567890 - Dra. SUWINARTI ( Geografi / IPS )', '4 ( 09:00:00 - 09:45:00 )', 'Ganjil 2017 / 2018', 'X-IPS2', 'IPS', '21'),
(227, 'Kamis', '1234567890 - SURAWAN, S.Pd. ( Bahasa Inggris / IPS )', '5 ( 10:05:00 - 10:50:00 )', 'Ganjil 2017 / 2018', 'X-IPS2', 'IPS', '3'),
(228, 'Kamis', '1234567890 - SURAWAN, S.Pd. ( Bahasa Inggris / IPS )', '6 ( 10:50:00 - 11:30:00 )', 'Ganjil 2017 / 2018', 'X-IPS2', 'IPS', '3'),
(229, 'Kamis', '1234567890 - YAYUK ISWATIN, S.Pd ( Seni Budaya / IPS )', '7 ( 12:30:00 - 13:15:00 )', 'Ganjil 2017 / 2018', 'X-IPS2', 'IPS', '17'),
(230, 'Kamis', '1234567890 - YAYUK ISWATIN, S.Pd ( Seni Budaya / IPS )', '8 ( 13:15:00 - 14:00:00 )', 'Ganjil 2017 / 2018', 'X-IPS2', 'IPS', '17'),
(231, 'Kamis', '1234567890 - NASHRUL ULUM, S.Pd. ( Sosiologi / IPS )', '9 ( 14:00:00 - 14:45:00 )', 'Ganjil 2017 / 2018', 'X-IPS2', 'IPS', '26'),
(232, 'Kamis', '1234567890 - NASHRUL ULUM, S.Pd. ( Sosiologi / IPS )', '10 ( 14:45:00 - 15:30:00 )', 'Ganjil 2017 / 2018', 'X-IPS2', 'IPS', '26'),
(233, 'Jumat', '1234567890 - HADIAH, S.Pd. ( Ekonomi / IPS )', '1 ( 06:45:00 - 07:30:00 )', 'Ganjil 2017 / 2018', 'X-IPS2', 'IPS', '23'),
(234, 'Jumat', '1234567890 - HADIAH, S.Pd. ( Ekonomi / IPS )', '2 ( 07:30:00 - 08:15:00 )', 'Ganjil 2017 / 2018', 'X-IPS2', 'IPS', '23'),
(235, 'Jumat', '1234567890 - TEGUH KOESTANTININGSIH, S.Pd ( Keterampilan / IPS )', '3 ( 08:15:00 - 09:00:00 )', 'Ganjil 2017 / 2018', 'X-IPS2', 'IPS', '25'),
(236, 'Jumat', '1234567890 - TEGUH KOESTANTININGSIH, S.Pd ( Keterampilan / IPS )', '4 ( 09:00:00 - 09:45:00 )', 'Ganjil 2017 / 2018', 'X-IPS2', 'IPS', '25'),
(237, 'Jumat', '1234567890 - NENI SUHARTINI, S.Pd, M.Psi ( BK / IPS )', '5 ( 10:05:00 - 10:50:00 )', 'Ganjil 2017 / 2018', 'X-IPS2', 'IPS', '20'),
(238, 'Jumat', '1234567890 - NENI SUHARTINI, S.Pd, M.Psi ( BK / IPS )', '6 ( 10:50:00 - 11:30:00 )', 'Ganjil 2017 / 2018', 'X-IPS2', 'IPS', '20'),
(239, 'Jumat', '1234567890 - MOHAMAD AFIF FARICHIN, M.Pd.I. ( Muhadatsah / IPS )', '7 ( 12:30:00 - 13:15:00 )', 'Ganjil 2017 / 2018', 'X-IPS2', 'IPS', '13'),
(240, 'Jumat', '1234567890 - MOHAMAD AFIF FARICHIN, M.Pd.I. ( Muhadatsah / IPS )', '8 ( 13:15:00 - 14:00:00 )', 'Ganjil 2017 / 2018', 'X-IPS2', 'IPS', '13'),
(241, 'Senin', '1234567890 - MARIFA RIAMA, S.Pd. ( Sejarah / AGAMA )', '1 ( 06:45:00 - 07:30:00 )', 'Ganjil 2017 / 2018', 'X-IAG', 'AGAMA', '11'),
(242, 'Senin', '1234567890 - MARIFA RIAMA, S.Pd. ( Sejarah / AGAMA )', '2 ( 07:30:00 - 08:15:00 )', 'Ganjil 2017 / 2018', 'X-IAG', 'AGAMA', '11'),
(243, 'Senin', '1234567890 - YAYUK ISWATIN, S.Pd ( Seni Budaya / AGAMA )', '3 ( 08:15:00 - 09:00:00 )', 'Ganjil 2017 / 2018', 'X-IAG', 'AGAMA', '17'),
(244, 'Senin', '1234567890 - YAYUK ISWATIN, S.Pd ( Seni Budaya / AGAMA )', '4 ( 09:00:00 - 09:45:00 )', 'Ganjil 2017 / 2018', 'X-IAG', 'AGAMA', '17'),
(245, 'Senin', '1234567890 - ARIF MUSTOFA, S.Ag., M.Pd. ( Ushul Fiqih / AGAMA )', '5 ( 10:05:00 - 10:50:00 )', 'Ganjil 2017 / 2018', 'X-IAG', 'AGAMA', '29'),
(246, 'Senin', '1234567890 - ARIF MUSTOFA, S.Ag., M.Pd. ( Ushul Fiqih / AGAMA )', '6 ( 10:50:00 - 11:30:00 )', 'Ganjil 2017 / 2018', 'X-IAG', 'AGAMA', '29'),
(247, 'Senin', '1234567890 - UMAR FARUQ, S.Ag. ( Ilmu Kalam / AGAMA )', '7 ( 12:30:00 - 13:15:00 )', 'Ganjil 2017 / 2018', 'X-IAG', 'AGAMA', '30'),
(248, 'Senin', '1234567890 - UMAR FARUQ, S.Ag. ( Ilmu Kalam / AGAMA )', '8 ( 13:15:00 - 14:00:00 )', 'Ganjil 2017 / 2018', 'X-IAG', 'AGAMA', '30'),
(249, 'Senin', '1234567890 - WIWIN SISWINARNI, S.Pd. ( Pendidikan Kewarganegaraan / AGAMA )', '9 ( 14:00:00 - 14:45:00 )', 'Ganjil 2017 / 2018', 'X-IAG', 'AGAMA', '28'),
(250, 'Senin', '1234567890 - WIWIN SISWINARNI, S.Pd. ( Pendidikan Kewarganegaraan / AGAMA )', '10 ( 14:45:00 - 15:30:00 )', 'Ganjil 2017 / 2018', 'X-IAG', 'AGAMA', '28'),
(251, 'Selasa', '1234567890 - SITI MARIA ULFAH, S.Pd.I ( Ilmu Hadits / AGAMA )', '1 ( 06:45:00 - 07:30:00 )', 'Ganjil 2017 / 2018', 'X-IAG', 'AGAMA', '31'),
(252, 'Selasa', '1234567890 - SITI MARIA ULFAH, S.Pd.I ( Ilmu Hadits / AGAMA )', '2 ( 07:30:00 - 08:15:00 )', 'Ganjil 2017 / 2018', 'X-IAG', 'AGAMA', '31'),
(253, 'Selasa', '1234567890 - TEGUH KOESTANTININGSIH, S.Pd ( Keterampilan / IPS )', '3 ( 08:15:00 - 09:00:00 )', 'Ganjil 2017 / 2018', 'X-IAG', 'AGAMA', '25'),
(254, 'Selasa', '1234567890 - TEGUH KOESTANTININGSIH, S.Pd ( Keterampilan / IPS )', '4 ( 09:00:00 - 09:45:00 )', 'Ganjil 2017 / 2018', 'X-IAG', 'AGAMA', '25'),
(255, 'Selasa', '1234567890 - MARIFA RIAMA, S.Pd. ( Sejarah / AGAMA )', '5 ( 10:05:00 - 10:50:00 )', 'Ganjil 2017 / 2018', 'X-IAG', 'AGAMA', '11'),
(256, 'Selasa', '1234567890 - MARIFA RIAMA, S.Pd. ( Sejarah / AGAMA )', '6 ( 10:50:00 - 11:30:00 )', 'Ganjil 2017 / 2018', 'X-IAG', 'AGAMA', '11'),
(257, 'Selasa', '1234567890 - MOHAMAD AFIF FARICHIN, M.Pd.I. ( Muhadatsah / AGAMA )', '7 ( 12:30:00 - 13:15:00 )', 'Ganjil 2017 / 2018', 'X-IAG', 'AGAMA', '13'),
(258, 'Selasa', '1234567890 - MOHAMAD AFIF FARICHIN, M.Pd.I. ( Muhadatsah / AGAMA )', '8 ( 13:15:00 - 14:00:00 )', 'Ganjil 2017 / 2018', 'X-IAG', 'AGAMA', '13'),
(259, 'Selasa', '1234567890 - INSA ASYAROH, S.Ag ( Ilmu Hadits / AGAMA )', '9 ( 14:00:00 - 14:45:00 )', 'Ganjil 2017 / 2018', 'X-IAG', 'AGAMA', '5'),
(260, 'Selasa', '1234567890 - INSA ASYAROH, S.Ag ( Ilmu Hadits / AGAMA )', '10 ( 14:45:00 - 15:30:00 )', 'Ganjil 2017 / 2018', 'X-IAG', 'AGAMA', '5'),
(261, 'Rabu', '1234567890 - UMAR FARUQ, S.Ag. ( Ilmu Kalam / AGAMA )', '1 ( 06:45:00 - 07:30:00 )', 'Ganjil 2017 / 2018', 'X-IAG', 'AGAMA', '30'),
(262, 'Rabu', '1234567890 - UMAR FARUQ, S.Ag. ( Ilmu Kalam / AGAMA )', '2 ( 07:30:00 - 08:15:00 )', 'Ganjil 2017 / 2018', 'X-IAG', 'AGAMA', '30'),
(263, 'Rabu', '1234567890 - NENI SUHARTINI, S.Pd, M.Psi ( BK / AGAMA )', '3 ( 08:15:00 - 09:00:00 )', 'Ganjil 2017 / 2018', 'X-IAG', 'AGAMA', '20'),
(264, 'Rabu', '1234567890 - NENI SUHARTINI, S.Pd, M.Psi ( BK / AGAMA )', '4 ( 09:00:00 - 09:45:00 )', 'Ganjil 2017 / 2018', 'X-IAG', 'AGAMA', '20'),
(265, 'Rabu', '1234567890 - Dra. AGUS SETYANINGSIH, M.Si ( Matematika / AGAMA )', '5 ( 10:05:00 - 10:50:00 )', 'Ganjil 2017 / 2018', 'X-IAG', 'AGAMA', '27'),
(266, 'Rabu', '1234567890 - Dra. AGUS SETYANINGSIH, M.Si ( Matematika / AGAMA )', '6 ( 10:50:00 - 11:30:00 )', 'Ganjil 2017 / 2018', 'X-IAG', 'AGAMA', '27'),
(267, 'Rabu', '1234567890 - ALIFIYAH RUSDIYANA, S.Pd. ( Bahasa Inggris / AGAMA )', '7 ( 12:30:00 - 13:15:00 )', 'Ganjil 2017 / 2018', 'X-IAG', 'AGAMA', '32'),
(268, 'Rabu', '1234567890 - ALIFIYAH RUSDIYANA, S.Pd. ( Bahasa Inggris / AGAMA )', '8 ( 13:15:00 - 14:00:00 )', 'Ganjil 2017 / 2018', 'X-IAG', 'AGAMA', '32'),
(269, 'Rabu', '1234567890 - MOHAMAD AFIF FARICHIN, M.Pd.I. ( Bahasa Arab / AGAMA )', '9 ( 14:00:00 - 14:45:00 )', 'Ganjil 2017 / 2018', 'X-IAG', 'AGAMA', '13'),
(270, 'Rabu', '1234567890 - MOHAMAD AFIF FARICHIN, M.Pd.I. ( Bahasa Arab / AGAMA )', '10 ( 14:45:00 - 15:30:00 )', 'Ganjil 2017 / 2018', 'X-IAG', 'AGAMA', '13'),
(271, 'Kamis', '1234567890 - ISMI MARIYAM, S.Pd. ( Bhs & Sastra Ind / AGAMA )', '1 ( 06:45:00 - 07:30:00 )', 'Ganjil 2017 / 2018', 'X-IAG', 'AGAMA', '22'),
(272, 'Kamis', '1234567890 - ISMI MARIYAM, S.Pd. ( Bhs & Sastra Ind / AGAMA )', '2 ( 07:30:00 - 08:15:00 )', 'Ganjil 2017 / 2018', 'X-IAG', 'AGAMA', '22'),
(273, 'Kamis', '1234567890 - MARDWI ASDIYANTO, M.Pd.I. ( Ilmu Tafsir / AGAMA )', '3 ( 08:15:00 - 09:00:00 )', 'Ganjil 2017 / 2018', 'X-IAG', 'AGAMA', '7'),
(274, 'Kamis', '1234567890 - MARDWI ASDIYANTO, M.Pd.I. ( Ilmu Tafsir / AGAMA )', '4 ( 09:00:00 - 09:45:00 )', 'Ganjil 2017 / 2018', 'X-IAG', 'AGAMA', '7'),
(275, 'Kamis', '1234567890 - USMAN, S.Pd. ( Bahasa Indonesia / AGAMA )', '5 ( 10:05:00 - 10:50:00 )', 'Ganjil 2017 / 2018', 'X-IAG', 'AGAMA', '24'),
(276, 'Kamis', '1234567890 - USMAN, S.Pd. ( Bahasa Indonesia / AGAMA )', '6 ( 10:50:00 - 11:30:00 )', 'Ganjil 2017 / 2018', 'X-IAG', 'AGAMA', '24'),
(277, 'Kamis', '1234567890 - UMAR FARUQ, S.Ag. ( Ilmu Kalam / AGAMA )', '7 ( 12:30:00 - 13:15:00 )', 'Ganjil 2017 / 2018', 'X-IAG', 'AGAMA', '30'),
(278, 'Kamis', '1234567890 - UMAR FARUQ, S.Ag. ( Ilmu Kalam / AGAMA )', '8 ( 13:15:00 - 14:00:00 )', 'Ganjil 2017 / 2018', 'X-IAG', 'AGAMA', '30'),
(279, 'Kamis', '1234567890 - AHERI SUGIHARTONO, S.Th.I ( Akhlak / AGAMA )', '9 ( 14:00:00 - 14:45:00 )', 'Ganjil 2017 / 2018', 'X-IAG', 'AGAMA', '6'),
(280, 'Kamis', '1234567890 - AHERI SUGIHARTONO, S.Th.I ( Akhlak / AGAMA )', '10 ( 14:45:00 - 15:30:00 )', 'Ganjil 2017 / 2018', 'X-IAG', 'AGAMA', '6'),
(281, 'Jumat', '1234567890 - AHERI SUGIHARTONO, S.Th.I ( Aqidah Akhlak / AGAMA )', '1 ( 06:45:00 - 07:30:00 )', 'Ganjil 2017 / 2018', 'X-IAG', 'AGAMA', '6'),
(282, 'Jumat', '1234567890 - AHERI SUGIHARTONO, S.Th.I ( Aqidah Akhlak / AGAMA )', '2 ( 07:30:00 - 08:15:00 )', 'Ganjil 2017 / 2018', 'X-IAG', 'AGAMA', '6'),
(283, 'Jumat', '1234567890 - INSA ASYAROH, S.Ag ( Al Quran Hadis / AGAMA )', '3 ( 08:15:00 - 09:00:00 )', 'Ganjil 2017 / 2018', 'X-IAG', 'AGAMA', '5'),
(284, 'Jumat', '1234567890 - INSA ASYAROH, S.Ag ( Al Quran Hadis / AGAMA )', '4 ( 09:00:00 - 09:45:00 )', 'Ganjil 2017 / 2018', 'X-IAG', 'AGAMA', '5'),
(285, 'Jumat', '1234567890 - YUDHA KURNIAWAN, S.Pd. ( Pendidikan Jasmani, ORKES / AGAMA )', '5 ( 10:05:00 - 10:50:00 )', 'Ganjil 2017 / 2018', 'X-IAG', 'AGAMA', '33'),
(286, 'Jumat', '1234567890 - YUDHA KURNIAWAN, S.Pd. ( Pendidikan Jasmani, ORKES / AGAMA )', '6 ( 10:50:00 - 11:30:00 )', 'Ganjil 2017 / 2018', 'X-IAG', 'AGAMA', '33'),
(287, 'Jumat', '1234567890 - ARIF MUSTOFA, S.Ag., M.Pd. ( Fiqih / AGAMA )', '7 ( 12:30:00 - 13:15:00 )', 'Ganjil 2017 / 2018', 'X-IAG', 'AGAMA', '34'),
(288, 'Jumat', '1234567890 - ARIF MUSTOFA, S.Ag., M.Pd. ( Fiqih / AGAMA )', '8 ( 13:15:00 - 14:00:00 )', 'Ganjil 2017 / 2018', 'X-IAG', 'AGAMA', '34'),
(289, 'Senin', '1234567890 - TRI SUDIK WIYONO, S.Pd ( Ekonomi / IPA )', '1 ( 06:45:00 - 07:30:00 )', 'Ganjil 2017 / 2018', 'XI-IPA 1', 'IPA', '16'),
(290, 'Senin', '1234567890 - TRI SUDIK WIYONO, S.Pd ( Ekonomi / IPA )', '2 ( 07:30:00 - 08:15:00 )', 'Ganjil 2017 / 2018', 'XI-IPA 1', 'IPA', '16'),
(291, 'Senin', '1234567890 - EDDI HARIYADI, S,Pd. ( Seni Budaya / IPA )', '3 ( 08:15:00 - 09:00:00 )', 'Ganjil 2017 / 2018', 'XI-IPA 1', 'IPA', '35'),
(292, 'Senin', '1234567890 - EDDI HARIYADI, S,Pd. ( Seni Budaya / IPA )', '4 ( 09:00:00 - 09:45:00 )', 'Ganjil 2017 / 2018', 'XI-IPA 1', 'IPA', '35'),
(293, 'Senin', '1234567890 - YUDHA KURNIAWAN, S.Pd. ( Pendidikan Jasmani, ORKES / IPA )', '5 ( 10:05:00 - 10:50:00 )', 'Ganjil 2017 / 2018', 'XI-IPA 1', 'IPA', '33'),
(294, 'Senin', '1234567890 - YUDHA KURNIAWAN, S.Pd. ( Pendidikan Jasmani, ORKES / IPA )', '6 ( 10:50:00 - 11:30:00 )', 'Ganjil 2017 / 2018', 'XI-IPA 1', 'IPA', '33'),
(295, 'Senin', '1234567890 - MOHAMAD AFIF FARICHIN, M.Pd.I. ( Muhadatsah / IPA )', '7 ( 12:30:00 - 13:15:00 )', 'Ganjil 2017 / 2018', 'XI-IPA 1', 'IPA', '13'),
(296, 'Senin', '1234567890 - MOHAMAD AFIF FARICHIN, M.Pd.I. ( Muhadatsah / IPA )', '8 ( 13:15:00 - 14:00:00 )', 'Ganjil 2017 / 2018', 'XI-IPA 1', 'IPA', '13'),
(297, 'Senin', '1234567890 - TEGUH KOESTANTININGSIH, S.Pd ( Keterampilan / IPA )', '9 ( 14:00:00 - 14:45:00 )', 'Ganjil 2017 / 2018', 'XI-IPA 1', 'IPA', '25'),
(298, 'Senin', '1234567890 - TEGUH KOESTANTININGSIH, S.Pd ( Keterampilan / IPA )', '10 ( 14:45:00 - 15:30:00 )', 'Ganjil 2017 / 2018', 'XI-IPA 1', 'IPA', '25'),
(299, 'Selasa', '1234567890 - Dra. ULUMIYAH ( BKTI / IPA )', '1 ( 06:45:00 - 07:30:00 )', 'Ganjil 2017 / 2018', 'XI-IPA 1', 'IPA', '35'),
(300, 'Selasa', '1234567890 - Dra. ULUMIYAH ( BKTI / IPA )', '2 ( 07:30:00 - 08:15:00 )', 'Ganjil 2017 / 2018', 'XI-IPA 1', 'IPA', '35'),
(301, 'Selasa', '1234567890 - ALY FUADI, S.Pd. ( Fisika / IPA )', '3 ( 08:15:00 - 09:00:00 )', 'Ganjil 2017 / 2018', 'XI-IPA 1', 'IPA', '36'),
(302, 'Selasa', '1234567890 - ALY FUADI, S.Pd. ( Fisika / IPA )', '4 ( 09:00:00 - 09:45:00 )', 'Ganjil 2017 / 2018', 'XI-IPA 1', 'IPA', '36'),
(303, 'Selasa', '1234567890 - Dra. MAZIDAH INAYATI ( Matematika / IPA )', '5 ( 10:05:00 - 10:50:00 )', 'Ganjil 2017 / 2018', 'XI-IPA 1', 'IPA', '37'),
(304, 'Selasa', '1234567890 - Dra. MAZIDAH INAYATI ( Matematika / IPA )', '6 ( 10:50:00 - 11:30:00 )', 'Ganjil 2017 / 2018', 'XI-IPA 1', 'IPA', '37'),
(305, 'Selasa', '1234567890 - INGRID ARIANY SAVITRI, S.Pd. ( Biologi / IPA )', '7 ( 12:30:00 - 13:15:00 )', 'Ganjil 2017 / 2018', 'XI-IPA 1', 'IPA', '38'),
(306, 'Selasa', '1234567890 - INGRID ARIANY SAVITRI, S.Pd. ( Biologi / IPA )', '8 ( 13:15:00 - 14:00:00 )', 'Ganjil 2017 / 2018', 'XI-IPA 1', 'IPA', '38'),
(307, 'Selasa', '1234567890 - ENNI SUBCHANDINI, S.Pd ( Kimia / IPA )', '9 ( 14:00:00 - 14:45:00 )', 'Ganjil 2017 / 2018', 'XI-IPA 1', 'IPA', '39'),
(308, 'Selasa', '1234567890 - ENNI SUBCHANDINI, S.Pd ( Kimia / IPA )', '10 ( 14:45:00 - 15:30:00 )', 'Ganjil 2017 / 2018', 'XI-IPA 1', 'IPA', '39'),
(309, '', '', '', 'Ganjil 2017 / 2018', '', '', '');

-- --------------------------------------------------------

--
-- Struktur dari tabel `jadwalku`
--

CREATE TABLE `jadwalku` (
  `idjadwalnya` int(11) NOT NULL,
  `idperiode` varchar(200) NOT NULL,
  `idhari` varchar(200) NOT NULL,
  `idjam` varchar(100) NOT NULL,
  `idguru` varchar(100) NOT NULL,
  `idmapel` varchar(100) NOT NULL,
  `idkelas` varchar(100) NOT NULL,
  `idjur` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Struktur dari tabel `jampel`
--

CREATE TABLE `jampel` (
  `idjam` int(11) NOT NULL,
  `jamke` varchar(200) NOT NULL,
  `jam_mulai` time NOT NULL,
  `jam_selesai` time NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `jampel`
--

INSERT INTO `jampel` (`idjam`, `jamke`, `jam_mulai`, `jam_selesai`) VALUES
(1, '1', '06:45:00', '07:30:00'),
(2, '2', '07:30:00', '08:15:00'),
(3, '3', '08:15:00', '09:00:00'),
(4, '4', '09:00:00', '09:45:00'),
(5, '5', '10:05:00', '10:50:00'),
(6, '6', '10:50:00', '11:30:00'),
(7, '7', '12:30:00', '13:15:00'),
(8, '8', '13:15:00', '14:00:00'),
(9, '9', '14:00:00', '14:45:00'),
(10, '10', '14:45:00', '15:30:00');

-- --------------------------------------------------------

--
-- Struktur dari tabel `jurusan`
--

CREATE TABLE `jurusan` (
  `idjur` int(11) NOT NULL,
  `nama_jurusan` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `jurusan`
--

INSERT INTO `jurusan` (`idjur`, `nama_jurusan`) VALUES
(1, 'IPA'),
(2, 'IPS'),
(3, 'AGAMA');

-- --------------------------------------------------------

--
-- Struktur dari tabel `kelas`
--

CREATE TABLE `kelas` (
  `idkelas` int(11) NOT NULL,
  `nama_kelas` varchar(200) NOT NULL,
  `idjur` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `kelas`
--

INSERT INTO `kelas` (`idkelas`, `nama_kelas`, `idjur`) VALUES
(1, 'X-MIPA1', '1'),
(2, 'X-MIPA2', '1'),
(3, 'X-MIPA3', '1'),
(4, 'X-IPS1', '2'),
(5, 'X-IPS2', '2'),
(6, 'X-IAG', '3'),
(7, 'XI-IPA 1', '1'),
(8, 'XI-IPA 2', '1'),
(9, 'XI-IPS 1', '2'),
(10, 'XI-IPS 2', '2'),
(11, 'XI-AGAMA', '3'),
(12, 'XII-IPA 1', '1'),
(13, 'XII-IPA 2', '1'),
(14, 'XII-IPS 1', '2'),
(15, 'XII-IPS 2', '2'),
(16, 'XII-AGAMA', '3');

-- --------------------------------------------------------

--
-- Struktur dari tabel `mapel`
--

CREATE TABLE `mapel` (
  `idmapel` int(11) NOT NULL,
  `nama_mapel` varchar(200) NOT NULL,
  `idjur` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `mapel`
--

INSERT INTO `mapel` (`idmapel`, `nama_mapel`, `idjur`) VALUES
(1, 'Fiqih', '1,2,3'),
(2, 'Ushul Fiqih', '2'),
(3, 'Al Quran Hadis', '3'),
(4, 'Aqidah Akhlak', '1'),
(5, 'Akhlak', '1'),
(6, 'S K I', '1'),
(7, 'Pendidikan Kewarganegaraan', '1'),
(8, 'Bahasa Indonesia', '2'),
(9, 'Bhs & Sastra Ind', '3'),
(10, 'Bahasa Arab', '1'),
(11, 'Bahasa Inggris', '2'),
(12, 'Bhs dan Sastra Ing', '2'),
(13, 'Matematika', ''),
(14, 'Sejarah', ''),
(15, 'Ilmu Tafsir', ''),
(16, 'Ilmu Hadits', ''),
(17, 'Ilmu Kalam', ''),
(18, 'Fisika', ''),
(19, 'Kimia', ''),
(20, 'Biologi', ''),
(21, 'Geografi', ''),
(22, 'Ekonomi', ''),
(23, 'Sosiologi', ''),
(24, 'Seni Budaya', ''),
(25, 'Pendidikan Jasmani, ORKES', ''),
(26, 'Teknologi Informasi Komunikasi', ''),
(27, 'Keterampilan', ''),
(28, 'BK', ''),
(29, 'Muhadatsah', ''),
(30, 'BKTI', ''),
(100, 'Abc', '');

-- --------------------------------------------------------

--
-- Struktur dari tabel `periode`
--

CREATE TABLE `periode` (
  `idperiode` int(11) NOT NULL,
  `semester` varchar(200) NOT NULL,
  `tahun_awal` year(4) NOT NULL,
  `tahun_akhir` year(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `periode`
--

INSERT INTO `periode` (`idperiode`, `semester`, `tahun_awal`, `tahun_akhir`) VALUES
(1, 'Ganjil', 2017, 2018),
(2, 'Genap', 2017, 2018),
(3, 'Gasal', 2018, 2019);

-- --------------------------------------------------------

--
-- Struktur dari tabel `user`
--

CREATE TABLE `user` (
  `id_user` int(11) NOT NULL,
  `email` varchar(200) NOT NULL,
  `password` varchar(200) NOT NULL,
  `nipuser` varchar(200) NOT NULL,
  `nama_lengkap` varchar(200) NOT NULL,
  `level` enum('admin','kepala sekolah','guru','') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `user`
--

INSERT INTO `user` (`id_user`, `email`, `password`, `nipuser`, `nama_lengkap`, `level`) VALUES
(1, 'rahma@mansurabaya.com', 'admin', '1234567890', 'Rahma Azmi Aziz, A.Md', 'admin'),
(2, 'faizal@mansurabaya.com', 'admin', '1234567890', 'Faizal Surya Afdhaludin, S.Kom.I', 'kepala sekolah'),
(3, 'denny1@mansurabaya.com', 'admin', '1234567890', 'Drs. DENNY MF., S.Pdi.', 'guru'),
(4, 'hasan@mansurabaya.com', 'admin', '1234567890', 'Drs. MOKH. HASAN B., M.Pd.', 'guru'),
(5, 'ingrid@mansurabaya.com', 'admin', '1234567890', 'INGRID ARIANY SAVITRI, S.Pd.', 'guru'),
(6, 'ihda@mansurabaya.com', 'admin', '1234567890', 'Dra. IHDA AFIFAH', 'guru'),
(7, 'mazidah@mansurabaya.com', 'admin', '1234567890', 'Dra. MAZIDAH INAYATI', 'guru'),
(8, 'enni@mansurabaya.com', 'admin', '1234567890', 'ENNI SUBCHANDINI, S.Pd', 'guru'),
(9, 'salam@mansurabaya.com', 'admin', '1234567890', 'Drs. ABD. SALAM HS.', 'guru'),
(10, 'sayudi@mansurabaya.com', 'admin', '1234567890', 'SAYUDI, S. Pd.', 'guru'),
(11, 'hadiah@mansurabaya.com', 'admin', '1234567890', 'HADIAH, S.Pd.', 'guru'),
(12, 'teguh@mansurabaya.com', 'admin', '1234567890', 'TEGUH KOESTANTININGSIH, S.Pd', 'guru'),
(13, 'efendi@mansurabaya.com', 'admin', '1234567890', 'Drs. AKHMAD EFENDI', 'guru'),
(14, 'mustofa@mansurabaya.com', 'admin', '1234567890', 'Drs. ALI MUSTOFA, M.Pd', 'guru'),
(15, 'suwinarti@mansurabaya.com', 'admin', '1234567890', 'Dra. SUWINARTI', 'guru'),
(16, 'alfiyah@mansurabaya.com', 'admin', '1234567890', 'ALIFIYAH RUSDIYANA, S.Pd.', 'guru'),
(17, 'nur@mansurabaya.com', 'admin', '1234567890', 'NUR JANAH, S.Pd', 'guru'),
(18, 'agus@mansurabaya.com', 'admin', '1234567890', 'Dra. AGUS SETYANINGSIH, M.Si', 'guru'),
(19, 'yudi@mansurabaya.com', 'admin', '1234567890', 'Drs. YUDI SYAIFULLOH', 'guru'),
(20, 'usman@mansurabaya.com', 'admin', '1234567890', 'USMAN, S.Pd.', 'guru'),
(21, 'ulumiyah@mansurabaya.com', 'admin', '1234567890', 'Dra. ULUMIYAH', 'guru'),
(22, 'yudha@mansurabaya.com', 'admin', '1234567890', 'YUDHA KURNIAWAN, S.Pd.', 'guru'),
(23, 'wiwin@mansurabaya.com', 'admin', '1234567890', 'WIWIN SISWINARNI, S.Pd.', 'guru'),
(24, 'wiji@mansurabaya.com', 'admin', '1234567890', 'WIJI  LAELATUL  JUMAH, S.Pd.', 'guru'),
(25, 'sudik@mansurabaya.com', 'admin', '1234567890', 'TRI SUDIK WIYONO, S.Pd', 'guru'),
(26, 'alief@mansurabaya.com', 'admin', '1234567890', 'ALIEF PURNOMO AJU, S.Pd.', 'guru'),
(27, 'surawan@mansurabaya.com', 'admin', '1234567890', 'SURAWAN, S.Pd.', 'guru'),
(28, 'marifa@mansurabaya.com', 'admin', '1234567890', 'MARIFA RIAMA, S.Pd.', 'guru'),
(29, 'ari@mansurabaya.com', 'admin', '1234567890', 'ARI KUSUMAWATI, M.Pd', 'guru'),
(30, 'yayuk@mansurabaya.com', 'admin', '1234567890', 'YAYUK ISWATIN, S.Pd', 'guru'),
(31, 'aini@mansurabaya.com', 'admin', '1234567890', 'NURUL AINI, S.Pd', 'guru'),
(32, 'neni@mansurabaya.com', 'admin', '1234567890', 'NENI SUHARTINI, S.Pd, M.Psi', 'guru'),
(33, 'arys@mansurabaya.com', 'admin', '1234567890', 'ARYS SUSANTO, M.Pd', 'guru'),
(34, 'anita@mansurabaya.com', 'admin', '1234567890', 'ANITA KURNIA RAHAYU, S.P.', 'guru'),
(35, 'arif@mansurabaya.com', 'admin', '1234567890', 'ARIF MUSTOFA, S.Ag., M.Pd.', 'guru'),
(36, 'suwar@mansurabaya.com', 'admin', '1234567890', 'MUHAMMAD SUWAR, S.Pd.I.', 'guru'),
(37, 'ismi@mansurabaya.com', 'admin', '1234567890', 'ISMI  MARIYAM, S.Pd.', 'guru'),
(38, 'rahmawati@mansurabaya.com', 'admin', '1234567890', 'NUR RAHMAWATI, S.Pd', 'guru'),
(39, 'aheri@mansurabaya.com', 'admin', '1234567890', 'AHERI SUGIHARTONO, S.Th.I', 'guru'),
(40, 'farid@mansurabaya.com', 'admin', '1234567890', 'MOCH. FARID WADJIDI Lc, S.Pd.', 'guru'),
(41, 'insa@mansurabaya.com', 'admin', '1234567890', 'INSA ASYAROH, S.Ag', 'guru'),
(42, 'sunarwan@mansurabaya.com', 'admin', '1234567890', 'SUNARWAN, S.Pd.', 'guru'),
(43, 'abas@mansurabaya.com', 'admin', '1234567890', 'Drs. ABAS SIMAN', 'guru'),
(44, 'maria@mansurabaya.com', 'admin', '1234567890', 'SITI MARIA ULFAH, S.Pd.I', 'guru'),
(45, 'mursalin@mansurabaya.com', 'admin', '1234567890', 'MURSALIN, ST, S.Pd', 'guru'),
(46, 'hanim@mansurabaya.com', 'admin', '1234567890', 'HANIM NURUL AINI, S.Pd.', 'guru'),
(47, 'salim@mansurabaya.com', 'admin', '1234567890', 'AGUS SALIM, S.Pd.', 'guru'),
(48, 'eddi@mansurabaya.com', 'admin', '1234567890', 'EDDI HARIYADI, S,Pd.', 'guru'),
(49, 'mardwi@mansurabaya.com', 'admin', '1234567890', 'MARDWI ASDIYANTO, M.Pd.I.', 'guru'),
(50, 'nashrul@mansurabaya.com', 'admin', '1234567890', 'NASHRUL ULUM, S.Pd.', 'guru'),
(51, 'umar@mansurabaya.com', 'admin', '1234567890', 'UMAR FARUQ, S.Ag.', 'guru'),
(52, 'fuadi@mansurabaya.com', 'admin', '1234567890', 'ALY FUADI, S.Pd.', 'guru'),
(53, 'fatukha@mansurabaya.com', 'admin', '1234567890', 'FATUKHA, S.Pd.', 'guru'),
(54, 'afif@mansurabaya.com', 'admin', '1234567890', 'MOHAMAD AFIF FARICHIN, M.Pd.I.', 'guru'),
(1000, 'agag@ana', '202cb962ac59075b964b07152d234b70', '12345678901', 'Cahya Ningsih Fitri, A.Mdaaa', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `dt_ngajar`
--
ALTER TABLE `dt_ngajar`
  ADD PRIMARY KEY (`iddata`);

--
-- Indexes for table `guru`
--
ALTER TABLE `guru`
  ADD PRIMARY KEY (`idguru`);

--
-- Indexes for table `hari`
--
ALTER TABLE `hari`
  ADD PRIMARY KEY (`idhari`);

--
-- Indexes for table `jadwal`
--
ALTER TABLE `jadwal`
  ADD PRIMARY KEY (`idjadwal`);

--
-- Indexes for table `jadwalku`
--
ALTER TABLE `jadwalku`
  ADD PRIMARY KEY (`idjadwalnya`);

--
-- Indexes for table `jampel`
--
ALTER TABLE `jampel`
  ADD PRIMARY KEY (`idjam`);

--
-- Indexes for table `jurusan`
--
ALTER TABLE `jurusan`
  ADD PRIMARY KEY (`idjur`);

--
-- Indexes for table `kelas`
--
ALTER TABLE `kelas`
  ADD PRIMARY KEY (`idkelas`);

--
-- Indexes for table `mapel`
--
ALTER TABLE `mapel`
  ADD PRIMARY KEY (`idmapel`);

--
-- Indexes for table `periode`
--
ALTER TABLE `periode`
  ADD PRIMARY KEY (`idperiode`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id_user`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `dt_ngajar`
--
ALTER TABLE `dt_ngajar`
  MODIFY `iddata` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `guru`
--
ALTER TABLE `guru`
  MODIFY `idguru` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=117;
--
-- AUTO_INCREMENT for table `hari`
--
ALTER TABLE `hari`
  MODIFY `idhari` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `jadwal`
--
ALTER TABLE `jadwal`
  MODIFY `idjadwal` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=310;
--
-- AUTO_INCREMENT for table `jadwalku`
--
ALTER TABLE `jadwalku`
  MODIFY `idjadwalnya` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `jampel`
--
ALTER TABLE `jampel`
  MODIFY `idjam` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `jurusan`
--
ALTER TABLE `jurusan`
  MODIFY `idjur` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `kelas`
--
ALTER TABLE `kelas`
  MODIFY `idkelas` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;
--
-- AUTO_INCREMENT for table `mapel`
--
ALTER TABLE `mapel`
  MODIFY `idmapel` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=101;
--
-- AUTO_INCREMENT for table `periode`
--
ALTER TABLE `periode`
  MODIFY `idperiode` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id_user` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1001;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
