1. vertex

3. warna

<?php 
include "koneksi.php";
$color = ['#00FFFF','#0000FF','#FFD700','#DC143C','#A9A9A9','#FF1493'];
$graph = "select * from graph_a";
$result = mysqli_query($conn, $graph);
$vertex_number = -1 ;
$vertex_list = [] ;
?>
<?if(vertex_number!=-1){
		$check=[];
		for($i=0;i<=vertex_number;i++){
			check[i]=-1;
		}
		fillColor(vertex_list[0][0],vertex_list[0][1],colors[0]);
		check[0]=0;

		for($j=1;j<vertex_list.length;j++){
			if(check[j]==-1){
				$temp=json[j];
				$c=[];
				for($k=0;k<temp.length;k++){
					if(check[temp[k]]!=-1){
						c.push(check[temp[k]]);
					}
				}
			}
			$flag_1=0;
			for($i=0;i<colors.length && flag_1==0;i++){
					if(isInArray(i, c)==false){
						fillColor(vertex_list[j][0],vertex_list[j][1],colors[i]);
						check[j]=i
						flag_1=1;
					}
			}
			if(flag_1==0){
				alert('Maximum number of color is 6 !!! please redraw')
			}
		}	
	}

?>

4. graph coloring
5. jadwal 