<h1>Biodata Guru</h1>
<table id="ver-minimalist">
  <?php
  include "koneksi.php";
  $coba = "Anis";
  $data = "SELECT * FROM user WHERE id_user = '$coba'";
  $dataguru = mysqli_query($conn, $data);
  while($row = mysqli_fetch_array($dataguru)){
	echo
	"<tr>
	  <td>NIP</td><td>:</td><td>$row[id_user]</td>
	</tr>
	<tr>
	  <td>Nama Lengkap </td><td>:</td><td>$row[email]</td>
	</tr>
	<tr>
	  <td>Mata Pelajaran yang Di AJarkan  </td><td>:</td><td>$row[nama_lengkap]</td>
	</tr>";
  }
 ?>
 
</table>
