<!--Author: W3layouts
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE HTML>
<html>
<head>
<?php
session_start();
include "koneksi.php"
?>
<title>Sistem Penjadwalan Mata Pelajaran MAN Surabaya</title>
<link href="css/style_log.css" rel="stylesheet" type="text/css" media="all"/>



<!-- Custom Theme files -->
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Login On Webapp Responsive, Login form web template, Sign up Web Templates, Flat Web Templates, Login signup Responsive web template, Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<!--web-fonts-->
<link href='//fonts.googleapis.com/css?family=Nunito:400,700,300' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Raleway:400,100,200,500,600,700,800,900' rel='stylesheet' type='text/css'>
<!--web-fonts-->
<script src="js/jquery.min.js"></script>
<script>$(document).ready(function(c) {
	$('.close').on('click', function(c){
		$('.mail-section').fadeOut('slow', function(c){
	  		$('.mail-section').remove();
		});
	});
});
</script>
</head>
<body>
	<div class="header">
		<h1>Login Scheduling System</h1>
	</div>
	<div class="main">
		<div class="mail-section">
			
				<div class="mail-image">

                	<img src="images/logo_.png" alt="" />

						<h3></h3>
						<h2>Madrasah Aliyah Negeri Surabaya</h2>
				</div>
					<div class="mail-form">
                    <form action="" method="post">

						<input type="text" name="email" class="user" placeholder="E-mail" required=""/>
						<input type="password" name="pass" class="pass" placeholder="Password" required=""/>
						<input type="submit" name="login" value="submit">
					</form>
					
					<?php
				if(isset($_POST['login'])){
					include "koneksi.php";
					$cek_data = mysqli_query($conn, "SELECT * FROM user WHERE
					email = '".$_POST['email']."' AND password = '".$_POST['pass']."'");
					$data = mysqli_fetch_array($cek_data);
					$level = $data['level'];
					$nama = $data['nama_lengkap'];
					if(mysqli_num_rows($cek_data) > 0){
						session_start();
						$_SESSION['id_user'] = $result['id_user'];
						if($level == 'admin'){
							header('location:home.php');
						}elseif($level == 'kepala sekolah'){
							header('location:awal.php');
						}elseif($level == 'guru'){
							header('location:dashboard.php');
						}
					}else{
						echo 'gagal login';
					}
				}
			?>
					
				</div>
			<div class="clear"> </div>
		</div>
	</div>
		<div class="footer">
			<p>&copy 2015 Flat Login On Webapp form . All rights reserved | Design by <a href="http://w3layouts.com">W3layouts.</a></p>
		</div>

</body>
</html>
