<?php 
if(isset($_POST['add'])){
	include "koneksi.php";
	$idjam = $_POST['idjam'];
	$jamke = $_POST['jamke'];
	$jammulai = $_POST['jam_mulai'];
	$jamselesai = $_POST['jam_selesai'];
	$sql = "insert into jampel (idjam, jamke, jam_mulai, jam_selesai) 
	VALUES('$idjam', '$jamke', '$jammulai', '$jamselesai')";
	if (mysqli_query($conn, $sql)) {
		header ('location:dtjam.php');
	} else {
		echo 'Error: ' . $sql. " . " .mysqli_error($conn);
	}
}
?>