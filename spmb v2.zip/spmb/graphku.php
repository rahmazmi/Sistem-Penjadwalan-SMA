<?php 
if(isset($_POST['add'])){
	include "koneksi.php";
	$idjadwal = $_POST['idjadwal'];
	$periode = $_POST['idperiode'];
	$kelas = $_POST[''];
	$jurusan = $_POST[''];
	$hari = $_POST[''];
	$graph = $_POST[''];
	$guru = $_POST[''];
	$query = "insert into jadwal ('')"
	$sql = "insert into guru (idguru, nama_guru, jurusannya, mapel_ajar) 
	VALUES('$idguru', '$namaguru', '$jurusan', '$mapel')";
	if (mysqli_query($conn, $sql)) {
		header ('location:dtguru.php');
	} else {
		echo 'Error: ' . $sql. " . " .mysqli_error($conn);
	}
}
?>