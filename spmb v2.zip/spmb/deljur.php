<?php
if(isset($_POST['delete'])){
	include "koneksi.php";
	$hapusdata = $_POST['idjur'];
	$del = "delete from jurusan where idjur = '$hapusdata'";
	if (mysqli_query($conn, $del)) {
		header ('location:dtjurusan.php');
	} else {
		echo 'Error deleting record: ' . mysqli_error($conn);
	}
}
?>